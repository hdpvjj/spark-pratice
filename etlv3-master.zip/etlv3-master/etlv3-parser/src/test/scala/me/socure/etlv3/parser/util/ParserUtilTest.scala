package me.socure.etlv3.parser.util

import me.socure.etlv3.parser.util.ParserUtil._
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormat
import org.scalatest.{FunSuite, Matchers}
import java.util.TimeZone

class ParserUtilTest extends FunSuite with Matchers {

  test("countrycode from mobile should be correctly obtained") {
    getCountryCode(Some("14842989760"))  shouldBe Some(1)
    getCountryCode(Some("+14842989760")) shouldBe Some(1)
    getCountryCode(Some("+919999999999")) shouldBe Some(91)
    getCountryCode(Some("+447975777666")) shouldBe Some(44)
    getCountryCode(Some("27214356666")) shouldBe Some(27)
  }

  test("date of birth decade should work as expected") {
    val fmt = DateTimeFormat.forPattern("yyyyMMdd")
    val date = new DateTime()
    getDecade(transactionDate = date.getMillis, dob = Some(new DateTime().minusYears(100).toString(fmt))) shouldBe Some(10)
    getDecade(transactionDate = date.getMillis, dob = Some(new DateTime().minusYears(200).toString(fmt))) shouldBe None
    getDecade(transactionDate = date.getMillis, dob = Some(new DateTime().minusYears(199).toString(fmt))) shouldBe Some(19)
    getDecade(transactionDate = date.getMillis, dob = Some(new DateTime().toString(fmt))) shouldBe Some(0)
    getDecade(transactionDate = date.getMillis, dob = Some(new DateTime().plusYears(2).toString(fmt))) shouldBe None
    (getDecade(transactionDate = date.getMillis, dob = Some("1975-12-012")) match {
      case Some(_) => true
      case _ => false
    }) shouldBe true
  }

  test("should obtain datetime as expected") {
    TimeZone.setDefault(TimeZone.getTimeZone("UTC"))
    getDateTime("2021/11/12").get.toString shouldBe "2021-11-12T00:00:00.000Z"
    getDateTime("2021-11-12").get.toString shouldBe "2021-11-12T00:00:00.000Z"
    // following test fails locally due to no UTC time set
    getDateTime("20211112").get.toString shouldBe "2021-11-12T00:00:00.000Z"
  }

  test("incorrect number inputs should return None") {
    getCountryCode(Some("00067567889"))  shouldBe None
    getCountryCode(Some(""))  shouldBe None
    getCountryCode(Some("00000000000"))  shouldBe None
    getCountryCode(Some("11111111111"))  shouldBe None
    getCountryCode(None)  shouldBe None
  }
}
