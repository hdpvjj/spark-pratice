package me.socure.etlv3.parser.util
import me.socure.etlv3.common.ParserResponse

object TestUtil {
  import org.joda.time.{DateTime, DateTimeZone}
  def stripTetlProcTime(payloadStr: String) = {
    payloadStr
      .split(",\"tetl_proc_time\":\"([0-9]{4}-[0-9]{2}-[0-9]{2})T([0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3})Z\"")
      .mkString("")
  }
  def getTetlProcTime(parserResponse: ParserResponse) = {
    val payloadStr = parserResponse.data.payload.getOrElse("")
    // plain old string parsing to extract tetl_proc_time value from payload json string
    // tetl_proc_time is usually added at the end of payload, except for rule_code... tables.
    val tetlProcTimeStr = payloadStr.split(",\"tetl_proc_time\":\"")(1).split(",")(0).stripSuffix("\"}").stripSuffix("\"")
    DateTime.parse(tetlProcTimeStr)
  }
  def getPayloadStripTetlProcTime(parserResponse: ParserResponse) = {
    stripTetlProcTime(parserResponse.data.payload.getOrElse(""))
  }

  def getPayload(parserResponse: ParserResponse) = {
    parserResponse.data.payload.get
  }

  def equalWoTetlProcTime(pr1: ParserResponse, pr2: ParserResponse) = {
    val payloadWoTetlProcTime1 = getPayloadStripTetlProcTime(pr1)
    val payload2 = getPayload(pr2)
    (payloadWoTetlProcTime1 == payload2) &&
      pr1.streamType == pr2.streamType &&
      pr1.data.transactionId == pr2.data.transactionId &&
      pr1.data.accountId == pr2.data.accountId
  }
}