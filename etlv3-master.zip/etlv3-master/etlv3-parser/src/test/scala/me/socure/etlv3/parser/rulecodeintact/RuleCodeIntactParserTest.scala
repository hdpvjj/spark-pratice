package me.socure.etlv3.parser.rulecodeintact

import java.io.File
import java.nio.charset.StandardCharsets
import me.socure.common.sqs.v2.MessageId
import me.socure.etlv3.common._
import me.socure.etlv3.parser.TransactionInputParser
import me.socure.etlv3.parser.rulecode.CompressData.compress
import me.socure.etlv3.parser.util.TestUtil
import org.json4s.{DefaultFormats, Formats}
import org.scalatest.{BeforeAndAfterAll, FunSuite, Matchers}

import scala.io.Source

class RuleCodeIntactParserTest extends FunSuite with Matchers with BeforeAndAfterAll {

  implicit val formats: Formats = DefaultFormats

  test("stripped pii's and stripped scores should not throw error") {
    val path = getClass.getResource("/response_sample_non_stripes.txt").getPath
    val file = new File(path)
    val source = Source.fromFile(file)
    val lines = source.getLines()
    lines.foreach {
      line =>
      noException should be thrownBy {
        val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""), line, None))
        RuleCodeIntactParser().parse(input)
      }
    }
    source.close()
  }

  test("should get expected output") {
    val input = TransactionInputParser.parse(getMessage())
    val actual = RuleCodeIntactParser().parse(input.copy(
                                       rulCodeSchema = List(RuleCodeSchema(
                                                                            "RuleCodeComplianceParser",
                                                                            "ruleCodeComplianceStream",
                                                                            Set("fmval_300009", "global_300214")
                                                                          )
                                                           )
                                     )
                          )
    (org.joda.time.DateTime.now().getMillis / 1000 - TestUtil.getTetlProcTime(actual).getMillis /1000 < 10) shouldEqual(true)
    val expected = ParserResponse(RuleCodeIntact("ae7a0c41-38a5-43fe-916f-27c668f09dd7", "1442",
                                                                   Some("{\"transaction_id\":\"ae7a0c41-38a5-43fe-916f" +
                                                                  "-27c668f09dd7\",\"transaction_date\":\"1970-01-01T02:48:18.877Z\",\"account_id\":\"1442\",\"run_id\":\"runid-test\",\"rule_codes\":{\"global_300214\":\"1.0\",\"fmval_300009\":\"1.0\",\"smsvl_100027\":\"Zip9\",\"smsvl_100004\":\"Y\"}}")), "ruleCodeIntactKinesisStream")
    TestUtil.equalWoTetlProcTime(actual, expected) shouldEqual true
  }

  private
  def getMessage(paramsStr: String = ""): WrappedMsg = {
    val msgId = MessageId("ae7a0c41-38a5-43fe-916f-27c668f09dd7", "")
    val txnData =
      s"""
         |{
         |   "transactionId": "ae7a0c41-38a5-43fe-916f-27c668f09dd7",
         |   "runId": "runid-test",
         |   "transactionDate": 10098877,
         |   "apiKey": "key",
         |   "accountId": 1442,
         |   "apiName": "/api/3.0/EmailAuthScore",
         |   "debug": "{}",
         |   "details": "{}",
         |   "response": "{}",
         |   "parameters": "{\\\"modules\\\": [\\\"fraud\\\",\\\"authenticity\\\",\\\"emailrisk\\\"]$paramsStr}",
         |   "debug": "[{\\\"rule_codes\\\":[{\\\"rulecode\\\":\\\"scoreComponents.GLOBAL.300214\\\",\\\"score\\\":\\\"0.0\\\",\\\"confidence\\\":\\\"0.0\\\",\\\"originalScore\\\":\\\"1.0\\\",\\\"ruleCodeShort\\\":\\\"GLOBAL.300214\\\"},{\\\"rulecode\\\":\\\"scoreComponents.FMVAL.300009\\\",\\\"score\\\":\\\"0.0\\\",\\\"confidence\\\":\\\"0.0\\\",\\\"originalScore\\\":\\\"1.0\\\",\\\"ruleCodeShort\\\":\\\"FMVAL.300009\\\"}],\\\"categorical_values\\\":[{\\\"rulecode\\\":\\\"SMSVL.100027\\\",\\\"value\\\":\\\"Zip9\\\"},{\\\"rulecode\\\":\\\"SMSVL.100004\\\",\\\"value\\\":\\\"Y\\\"}]}]"
         |}""".stripMargin
    WrappedMsg(msgId, compress(txnData.getBytes(StandardCharsets.UTF_8)), None)
  }

}
