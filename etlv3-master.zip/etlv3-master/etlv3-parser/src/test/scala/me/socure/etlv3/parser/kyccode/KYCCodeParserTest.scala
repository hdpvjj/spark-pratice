package me.socure.etlv3.parser.kyccode

import me.socure.common.sqs.v2.MessageId
import me.socure.etlv3.common.{KinesisStreamTypes, ParserResponse, Transaction, WrappedMsg}
import me.socure.etlv3.parser.TransactionInputParser
import me.socure.etlv3.parser.util.TestUtil
import org.json4s.{DefaultFormats, Formats}
import org.scalatest.{BeforeAndAfterAll, FunSuite, Matchers}

class KYCCodeParserTest extends FunSuite with Matchers with BeforeAndAfterAll {
  implicit val formats: Formats = DefaultFormats

  test("should get expected outputs") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""),
      "H4sIAAAAAAAA/2VSTYvbMBC951cYn9eJ5Dj+2NtCu7AUlkKhl7ossjRu1NiW0UdpuuS/dyzJ2XQLPnjejN4bvafXTZKkVrPJMG6lmp5Eep+kDCpGeEGzfc0OWbHvIWto2Wd5xcuy7kkjRJXevTv6gVnAw7Q8EPwIbWhd+hk2y09w9ryzzE74G2DOlZusV6SErqPPbFxo0h3+7/Zbsvs4Mjk8OHv8wpWGcFZA534sU6+XFbA4ZTzUprNWvRzAPKKAaNP7Fvd00KZ3bXo6cwRw5o+cfYdsCfWdXmpjJ1SPcO7RUXXINLmxAx0blW9wac8rATl4SKguIjQcNk7fENZNAK0G3FYIDcZcGUgZm+hiBOO4mWJd+Hpgxr78tyYsJq3ibXqJtqDErCYD0RcBXBqMCgcTLH+xwQWaXimkSZbrChieV/aO6Rv4K+h4uE3plqAKCmvoQcPE4SkYXXdVzmgHWdEImhX5Ic9YV5KsqQveQ1lWHQ334s5YNYL+HLL6NwuhuBthsigpe8mZXXWvEzMKy2EIWfrorlv/VCHqUQoxwA18nNZU3kDGT0ateN/L3x42Uq/mPy7ch3DpfF+8S5ruSL4jew8yYxSXmJ94COFCiBdRp+EtlJlplLfoZowF3XWDH06+4WU0cyLYzvDVowsyvLUF8TlraU6hnI9qglB+X2pnsFqCSOK2+Kou6eay+Qszt5Ya6AMAAA==", None
    )
    )
    val actual = KYCCodeParser().parse(input)
    val expected = ParserResponse(Transaction("ae7a0c41-38a5-43fe-916f-27c668f09dd7", "101", Some
    ("{\"transaction_id\":\"ae7a0c41-38a5-43fe-916f-27c668f09dd7\",\"transaction_date\":\"2022-04-22T17:53:39.186Z\"," +
      "\"account_id\":\"101\",\"zip\":\"0.01\",\"first_name\":\"0.2\"," +
      "\"mobile_number\":\"0.7\",\"city\":\"0.005\",\"dob\":\"0.12\",\"surname\":\"0.89\"," +
      "\"street_address\":\"0.0006\",\"state\":\"0.9\",\"ssn\":\"0.4\",\"email\":\"0.1\"}")),
      KinesisStreamTypes.KYCCodeStream.toString)
    TestUtil.equalWoTetlProcTime(actual, expected) shouldEqual true
  }
}