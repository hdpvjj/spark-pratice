package me.socure.etlv3.parser.reasoncode

import java.io.File
import me.socure.common.sqs.v2.MessageId
import me.socure.etlv3.common.{KinesisStreamTypes, ParserResponse, ReasonCode, WrappedMsg}
import me.socure.etlv3.parser.TransactionInputParser
import me.socure.etlv3.parser.util.TestUtil
import org.json4s.{DefaultFormats, Formats}
import org.scalatest.{BeforeAndAfterAll, FunSuite, Matchers}
import scala.io.Source

class ReasonCodeParserTest extends FunSuite with Matchers with BeforeAndAfterAll {
  implicit val formats: Formats = DefaultFormats

  test("stripped pii's and stripped scores should not throw error") {
    val path = getClass.getResource("/response_sample_non_stripes.txt").getPath
    val file = new File(path)
    val source = Source.fromFile(file)
    val lines = source.getLines()
    lines.foreach { line =>
      noException should be thrownBy {
        val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""), line, None))
        ReasonCodeParser().parse(input)
      }
    }
    source.close()
  }

  test("should get expected output and tetl_proc_time shall be recent") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""), "H4sIAAAAAAAA/71d61PbuBb/V5h8JqnlV+J+Y4HuzRToDrTs9pZORrEV8NSxc2WbLrvD/34l2U5kk4dOHWm/LMiSfkfnrQc9/w7iaPDecR3Lt3zfOh0UFKc5Dos4S6fsywCTMbZCFw2dCfaGrrMgwwD5i6E9Dn1/srCCKBoPWsMucEEG75FvBc7YnownlsWmXdEsJHkep4+f4yX77Pn+6QCvYoZwe3n3mc2wwhQvSUFoztr+fRikmE+Gkzh6GLx/GHz74/bT/fTi8uL7w+D0YRDGxcu29rwgq3J1S3Cepex7WiYJa13hlyVJi1xqoeQ5zsr8liwIJWlIptHm409chE9JnBeLOOEEbb7QMo2ljhGNnwlN4pCkOckLtvDNt2U2jxOSlss5odso/SdebWsmSxwn21dWTf/2QxaWlPwgFT+cxdgP8dwfhuGEDF3b9oaB7zjDkMnBmURzb2K7FQez5QqnLyljurSgbL4NYhHTvKh7vvm4enrJ4xAnOIooE7Et+mz7slWOGeNcWnClYAtcrjakZDQiTCOyMi02jfFqM1fd9EzSKKMd0YrBYT32DWiahTh84ouxOP9KumtpEWMtV5yylKUu5qVb1S8s8yJbElrmhNaKa1k4cj3kDD3kTYbufIGG2EXB0MOeF40tPPbmgRgrjfH9wJkwAxLt1VqecJqSRJIUmZeP7NcFTnLSVUWpGy5wHsZcw6XOjyQLs6ilrFGZEM7Eb3zqMM5jbj/sy4+XUPx/bRNMTGmEKSP0O9cMNr6tQouMhsykFkxKT6y1oCVHxKHgWkiJMOuoZSrxcsWsjBl7kVHmEypVrr/l5XwZ5/mbMREpmKHk0qI4/84rdZK7PTOW3BExg2zjCWaS4pztkJLXUzBP1Z1l8zuHummtulZL0ujhK/NorGHFJ6v8GW15mgclx7qRwHsxA/dq50xwtaCmAapUZOp4qJZHTJLonntNwee8Gins92aHkjP93/mpoIQUZ3vMd6cb3uGsdni9ylne7HSWO/xSnqdvml9fT2UV5st/xklZUcPUkKyKGjIiyXrh55REcXHyEdMlPrmoR59cZY9xuOl9z7S0mvRhcM/8HEd6TLI5Tv5srGOXpFDgVwJa8p6i+V9BaeMx/qAZizakGt80fmF6Nv0FNzLtupFXro+E0ow29tJY5HRVi5dpqWeP0CQY+ZMR8p2BiM8fyQv7oBJUBpspWd6AXNcWE3AOsxnesR/fOSPr3SWPb2dl8XQXZpSwQV++TC9YB/aTcMo5WzPPO759Zy3CyfFfOE+Zg5qFDUvrhtqLMU3gs52zkJalPNCPLv86u78aIZZ7WF6lKrxDxcmR1YSeRRzVnnHTnNH4MWZ5x916AKq/cEAu07unjFZxpY3yegqgyjdClQ+kChmhCgGpso1QZQOpmvSlylKhagKkyjLCKwtIVWCEqgBIlWNEgg6IKuSY8FcCBcQr14gEXSBVYyNUjVWoOv90/cfV19mfV/dnVyNbszPdCgakUbeybQVTkW7d3wp6e4199imjQKhCRqhCMKrs/vmENar5vYcsWzWhaJbh97YBFWb5iglFo4iot9YrUCVQQCLsneaoiVAxz1nbR2/Pr2SFip5/LXIjVujDrBD1j5IqiqUaJZtVuL1zQhVeuYo5YdN/3Dt2q1A1VordEm+1ZvUyCsgGte4WZRSQBI3Y4Bhqg1qzehkFxCsTVAkUkBc9QshR8KKwiIOQES+KYF7U7r/XUAvPMIdl+SYclkABidBEyBEoIDdqJBsNYNmofQyHpaJYQN/gGPFYDpCqiZGYMwHuCQMTGwqBAqGq/6mbClWqp27ryGmCKgSkyhobcaNjYN43MaJXE6BeTY5w1qBAFSwbRchI3oeA/iow4kUDGFXoGEcNCjYIPGkwkrkrn8ev4+YRslGV8Aw9ADHCLB+o7rYRh2UDHdbYSN43huV9lmNk8+UAN196r59+9SrANiJBGyjBwMgRVgA9wjIRnhHwJgD1f4ahRBVQrzwjh9sezLcjZCQ8I5hnsI8hQZVACHUNRozQhhqhCYeFVF/SrHl7hL2XigiBmy/HyObLgR66G6EqAJ6s9X/go6RYwJO1iREjnMCM0D7GZY6KugMVyzWSzLjQS3EjHgtBPdYRqFIRIZBZtpEIbStF6N+vPv3GBjhHMcPdyXsHBkIX6v8MRIUupPYORBqg80KgA6NMV8C3kjrPHDo4IAXrf2GopGBqN4byQnTmph0cZcK4CbvdY5qhNfJ2UOb9KssaIJAo7f4vOgMHjdyxd4BvDRiIuv5v/5QUTe3xn2zKGtOvDgyIXzrPTjswMMPU+S6xgwMLSb0FqRaSgIJE/S8MlOhSuzGQBvRPWpXoUsta5VBhRI4WVI6WbyYV8yGpGDcUR78cGxiYo9D5vKaDAzNIjal+B+YwXXfXdwb+rK2NAqJK49lzGwVC1RFSHQWq1HKcTX+dF9ZtFBBVGtW9jQKiSuP5UhsFpO0aTwjbKCBeadzUtlFANqhx59hGAUlQ42OkNgqIVxqfe7dRQFQZiThqd/uSHmq8wWujAKjSeoveRgFJUGPu10YBSVDjlrqNAqLKSCaDYDZ4hNsfFb1Su/2R/JvGvU4bBSRBjS8O2iiHqfpwfd+coGg82GqjQKhyNWZ9bRQAVf7YBFUCRZUqmwtco79qo0AkiHrnoip6hZRy0ap/cJxd6oFD5jYWRLv6n9DYvoJ6qZ3QbFisX70aFFWqXM3ny20UkNvqTZWj4raAVOn8k6w2CsQUdW7s2yggqrSHwwYFIkGdiXIbBRQONV4NtFFAgUfjcUMbBUKVzsfVbRRVqrbeBh+dKvWrYMk6tGt78AsS1PmvFrRRQNqu8Si5jQKiqr8XdSzHU6EM6En75w1K2x1o3qDxgK2NAvLvJjReoICyGY1HpG0UUPLeW4JqyTtMhFpPQtoooF2YxtuTNgooGGpX9wYF5Eq1h+gGBaRXRtIZtT/YlByckdRP7UmIlGj039erpDPAbb2r3QYbFIgN6rynaKOAtl8a7wrbKKBAaESC0OMit3dCOlbRK2hCaiR5V7vTkfobic4QzxAc5aZJyV9BMxmN96ptFFDa1/toTS3tgx5z9xZhoJJgAUWo/8SvQQEplpGLCrVHM9KuyEQq46v9EwHS+ZIRI3QARujxgxzt59sNCsg1mNin+sB9quVqvIRuo7zy6hIU/5w1WO7IO+XlcUTNihlerZKYVHUhnJoCSkkiyoRUY2ZxusgeRAEKXtJl9qbUjmhtChTJbasntvC6jRe1iFNeJSZkM1aA8dAa+8EcWS7GeIyxE1aRuKr4MCtzQdi376KpII+MCyFOZqJux9ZyD9Jrk2qmTYmP/8arrTKSHhK4nSFfD/S3O/1v9vev7WPT/5bkXNRFjJMDSAhGmW11+t+ti/PsJTDoDPvPAbIcGAPsbv/bbf0l9e0yzN0e6jY7Cqu78N/P9g+oT/w2A64/7x7gbkL6ZoDNuD1E9tBBJ5b13kLvt+d50hVrV5gfpn9dXsyupjeXs0+3s+tPv02vLndPEWzTJIQCG52EWUIojtMTGp3gVXHiONsPQKVw2KXlkVvxKMyW+8c5XS48kpRQXhNnrzy7+vXl7sA6u+L8k2xV4Y083zD3GvPiOXvX4nWGHF59V48v/8ZhsW2M/MexXZityi+9/H/D47MlZzF+d0N+zr5m9Meh8V0PuP2MXv6jka4D3Gr/MkRXDy+fSSoqZImo87+S0JfZKsFNvaV1SbZv7TIAYhZRWEH8JDgtfrq+atqEF6n7ia8cII7Y7GU+E1WY6ppWcvjatPPoQ+P8h9z0Ks2wILgoKannoISRnhckktsZzetyTs6s0sxrUR+tqQslVs5aP349r+hjA7Pkufc0WVmsyqInOa8i3XgivAedFfGSsGmr5SYkfSx4UTbu4Fi3Mo2rTOJ6enU1vbs8/3RzISy1EWEzvGZXW5TAGWuxA0fVKgIcVasTcFSteq1RSGFdYAqFRj4VxWrG66SVnLu2GFDVDdtUuWoKh7FP03F9ij8d195y6nle80kuA1f1aX6ok52qVBxXsp+SMs1yUvBKd7V8c4Jp+CSKhyHXHruON/FPRfG1szSqS6XV9fxY22cRhaoEdl2FMJtf8/nrwmls6YS7zNkL+2+2XM6iSFCzKP/5J05ZbinPYYl8NQ8pEb7lvEoEXyo+5KxT0dQk/InpWukXccEnGq5oNhfF6Pgak3gpOI8skec25RpFgrlkBlOwBDOVqyfmWUlDwpd4RwrR8/W1KkAmqgzWJcg6xfUqpu0pbnmoBOiuspNSJUjx+/aaoFyJ5gkOf3BhEqm04aoqJZd/YAtf59XrKoI7KvDtLfF5aCG7ygDuKtu3u+JmVXFwD093l0HdVguwvc0Rm6r87Q5ntrPoamt3s+frgRkaHJW+SjOpIb3lh1BqvK6+x2zOOpW2onWDVL6Qa/6bQpOn64KGbLYnnN+ygMt7r2sLtusXsjmaSoSiKqaIuV9up1XVP6aYtVcZZAscrucg6XNMs5SXX/38suIVhV//D987cVOteAAA", None))
    val actual = ReasonCodeParser().parse(input)
    org.joda.time.DateTime.now().getMillis / 1000 - TestUtil.getTetlProcTime(actual).getMillis / 1000 < 10 shouldEqual true
    val expected = ParserResponse(ReasonCode("ae7a0c41-38a5-43fe-916f-27c668f09dd7", "1442",Some("{\"transaction_id\":\"ae7a0c41-38a5-43fe-916f-27c668f09dd7\",\"account_id\":\"1442\",\"transaction_date\":\"2020-12-31T00:01:18.000Z\",\"reason_codes\":[\"i196\",\"i351\",\"i919\"],\"i919\":true,\"i351\":true,\"i196\":true}")),KinesisStreamTypes.ReasonCodeStream.toString)
    TestUtil.equalWoTetlProcTime(actual, expected) shouldEqual true
  }

  test("resoncode should be parsed from response") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""), "H4sIAJ0Xk2QC/41QPW/CMBT8K5FnAgmOCWGraAfUqgMdG4aH81IiEjuynQGh/Pc+O6BWVVV1uzvd3fu4MmdAWZCu0WpXsU3EjhkmuUCMKziu4yzlVQzrPIvzohbLVBQ1CM5m0ffgIzikaMqzgnMu8lVScHJA3zzjxXcSis8EvSilHpQLs9LJ9Aqdj7MF4QWfJ4unDpr2YXCnN6kN+lSFx+HDe67jRB057Jdg0PZa2VBzLYnWaFBJ3FUl25T/uqlks5IpWiVM32pjsAV/HTWESrBabXWFloT3ku2FKEp2oJD1W5KYzJN8JI6+YN/Y859JMu7EKrmDdQB7sbwrIr0D8XNMkXM/B1o07qWx7tc5PtKBk6cbHcOjejB0okNjb6/qdDW0wRLRarWBgV42i6id/o/KNbJxl0kJd5lwl6f9SSuc6GFk4yeX35iVSwIAAA==", None))
    val actual = ReasonCodeParser().parse(input)
    org.joda.time.DateTime.now().getMillis / 1000 - TestUtil.getTetlProcTime(actual).getMillis / 1000 < 10 shouldEqual true
    val expected = ParserResponse(ReasonCode("b4e075ee-dab8-413d-a874-79f52159fa53", "1",Some("{\"transaction_id" + "\":\"b4e075ee-dab8-413d-a874-79f52159fa53\",\"account_id\":\"1\",\"transaction_date\":\"2012-10-04T06:52:56.093Z\",\"reason_codes\":[\"i555\",\"r559\",\"i551\",\"i568\",\"i560\",\"r520\"],\"i555\":true,\"r559\":true,\"i551\":true,\"i568\":true,\"i560\":true,\"r520\":true}")),KinesisStreamTypes.ReasonCodeStream.toString)
    TestUtil.equalWoTetlProcTime(actual, expected) shouldEqual true
  }

}
