package me.socure.etlv3.parser.transaction

import me.socure.etlv3.parser.transaction.HeuristicUtil.ipInRange
import org.scalatest.{BeforeAndAfterAll, FunSuite, Matchers}

class HeuristicUtilTest extends FunSuite with Matchers with BeforeAndAfterAll {

  test("mobile number obtained should not be alternate") {
    HeuristicUtil.isAlternate("4153689377") shouldBe false
    HeuristicUtil.isAlternate("1010101000") shouldBe false
    HeuristicUtil.isAlternate("1111111111") shouldBe false
  }

  test("mobile number obtained should be alternate") {
    HeuristicUtil.isAlternate("1010101010") shouldBe true
  }

  test("mobile number as all of same digit should return true") {
    HeuristicUtil.isAllSame("111111111") shouldBe true
    HeuristicUtil.isAllSame("000000000") shouldBe true
  }

  test("mobile number as all one should return true") {
    HeuristicUtil.isAllOne("111111111") shouldBe true
  }

  test("should check iprange properly") {
    ipInRange(Some("172.16.0.5")) shouldBe true
    ipInRange(Some("182.16.0.5")) shouldBe false
    ipInRange(Some("10.20.40.240")) shouldBe true
    ipInRange(Some("18.206.226.161")) shouldBe false
    ipInRange(Some("1.1.81.87")) shouldBe false
    ipInRange(Some("166.137.17.31")) shouldBe false
    ipInRange(Some("166.137.113.31")) shouldBe false
    ipInRange(Some("10.20.11.19")) shouldBe true
    ipInRange(Some("165.209.219.235")) shouldBe false
    ipInRange(Some("192.168.0.5")) shouldBe true
  }

  test("should check iprange properly for comma separated ip's") {
    ipInRange(Some("165.209.219.235,10.20.11.19")) shouldBe false
    ipInRange(Some("165.209.219.235,166.137.113.31")) shouldBe false
    ipInRange(Some("172.16.0.5,10.20.40.240")) shouldBe true
    ipInRange(Some("172.16.0.5,10.20.40.240")) shouldBe true
    ipInRange(Some("165.209.219.235,10.20.11.19,192.168.0.5")) shouldBe false
    ipInRange(Some("172.16.0.5,10.20.40.240,192.168.0.5")) shouldBe true
  }

  test("nationalid is all one or zero") {
    HeuristicUtil.isAllOneOrZero(Some("000000000"), '0') shouldEqual(true)
    HeuristicUtil.isAllOneOrZero(Some("111111111"), '1') shouldEqual(true)
  }

}
