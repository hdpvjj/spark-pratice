package me.socure.etlv3.parser.util

import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import java.util.zip.GZIPOutputStream
import java.util.{Base64, UUID}
import me.socure.common.sqs.v2.MessageId

object TestDataProvider {

  def getRandomMessage(paramsStr: String = ""): WrappedMsg = {
    val extraParams = if (paramsStr.nonEmpty) "," + paramsStr  else ""
    val id = UUID.randomUUID().toString
    val msgId = MessageId(id, "")
    val txnData = s"""
                     |{
                     |   "transactionId": "test-$id",
                     |   "transactionDate": 10098877,
                     |   "apiKey": "key",
                     |   "accountId": 1,
                     |   "apiName": "/api/3.0/EmailAuthScore",
                     |   "debug": "{}",
                     |   "details": "{}",
                     |   "response": "{}",
                     |   "parameters": "{\\\"modules\\\": [\\\"fraud\\\",\\\"authenticity\\\",\\\"emailrisk\\\"]$extraParams}"
                     |}""".stripMargin
    WrappedMsg(msgId, compress(txnData.getBytes(StandardCharsets.UTF_8)))
  }

  private def compress(data: Array[Byte]): String = {
    val bos = new ByteArrayOutputStream(data.length)
    val gzipOut = new GZIPOutputStream(bos)
    gzipOut.write(data)
    gzipOut.close()
    val res = bos.toByteArray
    res(9) = -1 //Operating System flag. To be compatible with the existing implementation
    Base64.getEncoder.encodeToString(res)
  }

}

case class WrappedMsg(id: MessageId, body: String)