package me.socure.etlv3.parser.prefill

import argonaut.{DecodeJson, DecodeResult, Parse}
import me.socure.common.sqs.v2.MessageId
import me.socure.dapl.snowflake.crypto.{Decryption, HexadecimalFactory}
import me.socure.etlv3.common.WrappedMsg
import me.socure.etlv3.parser.TransactionInputParser
import org.json4s.{DefaultFormats, Formats}
import org.scalatest.{BeforeAndAfterAll, FunSuite, Matchers}

class PrefillParserTest extends FunSuite with Matchers with BeforeAndAfterAll {
  implicit val formats: Formats = DefaultFormats

  private def decryptParameter(para: DecodeResult[Dcrpt]): String = {
    Decryption().decryptRaw(para.result.right.get.ciphertext, para.result.right.get.iv, para.result.right
      .get.tag, para.result.right.get.aad, HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290"))
  }

  test("should get expected outputs") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""),
      "H4sIAAAAAAAA/2VTTYvbMBC951cYndeJ5DiOvbeFdmEpLIVCL3UpsjRu1NiW0cfSdMl/71iSt2ELOXjezLw3M0953WQZcYZPlgun9PQkyX1GOBw5FSXL9zU/5OW+h7xhVZ8XR1FVdU8bKY/k7l3rB+4Am1l1oPijrGF1FWr4rD7BJfDOKj/jZ4SF0H5yQZFRtpY+83GhITv83u23dPdx5Gp48O70RWgDsVdC538uVa/XFXBYZQPUktnoXg1gH1FAtuS+xTk9tOSuJeeLQABr/qg5ZOiWspDplbFuQvUEFwEddYdMkx87MClxDAmh3GUloIcASd0lhMVm680NYd1E0BnAaaU0YO0bA61SEq+YwFRupxSXIR64dT/+GxOWI63iLbmms6DErCcL6S4ShLJoFRZmGL7wwUeaXmukyZZ1JQzPK3vHzQ38FUxqbgnbUlRBYQM9GJgEPMVD192x4KyDvGwky8viUOS8q2je1KXooaqOHYt7CW+dHsF8jl5FU3iUjdRSCz/C5FBX9UpwF8Vf07jrfEvpjGOoYUjZxci3HX7paPyopBzgBj5Nq0f/QC7OVq9436vfAbbKrFY8LtyHeIJiX77zne1osaP7AHJrtVDopnyIVoON4yHsTdR7WTa7LHYlv2ZucBaHh06O4eH9EDqzb7iZ4V5GRzj+IfA2Kj7DBQlPwCh7juF80hPE8PsSe4vR4lGWRscHdyWb6+Yv7bw1SwMEAAA=", None
    )
    )

    val parseResponse = PrefillParser(List.empty[Long]).parse(input, Map("101" -> HexadecimalFactory
      .convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))

    val json = Parse.parse(parseResponse.data.payload.get).right.get
    val first_name = (json.hcursor --\ "first_name").as[Dcrpt]
    val middle_name = (json.hcursor --\ "middle_name").as[Dcrpt]
    val sur_name = (json.hcursor --\ "sur_name").as[Dcrpt]
    val suffix = (json.hcursor --\ "suffix").as[Dcrpt]
    val ssn_first_5 = (json.hcursor --\ "ssn_first_5").as[Dcrpt]
    val dob = (json.hcursor --\ "dob").as[Dcrpt]
    val associated_addresses = (json.hcursor --\ "associated_addresses").as[Dcrpt]
    decryptParameter(first_name) shouldBe "joe"
    decryptParameter(middle_name) shouldBe "john"
    decryptParameter(sur_name) shouldBe "jackson"
    decryptParameter(suffix) shouldBe "sir"
    decryptParameter(ssn_first_5) shouldBe "12345"
    decryptParameter(dob) shouldBe "01/02/03"
    decryptParameter(associated_addresses) shouldBe "{\"socure\":\"verify\"}"
  }

  private implicit
  val decodeAll: DecodeJson[Dcrpt] = DecodeJson {
    h =>
      for {
        ciphertext <- (h --\ "ciphertext").as[String]
        iv <- (h --\ "iv").as[String]
        tag <- (h --\ "tag").as[String]
        aad <- (h --\ "aad").as[String]
      } yield Dcrpt(
        ciphertext = ciphertext,
        iv = iv,
        tag = tag,
        aad = aad
      )
  }
}

case class Dcrpt(ciphertext: String, iv: String, tag: String, aad: String)
