package me.socure.etlv3.parser.rulecode

import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.zip.GZIPOutputStream

object CompressData {

  def compress(data: Array[Byte]): String = {
    val bos = new ByteArrayOutputStream(data.length)
    val gzipOut = new GZIPOutputStream(bos)
    gzipOut.write(data)
    gzipOut.close()
    val res = bos.toByteArray
    res(9) = -1
    Base64.getEncoder.encodeToString(res)
  }

}
