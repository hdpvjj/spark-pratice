package me.socure.etlv3.parser.transactionpii

import java.io.File
import argonaut.{DecodeJson, Json, Parse}
import me.socure.common.sqs.v2.MessageId
import me.socure.dapl.snowflake.crypto.{Decryption, HexadecimalFactory}
import me.socure.etlv3.common.{KinesisStreamTypes, ParserResponse, TransactionPii, WrappedMsg}
import me.socure.etlv3.parser.TransactionInputParser
import me.socure.etlv3.parser.util.TestUtil
import org.json4s.{DefaultFormats, Formats}
import org.scalatest.{BeforeAndAfterAll, FunSuite, Matchers}

import scala.io.Source

class TransactionPiiParserTest extends FunSuite with Matchers with BeforeAndAfterAll {
  implicit val formats: Formats = DefaultFormats

  test("stripped pii's and stripped scores should not throw error") {

    val path = getClass.getResource("/response_sample_non_stripes.txt").getPath
    val file = new File(path)
    val source = Source.fromFile(file)
    val lines = source.getLines()
    lines.foreach {
      line =>
      noException should be thrownBy {
        val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""), line, None))
        TransactionPiiParser(List.empty[Long]).parse(input, Map("1442" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290"),
                                                "1232" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290"),
                                                "1231" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")
                                               )
                                    )
      }
    }
    source.close()
  }

  test("should get expected output for entityType") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""),
                                                        "H4sIAHnot2QC/02QQU+EMBCF/wrpWYQC0sWbUWOMG2OiN+thKMNus9A2pRxww3+3pZust3mv37w36Zk4C2oC4aRWrx25Twggg1xUNC13cJdWZY9pQ+s+LZio612fN13HyE3yf/EJHIZVWu8axirKKC3LwICRb7hsqUamJz8GUwg9K7e1FXkRsXcYt4jMz1l5m2fPI8jhYXbHT6Ethr0O2/kQmPMapfPEdDUsTkarCa+OAetjHdpIcTLqbh5w4l5+c9JbmDvuQU7AF6FyUki3RAdDv5XTKUpz1Aqj/NmePeyWcHUI4+Rl0C0MyQe0g072+8dLyEZ9LeZCaXsAJX8hfBonK1n/AP2kzuGAAQAA", None
                                                       )
                                            )

    val parseResponse = TransactionPiiParser(List.empty[Long]).parse(input, Map("202" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))

    val json = Parse.parse(parseResponse.data.payload.get).right.get

    val entityName = (json.hcursor --\ "entity_name").as[Dcrpt]
    val decEntityName = Decryption().decryptRaw(
                                                 entityName.result.right.get.ciphertext,
                                                 entityName.result.right.get.iv,
                                                 entityName.result.right.get.tag,
                                                 entityName.result.right.get.aad,
                                             HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")
                                           )
    decEntityName shouldBe "Global Pablo LLC"
  }

  test("should get expected output for userid") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""),
                                                        "H4sIAKPrYmIC/02NzU7DMBCEX6XymRC7SZyGGxIcEBIXjpjDYm+o1caO/HOoqrw76/pQpD3sjL6ZubIUwEXQyXr3ZtjTjgGOwHUvmu4AQ9N3MzaTkHOzH7WUh5lPxozsYfc/+AIJKSrkwOm4mMRBEgGrfcfLrXO1zYneYmrts0u3LcFFxT5gKQWspb/tHnn7uoA9P+d0/NQ+YMkZ/Mm/hbluVSYi4t0IGFfvIt6dFQLVJgyVUmzxJp8xKpJfis0BslEEKgY0hC5ZbdOlOlj2g42nKtejd1jld9E5kjKlSDGx7/pBKrax7Q9goEysTgEAAA==", None
                                                       )
                                            )

    val parseResponse = TransactionPiiParser(List.empty[Long]).parse(input, Map("101" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))

    val json = Parse.parse(parseResponse.data.payload.get).right.get

    val userid = (json.hcursor --\ "user_id").as[Dcrpt]
    val decUserId = Decryption().decryptRaw(
                                              userid.result.right.get.ciphertext,
                                              userid.result.right.get.iv,
                                              userid.result.right.get.tag,
                                              userid.result.right.get.aad,
                                              HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")
                                            )
    decUserId shouldBe "123456"
  }

  test("should get expected output for environment_id") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""),
      """H4sIAAAAAAAA/71d61PbuBb/V5h8JqnlV+J+Y4HuzRToDrTs9pZORrEV8NSxc2WbLrvD/34l2U5kk4dOHWm/LMiSfkfnrQc9/w7iaPDecR3Lt3zfOh0UFKc5Dos4S6fsywCTMbZCFw2dCfaGrrMgwwD5i6E9Dn1/srCCKBoPWsMucEEG75FvBc7YnownlsWmXdEsJHkep4+f4yX77Pn+6QCvYoZwe3n3mc2wwhQvSUFoztr+fRikmE+Gkzh6GLx/GHz74/bT/fTi8uL7w+D0YRDGxcu29rwgq3J1S3Cepex7WiYJa13hlyVJi1xqoeQ5zsr8liwIJWlIptHm409chE9JnBeLOOEEbb7QMo2ljhGNnwlN4pCkOckLtvDNt2U2jxOSlss5odso/SdebWsmSxwn21dWTf/2QxaWlPwgFT+cxdgP8dwfhuGEDF3b9oaB7zjDkMnBmURzb2K7FQez5QqnLyljurSgbL4NYhHTvKh7vvm4enrJ4xAnOIooE7Et+mz7slWOGeNcWnClYAtcrjakZDQiTCOyMi02jfFqM1fd9EzSKKMd0YrBYT32DWiahTh84ouxOP9KumtpEWMtV5yylKUu5qVb1S8s8yJbElrmhNaKa1k4cj3kDD3kTYbufIGG2EXB0MOeF40tPPbmgRgrjfH9wJkwAxLt1VqecJqSRJIUmZeP7NcFTnLSVUWpGy5wHsZcw6XOjyQLs6ilrFGZEM7Eb3zqMM5jbj/sy4+XUPx/bRNMTGmEKSP0O9cMNr6tQouMhsykFkxKT6y1oCVHxKHgWkiJMOuoZSrxcsWsjBl7kVHmEypVrr/l5XwZ5/mbMREpmKHk0qI4/84rdZK7PTOW3BExg2zjCWaS4pztkJLXUzBP1Z1l8zuHummtulZL0ujhK/NorGHFJ6v8GW15mgclx7qRwHsxA/dq50xwtaCmAapUZOp4qJZHTJLonntNwee8Gins92aHkjP93/mpoIQUZ3vMd6cb3uGsdni9ylne7HSWO/xSnqdvml9fT2UV5st/xklZUcPUkKyKGjIiyXrh55REcXHyEdMlPrmoR59cZY9xuOl9z7S0mvRhcM/8HEd6TLI5Tv5srGOXpFDgVwJa8p6i+V9BaeMx/qAZizakGt80fmF6Nv0FNzLtupFXro+E0ow29tJY5HRVi5dpqWeP0CQY+ZMR8p2BiM8fyQv7oBJUBpspWd6AXNcWE3AOsxnesR/fOSPr3SWPb2dl8XQXZpSwQV++TC9YB/aTcMo5WzPPO759Zy3CyfFfOE+Zg5qFDUvrhtqLMU3gs52zkJalPNCPLv86u78aIZZ7WF6lKrxDxcmR1YSeRRzVnnHTnNH4MWZ5x916AKq/cEAu07unjFZxpY3yegqgyjdClQ+kChmhCgGpso1QZQOpmvSlylKhagKkyjLCKwtIVWCEqgBIlWNEgg6IKuSY8FcCBcQr14gEXSBVYyNUjVWoOv90/cfV19mfV/dnVyNbszPdCgakUbeybQVTkW7d3wp6e4199imjQKhCRqhCMKrs/vmENar5vYcsWzWhaJbh97YBFWb5iglFo4iot9YrUCVQQCLsneaoiVAxz1nbR2/Pr2SFip5/LXIjVujDrBD1j5IqiqUaJZtVuL1zQhVeuYo5YdN/3Dt2q1A1VordEm+1ZvUyCsgGte4WZRSQBI3Y4Bhqg1qzehkFxCsTVAkUkBc9QshR8KKwiIOQES+KYF7U7r/XUAvPMIdl+SYclkABidBEyBEoIDdqJBsNYNmofQyHpaJYQN/gGPFYDpCqiZGYMwHuCQMTGwqBAqGq/6mbClWqp27ryGmCKgSkyhobcaNjYN43MaJXE6BeTY5w1qBAFSwbRchI3oeA/iow4kUDGFXoGEcNCjYIPGkwkrkrn8ev4+YRslGV8Aw9ADHCLB+o7rYRh2UDHdbYSN43huV9lmNk8+UAN196r59+9SrANiJBGyjBwMgRVgA9wjIRnhHwJgD1f4ahRBVQrzwjh9sezLcjZCQ8I5hnsI8hQZVACHUNRozQhhqhCYeFVF/SrHl7hL2XigiBmy/HyObLgR66G6EqAJ6s9X/go6RYwJO1iREjnMCM0D7GZY6KugMVyzWSzLjQS3EjHgtBPdYRqFIRIZBZtpEIbStF6N+vPv3GBjhHMcPdyXsHBkIX6v8MRIUupPYORBqg80KgA6NMV8C3kjrPHDo4IAXrf2GopGBqN4byQnTmph0cZcK4CbvdY5qhNfJ2UOb9KssaIJAo7f4vOgMHjdyxd4BvDRiIuv5v/5QUTe3xn2zKGtOvDgyIXzrPTjswMMPU+S6xgwMLSb0FqRaSgIJE/S8MlOhSuzGQBvRPWpXoUsta5VBhRI4WVI6WbyYV8yGpGDcUR78cGxiYo9D5vKaDAzNIjal+B+YwXXfXdwb+rK2NAqJK49lzGwVC1RFSHQWq1HKcTX+dF9ZtFBBVGtW9jQKiSuP5UhsFpO0aTwjbKCBeadzUtlFANqhx59hGAUlQ42OkNgqIVxqfe7dRQFQZiThqd/uSHmq8wWujAKjSeoveRgFJUGPu10YBSVDjlrqNAqLKSCaDYDZ4hNsfFb1Su/2R/JvGvU4bBSRBjS8O2iiHqfpwfd+coGg82GqjQKhyNWZ9bRQAVf7YBFUCRZUqmwtco79qo0AkiHrnoip6hZRy0ap/cJxd6oFD5jYWRLv6n9DYvoJ6qZ3QbFisX70aFFWqXM3ny20UkNvqTZWj4raAVOn8k6w2CsQUdW7s2yggqrSHwwYFIkGdiXIbBRQONV4NtFFAgUfjcUMbBUKVzsfVbRRVqrbeBh+dKvWrYMk6tGt78AsS1PmvFrRRQNqu8Si5jQKiqr8XdSzHU6EM6En75w1K2x1o3qDxgK2NAvLvJjReoICyGY1HpG0UUPLeW4JqyTtMhFpPQtoooF2YxtuTNgooGGpX9wYF5Eq1h+gGBaRXRtIZtT/YlByckdRP7UmIlGj039erpDPAbb2r3QYbFIgN6rynaKOAtl8a7wrbKKBAaESC0OMit3dCOlbRK2hCaiR5V7vTkfobic4QzxAc5aZJyV9BMxmN96ptFFDa1/toTS3tgx5z9xZhoJJgAUWo/8SvQQEplpGLCrVHM9KuyEQq46v9EwHS+ZIRI3QARujxgxzt59sNCsg1mNin+sB9quVqvIRuo7zy6hIU/5w1WO7IO+XlcUTNihlerZKYVHUhnJoCSkkiyoRUY2ZxusgeRAEKXtJl9qbUjmhtChTJbasntvC6jRe1iFNeJSZkM1aA8dAa+8EcWS7GeIyxE1aRuKr4MCtzQdi376KpII+MCyFOZqJux9ZyD9Jrk2qmTYmP/8arrTKSHhK4nSFfD/S3O/1v9vev7WPT/5bkXNRFjJMDSAhGmW11+t+ti/PsJTDoDPvPAbIcGAPsbv/bbf0l9e0yzN0e6jY7Cqu78N/P9g+oT/w2A64/7x7gbkL6ZoDNuD1E9tBBJ5b13kLvt+d50hVrV5gfpn9dXsyupjeXs0+3s+tPv02vLndPEWzTJIQCG52EWUIojtMTGp3gVXHiONsPQKVw2KXlkVvxKMyW+8c5XS48kpRQXhNnrzy7+vXl7sA6u+L8k2xV4Y083zD3GvPiOXvX4nWGHF59V48v/8ZhsW2M/MexXZityi+9/H/D47MlZzF+d0N+zr5m9Meh8V0PuP2MXv6jka4D3Gr/MkRXDy+fSSoqZImo87+S0JfZKsFNvaV1SbZv7TIAYhZRWEH8JDgtfrq+atqEF6n7ia8cII7Y7GU+E1WY6ppWcvjatPPoQ+P8h9z0Ks2wILgoKannoISRnhckktsZzetyTs6s0sxrUR+tqQslVs5aP349r+hjA7Pkufc0WVmsyqInOa8i3XgivAedFfGSsGmr5SYkfSx4UTbu4Fi3Mo2rTOJ6enU1vbs8/3RzISy1EWEzvGZXW5TAGWuxA0fVKgIcVasTcFSteq1RSGFdYAqFRj4VxWrG66SVnLu2GFDVDdtUuWoKh7FP03F9ij8d195y6nle80kuA1f1aX6ok52qVBxXsp+SMs1yUvBKd7V8c4Jp+CSKhyHXHruON/FPRfG1szSqS6XV9fxY22cRhaoEdl2FMJtf8/nrwmls6YS7zNkL+2+2XM6iSFCzKP/5J05ZbinPYYl8NQ8pEb7lvEoEXyo+5KxT0dQk/InpWukXccEnGq5oNhfF6Pgak3gpOI8skec25RpFgrlkBlOwBDOVqyfmWUlDwpd4RwrR8/W1KkAmqgzWJcg6xfUqpu0pbnmoBOiuspNSJUjx+/aaoFyJ5gkOf3BhEqm04aoqJZd/YAtf59XrKoI7KvDtLfF5aCG7ygDuKtu3u+JmVXFwD093l0HdVguwvc0Rm6r87Q5ntrPoamt3s+frgRkaHJW+SjOpIb3lh1BqvK6+x2zOOpW2onWDVL6Qa/6bQpOn64KGbLYnnN+ygMt7r2sLtusXsjmaSoSiKqaIuV9up1XVP6aYtVcZZAscrucg6XNMs5SXX/38suIVhV//D987cVOteAAA""", None
    ))
    val parseResponse = TransactionPiiParser(List.empty[Long]).parse(input, Map("1442" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))
    val json = parseResponse.data.payload.get.toString
    json.contains(""""environment_id":1""") shouldBe true
  }

  test("should get expected value when parameters are not present") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""),
                                                        "H4sIANX8YmIC/02NQQ6CMBBFr2K6ttJCKeDORBfGxI0nGNtBG6WQUhaGcHdbiMHdn5f3/4zEO7A9KG9ae9ZkvyGABTAlOM1KyKnIaqQVlzVNCyVlWbNK64JsN//FI3gMVS5zJnMhUi6zMhjQmQt+5s3O0FeIESrVDtbPvzjji3aFJg6QJOQk27Hk1IB5Hwb/vKnWYexpvA+P6IzTcvpg9Ctw2Het7XElHbgw69H9rOkLq3MfpO4AAAA=", None
                                                       )
                                            )
    val actual = TransactionPiiParser(List.empty[Long]).parse(input, Map("101" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))
    (org.joda.time.DateTime.now().getMillis / 1000 - TestUtil.getTetlProcTime(actual).getMillis /1000 < 10) shouldEqual(true)
    val expected = ParserResponse(TransactionPii
                                                                                                   ("ae7a0c41-38a5-43fe-916f-27c668f09dd7", "101", Some("{\"transaction_id\":\"ae7a0c41-38a5-43fe-916f-27c668f09dd7\",\"transaction_date\":\"2022-04-22T19:07:01.638Z\",\"account_id\":\"101\"}")), KinesisStreamTypes.TransactionPiiStream.toString)
    TestUtil.equalWoTetlProcTime(actual, expected) shouldEqual true
  }

  test("should parse addresses") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""),
                                                        "H4sIAPS7cmIC" +
                                                        "/02Qy2rDMBBFf8VoXTeWnYfVXWi7KIVSmj4oVRYTe5yI2JKR5IUJ/veOKkO6m3u4D6EL8xa0g8oro59qdpcwFHkjEJcpCA7pMl+KtBQNT7NNWTS4aUSBK3aT/A8+gEeK8vWKr8t1UZbZRpADevWMY+ikKz3TGWBVmUH7vy2e8Wh7gS4UsAXdi+I2Wzx2oNrt4E+7ylgMuRoPwzF4LlOUnhzuCiy63miHV9KDpVqPNrok60w9tOgkyR/JGgtDLckoGdAQaq8q5cdIMOxb5c5R9iejMcr9X6Cuac/NXVTdKo08CMkKXpTJbtDJJ7QtjsmbgXkmmPJo2r6+J6tI42iA33BWHUTqPP1pxF/b+RGGYHtv6pmLUmT53BG+1M41H7sI/djPzoNqafso2bSf2PQLq3C5NvQBAAA=", None
                                                       )
                                            )

    val parseResponse = TransactionPiiParser(List.empty[Long]).parse(input, Map("101" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))
    implicit val json = Parse.parse(parseResponse.data.payload.get).right.get
    val addresses = extractParameter("addresses")
    val  address = decrypt(addresses.result.right.get.ciphertext,
            addresses.result.right.get.iv,
            addresses.result.right.get.tag,
            addresses.result.right.get.aad
           )
    address shouldBe "[{\"addressType\":\"billing\",\"line1\":\"3138 Sun Valley Road\",\"line2\":\"APT 5\"," +
                     "\"city\":\"Yakima\",\"state\":\"WA\",\"postalCode\":\"98902\",\"country\":\"US\"}]"
  }

  test("should get expected output of pii fields") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""),
      """H4sIAKyuamMC/21UyXKcMBD9FYqzhSUQm09xOT4kcfkyycEVchBS41EMiNKSZMo1/x4JMR5PKiekfq+31y1eU6vZbBi3Us2fRHqTpAxqhjklqGhYiWgxAGpJNaC85lXVDLgVok6vkveOH5kF70qqEldlXhQlLWvPYIv8Aoc15iLRiz8GI+fKzXbNRTCJtEc2hQDptT9fFxm+vp+YHG+d3e+40hD8BPTuOXBej/FqPcOcDRrMomYDZ8vCtA9rQUdWl05KuBFM56/fu3TQzInOE7uU+UQwW8mlPUQLhPxampd4XfZqhnj9Ee4zC22zUYoQrEtJXiBaoqpu2ugQIwXoEX4nT0pvgXpn5AzGhIY93qVGcadhSyrn1ea/PuCWmR0mX9patG9BA5eL9Ia7IKLecnzbXZC/HhaIAOP7iAhpeqcNXMK9HEfv06XHt54j8DMzk7T7D/CHTcsIGVdTjGOsH/XW2NOWVMMvqZzRMICGmcNJFGg5qfGQo74Aimhe9IgVdYFKUQGBts+LodnUUtPC5sMcRfGGO6UXpVeRk3C+Sh4e7rKtFdVvord1i3CJcB2BQWpjzzE+q/18mt7BSM5GJoTfEpNH/HaxWVL+l/E21OQ+CpDsrAawkay0AL9ZYQCB6Gk0K6uAyOUyQJZnRUbPMq2e/M0Rr4o6fa55F1Q/tcldmJZzJz3rRhDeVALhgvl1A0JQ3xQ1qgkrCO8pJTQ/6fluOZzZjM5YNYF2xm+yiJW3aya/U8YrHemvXdelLwcePjeJ1Q48pzs9l3+MW7vry1ihgY0GjjHhOZFfKD+MdaXC0N7JyPdsnmHbOiGfpWVjhJ9BcSU2XSjO6rKsmuYqQTXNMC3bptrebvyfcA3ruohtP3NMMKZ5HiXuJ2nMJdqQPF8HMDKvS6jlHVhjSupjevwLU2cDoR8FAAA=""",


//      "H4sIAIrIcmIC" +
//        "/21UwXKbMBD9FYZzRCQQCHJqJs2hbSYXt4dM6UFIS6wGECOJtp6M/70SwnHc6cnSvre72rfPvKbO8Mly4ZSePsn0Jkk5MI4FJaioeYlo0QNqSNWjnImqqnvcSMnSq+R94kfuwKeSqsRVmRdFSUvmGXxWX+Cw1pwVevHHEBRCL5NbexFMIu2Rj6FAeu3P10WGr+9Hrobbxe13QhsIeRK65TlwXo/x6jzDngMG7KwnC+fIzI0v68BEVpuOWi4D2NZfv7dpb/giW09sU+4bweSUUO4QIxD6G2Vf4nXe6wni9Ue4TzyMzQclQ7E2JXmBaIkqVjcxIVYK0CP8Tp60ORXih9F3Wt/gX2RAqFn5wF3QxGwp33YX5K+HGSLAxT4iUtluMRYu4U4Ng89p0+PbCBH4mdlRuf0H+MPHeYBM6DHWsc5vbnvn09bUwC+lF2ugBwOTgNOM0AjCcJ+jrgCKaF50iBesQKWsgEDT5UVfb8PrcebTYfLqx9Q7bWZtVs2ScL5KHh7usm0U3W0aNqxBuESYRaBXxrpzjc96P52WcbBK8IFL6Zdu84jfzi5Lyv8y3naU3EcBkp0zAC6StZHgjRIWEIieRrOyCoiaLwtkeVZk9CzTmineEvGq6GLOb94F1U9jiiVsa1lOerJaElFXEuGCe/cAIairC4YY4QURHaWE5ic935ljsVtwsU6PYBbrjSnjy5u1k/eU9UpH+mvbtunLQYSfm8SZBTynPbn/n+A27mr0Fer5YOEYG54beUP5ZayWCkt7J6PY82mCzXVSPSvHhwg/gxZabrpQnLGyrOr6KkGMZpiWTV1tf8X4eRAGVrvIzZ85JhjTPI8Sd6Oy9hKtSZ6vCxi41yW85R3IMCXsmB7/AuuCu7HuBAAA",
//                                                        """H4sIAMGkamMC/21TuW7cMBD9FUG1KfPSlSqG4yKJ4WaTwohTUNTIS1sSBR5JFsb+e3h47Q2QRuDc8948vZTOiNUK6ZReP4/lh6IU0AosOUGsEzXibALUk2ZCtJVN0024H8e2vCjOCz8JB6GUNDVuaspYzes2ZIhNfYVD6rkp9Bye0Sml9qtLswgmOe1OLLFBeRnel6zClzeLUPOVd/ud1AZi3QiDf4w5L8dsupBh3x0G7KZXC++eTZjQ1oHJWeWiRz9DNH6UkxF+TOuEGbA6JZVL60EcbJR9Th32eoVk/AzWKiJWMatEE6EM8Ro1bdfH1FQf3Hfwu7jXJpUP3qoVrM3oSqulz1hArcEO39Akb3pYwhJxtZcARKpNBfM68mRS1++7s7Rvhy2hFHKfmFB28MbCeWhQ8xyyy+MJUXQ+VXZRbv8R/ohlm6GSeon11uXrlXf3aYiBX0p7a2ACA6uEDBd6SVo8UTQw4IhTNiDBWobqsQEC/UDZ1CUe9LKJ9bC+HvRam02bRFwR3xfF7e11ldbWQ6Kxb3uEa4STpiZlrDvVftH7NV/hYJUUsxjHcGRLY+xqc1VR/yf6epriJoMsds4AuJiozQhBEJHUKD3KeFU3wa+289KKVqziJyJSjTyV4MiWN6f9dpHNDEX6yL73mau2G4nsmhFhJoJIgBA0dKxFLRGMyIFzwmnm6u3A3iaHt04vYLwNqks/CO2T1qWygcEk44fy+SAfwtMZDxfFQ5byueMVTtRtdE9itpB+iLe25VOgNokh0v9GjtyLdYWklVE9KifmGHoELfWYEHNctXXddN1FgVpeYV73XXP2U0sD6dRjVhTFBGNOaaJtWJS1/8Q6QmmkdBYBdZz/HmoxJ+2xPP4FzbRFe58EAAA=""",
      None))
    val parseResponse = TransactionPiiParser(List.empty[Long]).parse(input, Map("101" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))
    implicit val json = Parse.parse(parseResponse.data.payload.get).right.get

    val userid = extractParameter("user_id")
    val payments = extractParameter("payments")
    val geocode = extractParameter("geocode")
    val company_name = extractParameter("company_name")
    val first_name = extractParameter("first_name")
    val surname = extractParameter("surname")
    val physical_address = extractParameter("physical_address")
    val physical_address2 = extractParameter("physical_address2")
    val city = extractParameter("city")
    val state = extractParameter("state")
    val business_name = extractParameter("business_name")
    val ein = extractParameter("ein")

    decrypt(userid.result.right.get.ciphertext,
            userid.result.right.get.iv,
            userid.result.right.get.tag,
            userid.result.right.get.aad
           ) shouldBe "johnsmith1979"

    decrypt(payments.result.right.get.ciphertext,
            payments.result.right.get.iv,
            payments.result.right.get.tag,
            payments.result.right.get.aad
           ) shouldBe "[{\"paymentType\":\"ach\",\"recipientCountry\":\"US\",\"disbursementType\":\"billpay\"}]"

    decrypt(geocode.result.right.get.ciphertext,
            geocode.result.right.get.iv,
            geocode.result.right.get.tag,
            geocode.result.right.get.aad
           ) shouldBe "40.755688, -74.045986"

    decrypt(company_name.result.right.get.ciphertext,
            company_name.result.right.get.iv,
            company_name.result.right.get.tag,
            company_name.result.right.get.aad
           ) shouldBe "Corporation Corp, LLC."

    decrypt(first_name.result.right.get.ciphertext,
            first_name.result.right.get.iv,
            first_name.result.right.get.tag,
            first_name.result.right.get.aad
           ) shouldBe "John"

    decrypt(surname.result.right.get.ciphertext,
            surname.result.right.get.iv,
            surname.result.right.get.tag,
            surname.result.right.get.aad
           ) shouldBe "Smith"

    decrypt(physical_address.result.right.get.ciphertext,
            physical_address.result.right.get.iv,
            physical_address.result.right.get.tag,
            physical_address.result.right.get.aad
           ) shouldBe "123 Example Street"

    decrypt(physical_address2.result.right.get.ciphertext,
            physical_address2.result.right.get.iv,
            physical_address2.result.right.get.tag,
            physical_address2.result.right.get.aad
           ) shouldBe "Apt. 5"

    decrypt(city.result.right.get.ciphertext,
            city.result.right.get.iv,
            city.result.right.get.tag,
            city.result.right.get.aad
           ) shouldBe "New York"

    decrypt(state.result.right.get.ciphertext,
            state.result.right.get.iv,
            state.result.right.get.tag,
            state.result.right.get.aad
           ) shouldBe "NY"

    decrypt(business_name.result.right.get.ciphertext,
      business_name.result.right.get.iv,
      business_name.result.right.get.tag,
      business_name.result.right.get.aad
    ) shouldBe "socure"

    decrypt(ein.result.right.get.ciphertext,
      ein.result.right.get.iv,
      ein.result.right.get.tag,
      ein.result.right.get.aad
    ) shouldBe "ein123"
  }

  test("parse ipaddress pased in param as string") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""),
                                                        "H4sIALv7+2IC/01Ou27EIBD8lRN1bAN+p4uUFFGkNClDijWs79DZYAGWcjr53wN2celmZuexdxIcGA8yaGveFXk+ReE3A2yByoplZQd1VpUjZj1rxoy3smm6kfZKteTp9D/8CgFTnDU1bWpelnVV7x5Y9Afe0imia0RJk9KuJuyDjLLD9Qnz3lBEXJQ5Ld5m0NPLGi5f0jpMOYXDek6e+3bQEB3+ITj0izUeH8oCLtYGdIdLkNmqdUIvIv0WZHSwKhGNgkAcQhO01OF2KJj2nfbXgy4Xa/CgP4nPdtATmnUe0KU6xinjfddWHUtnvYBS8aF9ShDW9Tlnbd7znHEuyEa2P7zNbpN9AQAA", None))
    val parseResponse = TransactionPiiParser(List.empty[Long]).parse(input, Map("101" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))
    implicit val json = Parse.parse(parseResponse.data.payload.get).right.get

    val ipaddress = extractParameter("ip_address")

    decrypt(ipaddress.result.right.get.ciphertext,
            ipaddress.result.right.get.iv,
            ipaddress.result.right.get.tag,
            ipaddress.result.right.get.aad
           ) shouldBe "189.217.92.122"

  }

  test("parse ipaddress pased in param as set of string") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""),
                                                        "H4sIAGX8+2IC/02OvU7EMBCEX+XkmiS28+fQIUGBkGgoCcXG3nDWJXbkOBKnU94dOxY6up1vZ2f2RrwDs4L02ppXRR5PAfxkgC1QWbGsFFBnVTli1rFmzHgrm0aMtFOqJQ+n/8fP4DGes6amTc3Lsq7qwwOLfsNrXIXpEqbIpLSb8Uchoyy53mE+EoowF2VOi5cZ9PS0+fOHtA7jncJh+46e256kD471DhyuizUr3skCLsR6dMnVk9mqbcK1D/KzJ6ODTfXB2BMIRWi8ltpfE8HY7/R6SXI5W4NJfkU920FPaLZ5QBfjGKeMd6KtBItrvYBS4aG/Kia6nLM273jOOE+RTASUSAjdyf4L6g44q5ABAAA=", None))
    val parseResponse = TransactionPiiParser(List.empty[Long]).parse(input, Map("101" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))
    implicit val json = Parse.parse(parseResponse.data.payload.get).right.get

    val ipaddress = extractParameter("ip_address")

    decrypt(ipaddress.result.right.get.ciphertext,
            ipaddress.result.right.get.iv,
            ipaddress.result.right.get.tag,
            ipaddress.result.right.get.aad
           ) shouldBe "189.217.92.122|18.21.92.12"

  }

  test("parse addresses passed in param as address") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""),
                                                        "H4sIAJMA/GIC/01Qy07DMBD8lchnksbOu7cKioQQFVLhRDg48aa1msTBcaRWKP/Oug6Ug6Xd2ZnZ8X4To3k/8tpI1T8JsvYQOPscMh7WMfWjnCd+HDXgFzRtfJbVaZo3YSFERu68/+IHbsDKaZqEacKiKImTK4cP8hkudoTVCSuL1bWaenNdSEPqWDveXR1WWK+iIFxtOy7bzWSO+1ppsDoB1XSwnO/ZtQYZ4w3QMA6qH+GGDFyjrQHtWCXplJhaGEtsP0rSaD6JEokl4bgIeiNraS4OAbtfy/Hk2uGoenDtp+07VckW+qmrQFs7ykLKijyLc2rHcuBCYKDfVTQvAkazoGABZcxZ0hwhhyymi8YFxLguzRonm7aavibQ+Jx4NHhyN9u9OOh6Vb0I3vcObGUP1EFxknqPUo/G2555N7Tg7Y0GMMsHFVq290osrmH2F9R6sCXH65uXONRchoWKl0DKoSTzTOYfHr5+nVUCAAA=", None))
    val parseResponse = TransactionPiiParser(List.empty[Long]).parse(input, Map("101" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))
    implicit val json = Parse.parse(parseResponse.data.payload.get).right.get

    val addresses = extractParameter("addresses")

    decrypt(addresses.result.right.get.ciphertext,
            addresses.result.right.get.iv,
            addresses.result.right.get.tag,
            addresses.result.right.get.aad
           ) shouldBe "[{\"addressType\":\"billing\",\"line1\":\"456 First Example Street\",\"line2\":\"APT 5\"," +
                      "\"city\":\"Albuquerque\",\"state\":\"NM\",\"postalCode\":\"07122\",\"country\":\"US\"}]"

  }

  test("parse addresses pased in param as set of address") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""),
                                                        "H4sIAHoB/GIC/7VQy07DMBD8lShn0sbOu7cKioQQFVLhUJEe3HjTWk3i4DiiVdV/Z10HCgKOHCztzs7MjvfoasWajhVayOaOuxMHgb3HIGF+ERIvSFnkhUEJXkbi0qNJEcdp6WecJ+6V81V8wzQYOYkjP45oEERhdOawVtzDwYyw2mFlsKKQfaPPC4lPLGvO6rPDGOtxMPLHs5qJatrr7aKQCoyOw7rfGM7xZFuNjO4CKOha2XRwQVqm0FaDsqzcrSXvK+hybF9yt1Ss5zkSc5fhImi0KIQ+WATMfiW6nW3brWzAtivT13ItKmj6eg3K2BHqE5qlSZgSMxYt4xwDfawiaTaiJBlldEQotZYkRcgig+mgGQJiXhtngqNpte5fe1D4rLrTeHM7mz9Y6HxWNQieFxasRAPEQmEUO7dCddqZ7VndVuAstALQww8lWlbXkg+ufvKZ1HjQIcfjkxNZVB/agYqnQMomd09XzrfUc3hbSrX7mXj5X4mDXxMnfydendzTOzYFN5sJAwAA", None))
    val parseResponse = TransactionPiiParser(List.empty[Long]).parse(input, Map("101" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))
    implicit val json = Parse.parse(parseResponse.data.payload.get).right.get

    val addresses = extractParameter("addresses")

    decrypt(addresses.result.right.get.ciphertext,
            addresses.result.right.get.iv,
            addresses.result.right.get.tag,
            addresses.result.right.get.aad
           ) shouldBe "[{\"addressType\":\"billing\",\"line1\":\"456 First Example Street\",\"line2\":\"APT 5\"," +
                      "\"city\":\"Albuquerque\",\"state\":\"NM\",\"postalCode\":\"07122\",\"country\":\"US\"},{\"addressType\":\"billing\",\"line1\":\"456 First Example Street\",\"line2\":\"APT 7\",\"city\":\"NewYork\",\"state\":\"NY\",\"postalCode\":\"07123\",\"country\":\"US\"}]"

  }

  test("parse physical address in json format for sandbox") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""),
                                                        "H4sIABWgeWQC/12QXU+DMBSG/wrp9XAwGPu4M8rFotFE8MKIF7U9bM1G27RFgwv/3VOqmZGrnue8H+GciTNUWsqcUHLHyTYiFFY0YXkaZ2u6jPOshXiTFm28WLGiWLfJhvMVmUUE5IcwSnYgXT1oQGuG9E/cLXWepukiy5fFMsct1eIOhqlFi/iITw8ZU710U3saRA+081Yyx/c8u0rmZUfF6bp3h4opA97F4b3fe815DKNDhb0AA1YraeFCNDUY68AEVUM6xfsT2AbH14a0hva8QWFDKBbhbwkm3BAI+H4j7DGM+qAkhPEtzIMVjJ4o59g7JWJ+sG9xf7OrX9Jg/RI6sMR/gVmHpwqUHTBnr365AXD3QsKj/Nn7Y86iuqzqqKqfyrIOyumC5qftufpvrz9VWC0aMo5k/AZk1nSI9wEAAA==", None

                                                       )
                                            )
    val parseResponse = TransactionPiiParser(List.empty[Long]).parse(input, Map("1" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))
    implicit val json = Parse.parse(parseResponse.data.payload.get).right.get

    val physicaladdress = extractParameter("physical_address")

    decrypt(physicaladdress.result.right.get.ciphertext,
            physicaladdress.result.right.get.iv,
            physicaladdress.result.right.get.tag,
            physicaladdress.result.right.get.aad
           ) shouldBe "{\"city\":\"CITY1\",\"zip\":\"00000\",\"state\":\"chicago\",\"streetLineOne\":\"1234, TEST " +
                      "STREET\",\"country\":\"US\",\"streetLineTwo\":\"2\"}"
  }

  test("account in payment node should be expected") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""),
                                                        "H4sIAF+PdmMC/32QX2+CMBTFv4rp85ggAro3M01GlqgRtz2ID6W9aCMU1j9LiOG7r1A23cvees79nXPbXpESmEtMFKt4TNHTCGGIsEumnuPPcOBM/RycuRfmziQiYTjL3TmlEXoY3QeXWIGJemHghsHE94NpEBkC1+wVmr6zZs7FHDuTkEpz1e/yXM9ia1x2BWhszmP/0R2vSsyKhVbnhFQCuhyFTJ865tpaqQwhb4YAWVdcws2psTC1CoSlUlRWVBcgUyMPKcoF1jQ1YIqwWQRcMcJUYx3o9gsmL1bW54qDlcde46Y0gb7KFAsgrGbGeO6eJprOTtFbMoQtvG9qsANMznZCmcy0kPB3nLGiMJnhava7hkWDWusyA2Hpw3a3eY+Xq+XRBkSlFeOn/xDGPzUT7Pcnkv1i/3PZzcd6tUte4u3w0i9cMBrfB5TQ0LYtar8BYbs6vTwCAAA=", None))
    val parseResponse = TransactionPiiParser(List.empty[Long]).parse(input, Map("101" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))
    implicit val json = Parse.parse(parseResponse.data.payload.get).right.get
    val payments = extractParameter("payments")
    decrypt(payments.result.right.get.ciphertext,
            payments.result.right.get.iv,
            payments.result.right.get.tag,
            payments.result.right.get.aad
           ) shouldBe "[{\"paymentType\":\"ach\",\"recipientCountry\":\"US\",\"disbursementType\":\"billpay\"," +
                      "\"account\":{\"accountNumber\":\"[PROVIDED]\",\"routingNumber\":\"[PROVIDED]\"," +
                      "\"inquiries\":[\"STATUS\",\"OWNERSHIP\"],\"validInquiries\":true}}]"
  }

  test("shipping details and merchant details should be expected") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""), "H4sIAEi3v2QC/1VRTW/bMAz9K4YOu2xOLH/Izk4zmqDINvSQYgOGeQdNom2htmVIcoqg8H+fFKlIdiMfHx/JxzdkFJ00ZUbI6cjR5whRKGnCchxnFS3iPGsh3mHSxmnJCKnaZMd5iT5F9417asC2YrJL0iQp8hwXxDLoLL7B5ao5i/jFhg5kTC6Tuc5KE+xpT3R0Amhr4222SbaHkYqhXkz/zKQC18fh79I5ztvqU2MZ+gYo0LOcNNyQmSora0B5VoNGyZcBdGPT3w1qFV14Y4kNonYQTEYwYS4eATdfCf3i07mXE/j0z7WBcztPBy0rPYgJsEsaRDAuI1KZPqrP4NtdNfXVejZR/uhhP86hJ8E7eJUy7KONNdRXnn6FDaQFhwfJA45xVtnvkDQJWs5UFeR+PHvQXOZA172YZzF1DVqvB7zne2+jI9krWqG0cb/wTT/r74fT8RB2WtSt8lifHo71nVUePtNh01HFBP1C5bBhcryzz1M+4iwvCS7yNC3sMq46gmI9ncz/uwgeDCirHanScKX1pZPvZ+7F2T5XtAJ49BVeYVCX6ENUM2ZfI5Vw31lXtP4DyAn0meQCAAA=", None))
    val parseResponse = TransactionPiiParser(List.empty[Long]).parse(input, Map("201" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))
    implicit val json = Parse.parse(parseResponse.data.payload.get).right.get
    val addresses = extractParameter("addresses")
    decrypt(addresses.result.right.get.ciphertext,
      addresses.result.right.get.iv,
      addresses.result.right.get.tag,
      addresses.result.right.get.aad
    ) shouldBe "[{\"addressType\":\"shipping\",\"line1\":\"6117 68th Ave\",\"line2\":\"Apt 4G\",\"city\":\"Ridgewood\",\"state\":\"NY\",\"postalCode\":\"11385-4620\",\"country\":\"US\"}]"

    val shippingDetails = extractParameter("shipping_details")
    decrypt(shippingDetails.result.right.get.ciphertext,
      shippingDetails.result.right.get.iv,
      shippingDetails.result.right.get.tag,
      shippingDetails.result.right.get.aad
    ) shouldBe "{\"firstName\":\"VALERIE\",\"surName\":\"GARCIA\",\"email\":\"val.garcia@aol.com\",\"phone\":\"+13476154225\"}"

    val merchantDetails = extractParameter("merchant_details")
    val r = decrypt(merchantDetails.result.right.get.ciphertext,
      merchantDetails.result.right.get.iv,
      merchantDetails.result.right.get.tag,
      merchantDetails.result.right.get.aad
    ) shouldBe "{\"id\":\"N789682\",\"category\":\"Diversified Jewelry & Accessories\"}"
  }

  test("shipping details should not be passed as type is not shipping") {
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""), "H4sIAKC8v2QC/1VRTW/bMAz9K4YOu2xOLH/Izk4zmqDINvSQYgOGeQdVkm2htmVIcoqg8H8fFWlIdiMfHx8fyXdkNZ0MZVaq6cjR5whRUdKE5TjOKlrEedaKeIdJG6clI6Rqkx3nJfoU3TfuqRXQiskuSZOkyHNcEGDQWX4Tl6vmLONXCB3ImFome52VJtjTnujoBNAW4m22SbaHkcqhXmz/zJQWro+Ll6VznPfVpxYY5gZoYWY1GXFDZqpB1grtWQ0aFV8GYRpIfzeo1XThDRAbRGGQmKxk0l48Itx8Lc2rT+deTcKnf64NnMM8E7RAepCTwC5pEMG4jEhl+6g+C9/uqqmv1rON8kcP+3EOPUneiTelgh9j4aC+8vQrOFAADg+KBxzjrILvkDQJWu6oOsj9ePagvcyB/iIHMNE1aL36N72cZ8j3/oqOA0u0UhvrXuF7ftbfD6fjIVha9K3yWJ8ejvXdpTx8psOmo5pJ+oWqYcPUeHc9T/mIs7wkuMjTtAAzrjoKzXo62f+9SB72L6sdqdKwJJylU/+23Msz/Fa2UvDoq3gTg75EH6KaMfiM0tI9Z13R+hcJh9094wIAAA==", None))
    val parseResponse = TransactionPiiParser(List.empty[Long]).parse(input, Map("201" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))
    implicit val json = Parse.parse(parseResponse.data.payload.get).right.get
    val addresses = extractParameter("addresses")
    decrypt(addresses.result.right.get.ciphertext,
      addresses.result.right.get.iv,
      addresses.result.right.get.tag,
      addresses.result.right.get.aad
    ) shouldBe "[{\"addressType\":\"billing\",\"line1\":\"6117 68th Ave\",\"line2\":\"Apt 4G\",\"city\":\"Ridgewood\",\"state\":\"NY\",\"postalCode\":\"11385-4620\",\"country\":\"US\"}]"

    try {
      val shippingDetails = extractParameter("shipping_details")
      decrypt(shippingDetails.result.right.get.ciphertext,
        shippingDetails.result.right.get.iv,
        shippingDetails.result.right.get.tag,
        shippingDetails.result.right.get.aad
      ) shouldBe "{\"firstName\":\"VALERIE\",\"surName\":\"GARCIA\",\"email\":\"val.garcia@aol.com\",\"phone\":\"+13476154225\"}"
    } catch {
      case ex: NoSuchElementException => ex.isInstanceOf[NoSuchElementException] shouldBe(true)
    }
  }

  test("shipping detail should be passed if addresses has more than one address and has type shipping") {
    val msg = "H4sIAL/Cv2QC/9VSy27bMBD8FYGHXhrboh6U3FOF2AjcFjk4SIGi6oEhVxIRWRRIyoER6N9LigzsfkJv3NnZ2eHuviOj6KApM0IOB46+RIhCQWOW4VVa0nyVpQ2stpg0q6RghJRNvOW8QHfRbeGOGrClmGzjJI7zLMM5sQw6iu9wWTRHsXq1TwcyJqfBLL2SGHvaIz05AbSx7026jjf7ExV9NZnuiUkFro7Dy9Q6zvvsQ2MZ+goo0KMcNFyRkSora0B5Vo1Okk896NqGv2vUKDrx2hJrRG0jGIxgwlw8Aq6/EvrVh2MnB/Dhn6WAc9tPBy0r3YsBsAtqRDAuIlKaLqrO4MtdNvHZajRR9uBh386hR8FbeJMy+NHGDtRnHn8FB9KC/b3kAcc4Le12SBIHLTdUFeSenzxoLmOgv4jemmhrNN9F/4Fd3Ylx9H6XeX/EO791R7K/aITSxp2OL/pZ/dgfD/vgaVLXzEN1vD9UN5v18Jn265YqJuhXKvs1k6ebbXvKZ5xmBcF5liT5Mjx7RaBYRwfzrxfBwwCKckvKJPzSzqWVH9/cibO9RdEI4NE3eINeXaJPUcWYvSSphDumeUbzX9kbKHyTAwAA"
    val input = TransactionInputParser.parse(WrappedMsg(MessageId("1", ""), msg, None))
    val parseResponse = TransactionPiiParser(List.empty[Long]).parse(input, Map("201" -> HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")))
    implicit val json = Parse.parse(parseResponse.data.payload.get).right.get
    val addresses = extractParameter("addresses")
    decrypt(addresses.result.right.get.ciphertext,
      addresses.result.right.get.iv,
      addresses.result.right.get.tag,
      addresses.result.right.get.aad
    ) shouldBe "[{\"addressType\":\"billing\",\"line1\":\"6117 68th Ave\",\"line2\":\"Apt 4G\",\"city\":\"Ridgewood\",\"state\":\"NY\",\"postalCode\":\"11385-4620\",\"country\":\"US\"},{\"addressType\":\"shipping\",\"line1\":\"6117 68th Ave\",\"line2\":\"Apt 4G\",\"city\":\"Ridgewood\",\"state\":\"NY\",\"postalCode\":\"11385-4620\",\"country\":\"US\"}]"
    val shippingDetails = extractParameter("shipping_details")
    decrypt(shippingDetails.result.right.get.ciphertext,
      shippingDetails.result.right.get.iv,
      shippingDetails.result.right.get.tag,
      shippingDetails.result.right.get.aad
    ) shouldBe "{\"firstName\":\"VALERIE\",\"surName\":\"GARCIA\",\"email\":\"val.garcia@aol.com\",\"phone\":\"+13476154225\"}"
  }

  def extractParameter(param: String)(implicit json: Json) = {
    (json.hcursor --\ param).as[Dcrpt]
  }

  def decrypt(ciphertext: String, iv: String, tag: String, aad: String) = {
    Decryption().decryptRaw(
                              ciphertext,
                              iv,
                              tag,
                              aad,
                              HexadecimalFactory.convertHexStrToBytes("f5b44f9b1e43aa596d3565c26d214cb83a6cfb34e636002667729ff9ec7be290")
                            )
  }

  private implicit
  val decodeAll: DecodeJson[Dcrpt] = DecodeJson {
    h =>
    for {
      ciphertext <- (h --\ "ciphertext").as[String]
      iv <- (h --\ "iv").as[String]
      tag <- (h --\ "tag").as[String]
      aad <- (h --\ "aad").as[String]
    } yield Dcrpt(
                   ciphertext = ciphertext,
                   iv = iv,
                   tag = tag,
                   aad = aad
                 )
  }
}

case class Dcrpt(ciphertext: String, iv: String, tag: String, aad: String)
