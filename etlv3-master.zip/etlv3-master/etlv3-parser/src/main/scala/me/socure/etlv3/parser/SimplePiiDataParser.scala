package me.socure.etlv3.parser

import me.socure.etlv3.common.{ParserResponse, TransactionInput}

trait SimplePiiDataParser[In0 <: TransactionInput, In1 <: Map[String, Array[Byte]], Out <: ParserResponse] {
  def parse(in0: In0, in1: In1): Out
}
