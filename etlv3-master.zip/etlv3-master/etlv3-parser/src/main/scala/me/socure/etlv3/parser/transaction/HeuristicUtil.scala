package me.socure.etlv3.parser.transaction

import java.util.regex.Pattern

import com.google.common.base.Strings
import me.socure.etlv3.common.MobileNumber
import me.socure.etlv3.parser.util.IpAddressMatcherUtil
import me.socure.etlv3.parser.util.ParserUtil.{dateFormat, dateFormatAlt, dateValidator}
import org.apache.commons.lang3.time.DateFormatUtils
import org.slf4j.LoggerFactory
import scala.util.{Failure, Success, Try}

object HeuristicUtil {
  private val logger                = LoggerFactory.getLogger(getClass)
  private val VALID_SSN_FORMATS = Set(
                                       Pattern.compile("\\d\\d\\d-\\d\\d-\\d\\d\\d\\d"),
                                       Pattern.compile("\\d\\d\\d\\d"),
                                       Pattern.compile("\\d\\d\\d\\d\\d\\d\\d\\d\\d")
                                     )
  val allowedIpDomainRange: Set[String] = Set("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16")
  def extractDomain(str: Option[String]): Option[String] = {
    val parts = str.getOrElse("") split "@"
    if (parts.length == 2) Some(parts(1)) else None
  }

  def validateDate(date: String): Boolean =
    if (Strings.isNullOrEmpty(date) ||
        (dateValidator.isValid(date, DateFormatUtils.ISO_DATE_FORMAT.getPattern) ||
         dateValidator.isValid(date, dateFormat) ||
         dateValidator.isValid(date, dateFormatAlt))) true
    else false

  def ipInRange(ipAddress: Option[String]): Boolean = {
    Try{
      if(ipAddress.getOrElse("").contains(",")) {
        val ipaddressList = ipAddress.get.split(",").toList
        val resultSet = ipaddressList.foldLeft(List.empty[Boolean]) { (s,v) =>
          if(allowedIpDomainRange.exists(IpAddressMatcherUtil.isIpInRange(v, _)))
            s ++ List(true)
          else {
            s ++ List(false)
          }
        }
        if(resultSet.contains(false)) false
        else true
      } else {
        allowedIpDomainRange.exists(IpAddressMatcherUtil.isIpInRange(ipAddress.getOrElse(""), _))
      }
    } match {
      case Success(flag) => flag
      case Failure(ex) =>
      logger.info(s"Error occurred while trying to parse ip ${ex}")
      false
    }
  }

  def isAlternate(mobileNumber: String): Boolean = {
    val result = for {
      x <- 0 until mobileNumber.toCharArray.size by 2
      y <- 1 until mobileNumber.toCharArray.size by 2
      resX <- List() :+ List(mobileNumber.charAt(x))
      resY <- List() :+ List(mobileNumber.charAt(y))
    } yield {
      (resX, resY)
    }
    result.map(x=>x._1).distinct.length == 1 &&
    result.map(x=>x._2).distinct.length == 1 &&
    result.map(x=>x._1).flatten.head != result.map(x=>x._2).flatten.head
  }

  def isAllSame(mobileNumber: String): Boolean = {
    val res = for {
      x <- 0 until mobileNumber.size - 1
      res = false
      if (mobileNumber.charAt(0) != mobileNumber.charAt(x))
    } yield res
    if(res.nonEmpty && !res.head) false
    else true
  }

  def isAllOne(mobileNumber: String): Boolean = {
    val res = for {
      x <- 0 until mobileNumber.size - 1
      res = false
      if ('1' != mobileNumber.charAt(x))
    } yield res
    if(res.nonEmpty && !res.head) false
    else true
  }

  def extractMobileInfo(mobile: Option[String]): Option[(MobileNumber)] = {
    mobile match {
      case Some(x) if(x.trim.size >= 0) =>
      val trimmedMobileNumber = if(x.trim.startsWith("+1")) x.trim.replace("+1","").replace("-", "") else if(x.trim.startsWith("+")) x.trim.replace("+","").replace("-", "") else x.trim.replace("-", "")
      Some(MobileNumber(
                         isInSeq = trimmedMobileNumber.equals("1234567890")  || trimmedMobileNumber.equals("+11234567890"),
                         isAllOne = isAllOne(trimmedMobileNumber),
                         isAllSame = isAllSame(trimmedMobileNumber),
                         isAlternate = isAlternate(trimmedMobileNumber),
                         sizeOfMobileNumber = trimmedMobileNumber.size
                       ))
      case _  => None
    }
  }

  def getSSNSize(ssn: Option[String]): Int = ssn.getOrElse("").replace("-", "").size

  def isValidSSN(ssn: Option[String]): Boolean = {
    ssn match {
      case Some(x) =>
      if (!Strings.isNullOrEmpty(x)) {
        VALID_SSN_FORMATS.exists(p => {
          p.matcher(x.trim).matches()
        })
      } else false
      case _ => false
    }

  }

  def isAllOneOrZero(ssn: Option[String], digit: Char): Boolean = {
    ssn match {
      case Some(ssnNo) if ssnNo.trim.nonEmpty =>
      val ssn = ssnNo.replace("-", "")
      val res = for {
        x <- 0 until ssn.size - 1
        res = false
        if (digit != ssn.charAt (x))
      } yield res
      if (res.nonEmpty && ! res.head) false
      else true
      case _ => false
    }
  }

}
