package me.socure.etlv3.parser.modelscore

import argonaut.{ACursor, DecodeJson, DecodeResult}
import me.socure.etlv3.common.{KinesisStreamTypes, ModelScoreOutput, ParserResponse, TransactionInput}
import me.socure.etlv3.parser.SimpleDataParser
import me.socure.etlv3.parser.modelscore.AssociationTypes._
import me.socure.etlv3.parser.modelscore.ModelTypes._
import org.json4s.{DefaultFormats, Formats}
import me.socure.etlv3.parser._

class ModelScoreParser extends SimpleDataParser[TransactionInput, ParserResponse] {

  private implicit val formats: Formats = DefaultFormats

  private implicit
  val decodeModelScore: DecodeJson[ModelScore] = DecodeJson {
    h =>
    for {
      modelName <- (h --\ "model" --\ "name").as[Option[String]]
      modelVersion <- (h --\ "model" --\ "version").as[Option[String]]
      modelIdentifier <- (h --\ "model" --\ "identifier").as[Option[String]]
      modelId <- {
        val modId = (h --\ "model" --\ "id").as[Option[Long]]
        if (modId.isError) DecodeResult.ok(None)
        else modId
      }
      originalScore <- {
        val orgScore = (h --\ "originalScore").as[Option[Double]]
        if (orgScore.isError) DecodeResult.ok(None)
        else orgScore
      }
      quantileScore <- {
        val qScore = (h --\ "quantile").as[Option[Double]]
        if (qScore.isError) DecodeResult.ok(None)
        else qScore
      }
      outputScore <- {
        val opScore = (h --\ "score").as[Option[Double]]
        if (opScore.isError) DecodeResult.ok(None)
        else opScore
      }
    } yield ModelScore(
                        modelName = modelName,
                        modelVersion = modelVersion,
                        modelIdentifier = modelIdentifier,
                        associationType = None,
                        modelType = None,
                        modelId = modelId,
                        originalScore = originalScore,
                        quantileScore = quantileScore,
                        outputScore = outputScore
                      )
  }

  private
  def parseModelScore(
                       cursor         : ACursor,
                       associationType: AssociationType,
                       modelType      : ModelType
                     ): DecodeResult[Option[ModelScore]] = {
    cursor
    .focusSafe
    .map(_.as[ModelScore].map(_.copy(associationType = Some(associationType), modelType = Some(modelType))))
    .lift
  }

  override
  def parse(input: TransactionInput): ParserResponse = {
    val debug = input.payload.hcursor --\ "debugJson"
    val decodeResult = for {
      fraudPrimary <- parseModelScore(debug --\ "fraud_score_info" --\ "primary", Primary, Fraud)
      fraudSigma <- parseModelScore(debug --\ "fraud_score_info" --\ "sigma", Sigma, Fraud)
      fraudCustoms <- (debug --\ "fraud_score_info" --\ "custom").focusSafe.map(_.as[Map[String, ModelScore]].map {
        kv => kv.map {
          case (k, v) => k -> v.copy(associationType = Some(Custom), modelType = Some(Fraud))
        }
      }
                                                                               ).lift
      addressRisk <- parseModelScore(debug --\ "risk_score_info" --\ "address", Primary, AddressRisk)
      emailRisk <- parseModelScore(debug --\ "risk_score_info" --\ "email", Primary, EmailRisk)
      phoneRisk <- parseModelScore(debug --\ "risk_score_info" --\ "phone", Primary, PhoneRisk)
      nameAddressCorrelation <- parseModelScore(debug --\ "correlation_score_info" --\ "name_address", Primary,
                                                NameAddressCorrelation)
      nameEmailCorrelation <- parseModelScore(debug --\ "correlation_score_info" --\ "name_email", Primary,
                                              NameEmailCorrelation)
      namePhoneCorrelation <- parseModelScore(debug --\ "correlation_score_info" --\ "name_phone", Primary,
                                              NamePhoneCorrelation)
      syntheticCustoms <- (debug --\ "synthetic_score_info" --\ "custom").focusSafe.map(_.as[Map[String, ModelScore]]
                                                                                          .map {
        kv => kv.map {
          case (k, v) => k -> v.copy(associationType = Some(Custom), modelType = Some(Synthetic))
        }
      }
                                                                                       ).lift
    } yield {
      val modelScores = Set(
                             fraudPrimary,
                             fraudSigma,
                             addressRisk,
                             emailRisk,
                             phoneRisk,
                             nameAddressCorrelation,
                             nameEmailCorrelation,
                             namePhoneCorrelation
                           ).flatten ++
                        fraudCustoms.map(_.values).getOrElse(Iterable.empty) ++
                        syntheticCustoms.map(_.values).getOrElse(Iterable.empty)
      modelScores.filterNot(_.isEmpty)
    }
    val models = decodeResult.result.orError("ModelScore Parsing Error", input.transactionId)

    val result = models.map {
      model =>
      Map(
           "transaction_id" -> input.transactionId,
           "model_identifier" -> model.modelIdentifier.getOrElse(""),
           "account_id" -> input.accountId.map(acctid => acctid.toString).getOrElse(""),
           "transaction_date" -> input.transactionDate.toString,
           "environment_id" -> input.environmentId,
           "run_id" -> (input.payload.hcursor --\ "runId").focusSafe.map(_.as[Option[String]]).lift.map(_.flatten)
             .orError("runId", input.transactionId),
           "model_name" -> model.modelName,
           "model_version" -> model.modelVersion,
           "model_association_type" -> model.associationType.map(_.id),
           "model_type" -> model.modelType.map(_.id),
           "original_score" -> model.originalScore,
           "quantile_score" -> model.quantileScore,
           "output_score" -> model.outputScore,
           "model_id" -> model.modelId,
           "country" -> input.country,
           "tetl_proc_time" -> input.tetlProcTime.toString
         )
    }

    ParserResponse(
                    data = ModelScoreOutput(
                                             transactionId = input.transactionId,
                                             accountId = input.accountId.map(acctid => acctid.toString).getOrElse(""),
                                             payload = Some(trimSquareFoldJson(org.json4s.jackson.Serialization.write
                                             (result)))
                                           ),
                    streamType = KinesisStreamTypes.ModelScoreStream.toString
                  )
  }

  def trimSquareFoldJson(json: String): String = {
    if (!json.isEmpty || !json.equals("[]") || !json.equals("{}"))
      json.substring(1, json.length - 1)
    else
      json
  }
}

object ModelScoreParser {
  def apply(): ModelScoreParser = {
    new ModelScoreParser()
  }
}
