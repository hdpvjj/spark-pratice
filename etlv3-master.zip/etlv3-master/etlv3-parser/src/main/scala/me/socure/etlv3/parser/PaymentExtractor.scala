package me.socure.etlv3.parser

import argonaut.DecodeJson
import me.socure.etlv3.common.{Account, JsonValue, Payment, TransactionInput}
import org.json4s.{DefaultFormats, Formats}

object PaymentExtractor {
  implicit val jsonFormats: Formats = DefaultFormats

  private implicit val decodeAccount: DecodeJson[Account] = DecodeJson { h =>
  for {
    accountNumber  <- (h --\ "accountNumber").as[Option[JsonValue[String]]]
    routingNumber  <- (h --\ "routingNumber").as[Option[JsonValue[String]]]
    inquiries      <- (h --\ "inquiries").as[Option[Set[String]]]
    validInquiries <- (h --\ "validInquiries").as[Option[JsonValue[Boolean]]]
  } yield Account(
                   accountNumber  = accountNumber,
                   routingNumber  = routingNumber,
                   inquiries      = inquiries,
                   validInquiries = validInquiries
                 )

  }

  private implicit val decodePayment: DecodeJson[Payment] = DecodeJson { h =>
  for {
    paymentType <- (h --\ "paymentType").as[Option[JsonValue[String]]]
    recipientCountry <- (h --\ "recipientCountry").as[Option[JsonValue[String]]]
    disbursementType <- (h --\ "disbursementType").as[Option[JsonValue[String]]]
    account <- (h --\ "account").as[Option[Account]]
  } yield Payment(
                   paymentType = paymentType,
                   recipientCountry = recipientCountry,
                   disbursementType = disbursementType,
                   account = account
                 )
  }

  def extractFromPayload(trxInput: TransactionInput, param: String) = {
    (trxInput.payload.hcursor --\ "parametersJson" --\ param)
  }

  def extractPaymentParameter(trxInput: TransactionInput, param: String) = {
    extractFromPayload(trxInput: TransactionInput, param: String).focusSafe
    .map(_.as[Payment])
    .lift
    .map(_.toList)
    .result.orError(param,
                    trxInput.transactionId)
  }


}
