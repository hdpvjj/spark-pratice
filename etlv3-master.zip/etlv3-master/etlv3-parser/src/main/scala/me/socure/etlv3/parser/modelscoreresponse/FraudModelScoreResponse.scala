package me.socure.etlv3.parser.modelscoreresponse

case class FraudModelScoreResponse(
                                    name: Option[String],
                                    version: Option[String],
                                    score: Option[Double]
                                  ) {
}
