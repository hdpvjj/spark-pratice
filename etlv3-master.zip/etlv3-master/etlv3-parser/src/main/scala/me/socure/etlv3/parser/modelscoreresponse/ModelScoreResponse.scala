package me.socure.etlv3.parser.modelscoreresponse

import me.socure.etlv3.common.ModuleTypes.ModuleType


case class ModelScoreResponse(
                               moduleType: Option[ModuleType],
                               modelName: Option[String],
                               modelVersion: Option[String],
                               fieldValidations: Option[String],
                               score: Option[Double]
                             ) {
  def isEmpty: Boolean = score.isEmpty
}
