package me.socure.etlv3.parser.docv

import me.socure.dapl.snowflake.crypto.Encryption
import me.socure.etlv3.common._
import me.socure.etlv3.parser.{SimplePiiDataParser, _}
import org.json4s.{DefaultFormats, Formats}
import org.slf4j.LoggerFactory

import java.nio.charset.StandardCharsets
import scala.collection.immutable.ListMap

class DocVParser(nonConsentingAccounts: List[Long]) extends SimplePiiDataParser[TransactionInput, Map[String,
  Array[Byte]], ParserResponse] {

  implicit val jsonFormats: Formats = DefaultFormats
  private val logger = LoggerFactory.getLogger(getClass)

  override
  def parse(in0: TransactionInput, in1: Map[String, Array[Byte]]): ParserResponse = {
    val encrypter = Encryption()
    val encData = in0.accountId.map(acctid => acctid.toString) match {
      case Some(actId) => in1.get(actId) match {
        case Some(key) => (key, actId.getBytes(StandardCharsets.UTF_8))
        case _ => throw new Exception(s"For trxId ${in0.transactionId} account id $actId DataKey not found")
      }
      case _ => throw new Exception(s"For trxId ${in0.transactionId} account id not found")
    }
    logger.info(s"key length is = ${encData._1.length}")
    val transaction = ListMap(
      "transaction_id" -> in0.transactionId,

      "transaction_date" -> in0.transactionDate.toString,

      "account_id" -> in0.accountId.map(acctid => acctid.toString).getOrElse(""),

      "run_id" -> (in0.payload.hcursor --\ "runId")
        .focusSafe.map(_.as[Option[String]]).lift.map(_.flatten).orError("runId", in0.transactionId),

      "reference_id" -> (in0.payload.hcursor --\ "responseJson" --\ "referenceId")
        .focusSafe.map(_.as[Option[String]]).lift.map(_.flatten).orError("referenceId", in0.transactionId),

      "customer_profile" -> (in0.payload.hcursor --\ "responseJson" --\ "customerProfile").focus.map(x => x.nospaces).getOrElse("{}"),

      "document_verification" -> {
        (in0.payload.hcursor --\ "responseJson" --\ "documentVerification").focus.map(x => x.nospaces) match {
          case Some(documentVerification) if documentVerification.trim.nonEmpty =>
            Some(
              encrypter.encryptRaw(documentVerification.getBytes(StandardCharsets.UTF_8), encData._1,
                encData._2)
            )
          case _ => None
        }
      },
      "tetl_proc_time" -> in0.tetlProcTime.toString
    )
    ParserResponse(
      data = DocV(
        transactionId = in0.transactionId,
        accountId = in0.accountId.map(acctid => acctid.toString).getOrElse(""),
        payload = if (transaction.isEmpty || !transaction.isDefinedAt("document_verification") || (in0.accountId
          .isDefined &&
          in0.accountId.map(acctid => acctid.toString).getOrElse("").equals("0"))) None else Some(org.json4s.jackson.Serialization.write(transaction))
      ),
      streamType = if (nonConsentingAccounts.contains(in0.accountId.getOrElse(throw new Exception(s"For trxId " +
        s"${in0.transactionId} account id not found")))) KinesisStreamTypes.NonConsentingDocVStream.toString
      else KinesisStreamTypes.DocVStream.toString
    )
  }
}

object DocVParser {
  def apply(nonConsentingAccounts: List[Long]): DocVParser = {
    new DocVParser(nonConsentingAccounts)
  }
}

