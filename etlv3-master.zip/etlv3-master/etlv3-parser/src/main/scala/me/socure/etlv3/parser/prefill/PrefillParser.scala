package me.socure.etlv3.parser.prefill

import me.socure.dapl.snowflake.crypto.Encryption
import me.socure.etlv3.common._
import me.socure.etlv3.parser.{SimplePiiDataParser, _}
import org.json4s.{DefaultFormats, Formats}
import org.slf4j.LoggerFactory

import java.nio.charset.StandardCharsets
import scala.collection.immutable.ListMap

class PrefillParser(nonConsentingAccounts: List[Long]) extends SimplePiiDataParser[TransactionInput, Map[String,
  Array[Byte]], ParserResponse] {

  implicit val jsonFormats: Formats = DefaultFormats
  private val logger = LoggerFactory.getLogger(getClass)

  def extractFromPayload(trxInput: TransactionInput, param: String) = {
    (trxInput.payload.hcursor --\ "responseJson" --\ "prefill" --\ param)
  }

  def extractParameter(trxInput: TransactionInput, param: String) = {
    extractFromPayload(trxInput: TransactionInput, param: String).focusSafe.map(_.as[Option[JsonValue[String]]]).lift
      .map(_.flatten).orError(param,
      trxInput.transactionId) match {
      case Some(param) => param.value
      case _ => None
    }
  }

  override
  def parse(in0: TransactionInput, in1: Map[String, Array[Byte]]): ParserResponse = {
    val encrypter = Encryption()
    val encData = in0.accountId.map(acctid => acctid.toString) match {
      case Some(actId) => in1.get(actId) match {
        case Some(key) => (key, actId.getBytes(StandardCharsets.UTF_8))
        case _ => throw new Exception(s"For trxId ${in0.transactionId} account id ${actId} DataKey not found")
      }
      case _ => throw new Exception(s"For trxId ${in0.transactionId} account id not found")
    }
    logger.info(s"key length is = ${encData._1.length}")
    val transaction = ListMap(
      "transaction_id" -> in0.transactionId,

      "transaction_date" -> in0.transactionDate.toString,

      "account_id" -> in0.accountId.map(acctid => acctid.toString).getOrElse(""),

      "run_id" -> (in0.payload.hcursor --\ "runId")
        .focusSafe.map(_.as[Option[String]]).lift.map(_.flatten).orError("runId", in0.transactionId),

      "first_name" -> {
        extractParameter(in0, "firstName") match {
          case Some(firstName) if (firstName.trim.nonEmpty) =>
            Some(
              encrypter.encryptRaw(firstName.getBytes(StandardCharsets.UTF_8), encData._1, encData._2)
            )
          case _ => None
        }
      },

      "middle_name" -> {
        extractParameter(in0, "middleName") match {
          case Some(middleName) if (middleName.trim.nonEmpty) =>
            Some(
              encrypter.encryptRaw(middleName.getBytes(StandardCharsets.UTF_8), encData._1, encData._2)
            )
          case _ => None
        }
      },

      "sur_name" -> {
        extractParameter(in0, "surName") match {
          case Some(surName) if (surName.trim.nonEmpty) =>
            Some(
              encrypter.encryptRaw(surName.getBytes(StandardCharsets.UTF_8), encData._1, encData._2)
            )
          case _ => None
        }
      },

      "suffix" -> {
        extractParameter(in0, "suffix") match {
          case Some(suffix) if (suffix.trim.nonEmpty) =>
            Some(
              encrypter.encryptRaw(suffix.getBytes(StandardCharsets.UTF_8), encData._1, encData._2)
            )
          case _ => None
        }
      },

      "ssn_first_5" -> {
        extractParameter(in0, "ssnFirst5") match {
          case Some(ssnFirst5) if (ssnFirst5.trim.nonEmpty) =>
            Some(
              encrypter.encryptRaw(ssnFirst5.getBytes(StandardCharsets.UTF_8), encData._1, encData._2)
            )
          case _ => None
        }
      },

      "dob" -> {
        extractParameter(in0, "dob") match {
          case Some(dob) if (dob.trim.nonEmpty) =>
            Some(
              encrypter.encryptRaw(dob.getBytes(StandardCharsets.UTF_8), encData._1, encData._2)
            )
          case _ => None
        }
      },
      "associated_addresses" -> {
        (in0.payload.hcursor --\ "responseJson" --\ "prefill" --\ "associatedAddresses").focus.map(x => x.nospaces) match {
          case Some(address) if (address.trim.nonEmpty) =>
            Some(
              encrypter.encryptRaw(address.getBytes(StandardCharsets.UTF_8), encData._1,
                encData._2)
            )
          case _ => None
        }
      },
      "tetl_proc_time" -> in0.tetlProcTime.toString
    )
    ParserResponse(
      data = Prefill(
        transactionId = in0.transactionId,
        accountId = in0.accountId.map(acctid => acctid.toString).getOrElse(""),
        payload = if (transaction.isEmpty || (in0.accountId.isDefined && in0.accountId.map(acctid => acctid.toString).getOrElse("").equals("0"))) None else Some(org.json4s.jackson.Serialization.write(transaction))
      ),
      streamType = if (nonConsentingAccounts.contains(in0.accountId.getOrElse(throw new Exception(s"For trxId " +
        s"${in0.transactionId} account id not found")))) KinesisStreamTypes.NonConsentingPrefillStream.toString
      else KinesisStreamTypes.PrefillStream.toString
    )
  }
}

object PrefillParser {
  def apply(nonConsentingAccounts: List[Long]): PrefillParser = {
    new PrefillParser(nonConsentingAccounts)
  }
}






