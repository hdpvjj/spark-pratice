package me.socure.etlv3.parser.rulecodeintact

import me.socure.etlv3.common._
import me.socure.etlv3.parser.{SimpleDataParser, _}
import org.json4s.{DefaultFormats, Formats}
import scala.collection.immutable.ListMap

class RuleCodeIntactParser extends SimpleDataParser[TransactionInput, ParserResponse] {
  implicit val jsonFormats: Formats = DefaultFormats

  override
  def parse(input: TransactionInput): ParserResponse = {

    def extractParameter(trxInput: TransactionInput, param: String) = {
      extractFromPayload(trxInput: TransactionInput, param: String).focusSafe.map(_.as[Option[String]]).lift
      .map(_.flatten).orError(param,
                              trxInput.transactionId
                             )
    }

    def extractFromPayload(trxInput: TransactionInput, param: String) = {
      (trxInput.payload.hcursor --\ "parametersJson" --\ param)
    }

    val ruleCodeMap = input.ruleCode.result.orError("rulecode", input.transactionId).foldLeft(Map.empty[String, String]) {(s, v) =>
         s ++ Map(v.name.get -> v.value.get)
      }

    val payload = if(ruleCodeMap.isEmpty) None else Some(org.json4s.jackson.Serialization.write(ListMap(
                                                                                                         "transaction_id" ->
                                                                                                         input.transactionId,

                                                                                                         "transaction_date"
                                                                                                         -> input
                                                                                                            .transactionDate
                                                                                                            .toString,

                                                                                                         "account_id" ->
                                                                                                         input.accountId.map
                                                                                                         (acctid => acctid
                                                                                                                    .toString)
                                                                                                         .getOrElse(""),

                                                                                                         "run_id" ->
                                                                                                         (input.payload.hcursor --\ "runId")
                                                                                                           .focusSafe.map(_.as[Option[String]]).lift.map(_.flatten).orError("runId", input.transactionId),

                                                                                                         "rule_codes" -> ruleCodeMap,
                                                                                                         "tetl_proc_time" -> input.tetlProcTime.toString
                                                                                                       )
                                                                                               ))

    ParserResponse(
                    data = RuleCodeIntact(
                                        transactionId = input.transactionId,
                                        accountId = input.accountId.map(acctid => acctid.toString).getOrElse(""),
                                        payload = payload
                                      ),
                    streamType = KinesisStreamTypes.RuleCodeIntactStream.toString
                  )
  }

}

object RuleCodeIntactParser {
  def apply() = {
    new RuleCodeIntactParser()
  }
}
