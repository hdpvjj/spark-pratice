package me.socure.etlv3.parser.transactionpii

import java.nio.charset.StandardCharsets
import argonaut.DecodeJson
import me.socure.dapl.snowflake.crypto.Encryption
import me.socure.etlv3.common._
import me.socure.etlv3.parser.{PaymentExtractor, SimplePiiDataParser, _}
import org.json4s.jackson.JsonMethods
import org.json4s.jackson.JsonMethods.{compact, render}
import org.json4s.{DefaultFormats, Formats}
import org.slf4j.LoggerFactory
import scala.collection.immutable.ListMap
import scala.util.Try

class TransactionPiiParser(nonConsentingAccounts: List[Long]) extends SimplePiiDataParser[TransactionInput, Map[String, Array[Byte]], ParserResponse] {

  implicit val jsonFormats: Formats = DefaultFormats
  private val logger           = LoggerFactory.getLogger(getClass)
  private implicit val decodeAddress: DecodeJson[Address] = DecodeJson { h =>
  for {
    addressType <- (h --\ "type").as[Option[JsonValue[String]]]
    line1 <- (h --\ "line1").as[Option[JsonValue[String]]]
    line2 <- (h --\ "line2").as[Option[JsonValue[String]]]
    city <- (h --\ "city").as[Option[JsonValue[String]]]
    state <- (h --\ "state").as[Option[JsonValue[String]]]
    postalCode <- (h --\ "postalCode").as[Option[JsonValue[String]]]
    country <- (h --\ "country").as[Option[JsonValue[String]]]
  } yield Address(
                   addressType = extractAddressType(addressType),
                   line1 = line1,
                   line2 = line2,
                   city = city,
                   state = state,
                   postalCode = postalCode,
                   country = country
                 )
  }

  private implicit val decodeDevice: DecodeJson[Device] = DecodeJson { h =>
  for {
    deviceType <- (h --\ "deviceType").as[Option[JsonValue[String]]]
    operatingSystem <- (h --\ "operatingSystem").as[Option[JsonValue[String]]]
    deviceInterface <- (h --\ "deviceInterface").as[Option[JsonValue[String]]]
  } yield Device(
                  deviceType = deviceType,
                  operatingSystem = operatingSystem,
                  deviceInterface = deviceInterface
                )
  }

  private def extractAddressType(extractedType: Option[String]): Option[String] = extractedType.map(_.trim).filter(_.nonEmpty).orElse(Some("na"))

  def extractFromPayload(trxInput: TransactionInput, param: String) = {
    (trxInput.payload.hcursor --\ "parametersJson" --\ param)
  }

  def extractIpAddress(input: TransactionInput) = {
    val isIpAddress = (input.payload.hcursor --\ "parametersJson" --\ "ipaddress").as[Option[JsonValue[String]]]

    if(isIpAddress.isError) {
      Some((input.payload.hcursor --\ "parametersJson" --\ "ipaddress").as[Option[Set[String]]].map(_.getOrElse
      (Set.empty[String]).map(_.trim.toLowerCase).filterNot(_.isEmpty)).orError("ipAddress", input.transactionId).mkString("|"))
    } else {
      isIpAddress.result.right.getOrElse(None) match {
        case Some(ipAddress) => ipAddress.value
        case _ => None
    }
    }
  }

  def extractStrJsonValue(paramValue: Option[JsonValue[String]]) = {
    paramValue match {
      case Some(pValue) => pValue.value
      case _ => None
    }
  }

  def getParameter(input: TransactionInput, param: String) = {
    extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ param)
                          .focusSafe.map(_.as[Option[JsonValue[String]]]).lift.map(_.flatten)
                          .orError(param, input.transactionId)
                       )
  }

  def extractParameter(trxInput: TransactionInput, param: String) = {

    if(trxInput.environmentId.isDefined && trxInput.environmentId.contains(3)) {
      Try {
        getParameter(trxInput, param)
      }.getOrElse {
        logger.info(s"Resolving ${param} for sandbox environment id ${trxInput.environmentId}")
        (trxInput.payload.hcursor --\ "parametersJson" --\ param).focus.map(x => x.nospaces)
      }
    } else {
      getParameter(trxInput, param)
    }
  }

  def extractAddressesParameter(trxInput: TransactionInput, param: String) = {

    val addresses = extractFromPayload(trxInput: TransactionInput, param: String).as[Set[Address]]

    if(addresses.isError) {
      extractFromPayload(trxInput: TransactionInput, param: String).focusSafe
      .map(_.as[Option[Address]]).lift.map(_.getOrElse(None)).result.orError(param,
                                                                             trxInput.transactionId).toSet
    } else {
      addresses.result.right.getOrElse(Set.empty[Address])
    }
  }

  def extractDeviceParameter(trxInput: TransactionInput, param: String) = {
    extractFromPayload(trxInput: TransactionInput, param: String).focusSafe
    .map(_.as[Device])
    .lift
    .map(_.toList.filterNot(_.isEmpty))
    .result.orError(param,
                    trxInput.transactionId)
  }

  override
  def parse(in0: TransactionInput, in1: Map[String, Array[Byte]]): ParserResponse = {
    val encrypter = Encryption()
    val encData = in0.accountId.map(acctid => acctid.toString) match {
      case Some(actId) => in1.get(actId) match {
        case Some(key) => (key, actId.getBytes(StandardCharsets.UTF_8))
        case _         => throw new Exception(s"For trxId ${in0.transactionId} account id ${actId} DataKey not found")
      }
      case _           => throw new Exception(s"For trxId ${in0.transactionId} account id not found")
    }
    val address = extractAddressesParameter(in0, "addresses")
    logger.info(s"key length is = ${encData._1.length}")
    val transaction = ListMap(
                               "transaction_id" -> in0.transactionId,

                               "transaction_date" -> in0.transactionDate.toString,

                               "account_id" -> in0.accountId.map(acctid => acctid.toString).getOrElse(""),
                               "environment_id" -> in0.environmentId,

                               "run_id" -> (in0.payload.hcursor --\ "runId")
                                 .focusSafe.map(_.as[Option[String]]).lift.map(_.flatten).orError("runId", in0.transactionId),

                               "entity_name" -> {
                                 extractParameter(in0, "entityName") match {
                                   case Some(entityName) => if (entityName.trim.nonEmpty) {
                                     Some(
                                           encrypter.encryptRaw(entityName.getBytes(StandardCharsets.UTF_8), encData._1, encData._2)
                                         )
                                   }
                                   case _           => None
                                 }
                               },

                               "origin_of_invocation" -> {
                                 extractParameter(in0, "originOfInvocation") match {
                                   case Some(ofi) if (ofi.trim.nonEmpty) => 
                                     Some(
                                       encrypter.encryptRaw(ofi.getBytes(StandardCharsets.UTF_8), encData._1, encData._2)
                                     )
                                   case _                                => None
                                 }
                               },

                               "email" -> {
                                 extractParameter(in0, "email") match {
                                   case Some(email) => if (email.trim.nonEmpty) {
                                     Some(
                                       encrypter.encryptRaw(email.getBytes(StandardCharsets.UTF_8), encData._1, encData._2)
                                     )
                                   }
                                   case _           => None
                                 }
                               },

                               "first_name" -> {
                                 extractParameter(in0, "firstname") match {
                                   case Some(firstName) if (firstName.trim.nonEmpty) => 
                                     Some(
                                       encrypter.encryptRaw(firstName.getBytes(StandardCharsets.UTF_8), encData._1, encData._2)
                                     )
                                   case _                                            => None
                                 }
                               },

                               "surname" -> {
                                 extractParameter(in0, "surname") match {
                                   case Some(surname) if (surname.trim.nonEmpty) =>
                                     Some(encrypter.encryptRaw(surname.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _                                        => None
                                 }
                               },

                               "full_name" -> {
                                 extractParameter(in0, "fullname") match {
                                   case Some(fullName) if (fullName.trim.nonEmpty) =>
                                     Some(encrypter.encryptRaw(fullName.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _                                          => None
                                 }
                               },

                               "company_name" -> {
                                 extractParameter(in0, "companyname") match {
                                   case Some(companyName) if (companyName.trim.nonEmpty) =>
                                     Some(
                                       encrypter.encryptRaw(companyName.getBytes(StandardCharsets.UTF_8), encData._1, encData._2)
                                     )
                                   case _                                                => None
                                 }
                               },

                               "user_id" -> {
                                 extractParameter(in0, "userid") match {
                                   case Some(userid) if (userid.trim.nonEmpty) => Some(encrypter.encryptRaw(userid.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _       => None
                                 }
                               },

                               "physical_address" -> {
                                 extractParameter(in0, "physicaladdress") match {
                                   case Some(physicalAddress) if (physicalAddress.trim.nonEmpty) =>
                                     Some(encrypter.encryptRaw(physicalAddress.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _                                                        => None
                                 }
                               },

                               "physical_address2" -> {
                                 extractParameter(in0, "physicaladdress2") match {
                                   case Some(physicalAddress2) if (physicalAddress2.trim.nonEmpty) =>
                                     Some(encrypter.encryptRaw(physicalAddress2.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _                                                          => None
                                 }
                               },

                               "city" -> {
                                 extractParameter(in0, "city") match {
                                   case Some(city) if (city.trim.nonEmpty) =>
                                     Some(encrypter.encryptRaw(city.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _                                  => None
                                 }
                               },

                               "state" -> {
                                 extractParameter(in0, "state") match {
                                   case Some(state) if (state.trim.nonEmpty) =>
                                     Some(encrypter.encryptRaw(state.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _                                    => None
                                 }
                               },

                               "zip" -> {
                                 extractParameter(in0, "zip") match {
                                   case Some(zip) if (zip.trim.nonEmpty) =>  Some(encrypter.encryptRaw(zip.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _       => None
                                 }
                               },

                               "country" -> {
                                 in0.country match {
                                   case Some(country) if (country.trim.nonEmpty) => 
                                     Some(encrypter.encryptRaw(country.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _                                        => None
                                 }
                               },

                               "ip_address" -> {
                                 extractIpAddress(in0) match {
                                   case Some(ipAddress) if (ipAddress.trim.nonEmpty) => Some(encrypter.encryptRaw(ipAddress.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _  => None
                                }
                               },

                               "national_id" -> {
                                 extractParameter(in0, "nationalid") match {
                                   case Some(nationalId) if (nationalId.trim.nonEmpty) => Some(encrypter.encryptRaw(nationalId.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _  => None
                                 }
                               },

                               "dob" -> {
                                 extractParameter(in0, "dob") match {
                                   case Some(dob) if (dob.trim.nonEmpty) => 
                                     Some(encrypter.encryptRaw(dob.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _                                => None
                                 }
                               },

                               "mobile_number" -> {
                                 extractParameter(in0, "mobilenumber") match {
                                   case Some(mob) if (mob.trim.nonEmpty) => 
                                     Some(encrypter.encryptRaw(mob.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _                                => None
                                 }
                               },

                               "driver_license" -> {
                                 extractParameter(in0, "driverlicense") match {
                                   case Some(dl) if (dl.trim.nonEmpty) => 
                                     Some(encrypter.encryptRaw(dl.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _                              => None
                                 }
                               },

                               "driver_license_state" -> {
                                 extractParameter(in0, "driverlicensestate") match {
                                   case Some(dls) if (dls.trim.nonEmpty) => 
                                     Some(encrypter.encryptRaw(dls.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _                                => None
                                 }
                               },

                               "geocode" -> {
                                 extractParameter(in0, "geocode") match {
                                   case Some(geocode) if (geocode.trim.nonEmpty) => 
                                     Some(encrypter.encryptRaw(geocode.getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                   case _                                        => None
                                 }
                               },


                               "payments" -> {
                                 val payment = PaymentExtractor.extractPaymentParameter(in0, "payments")
                                 if(payment.nonEmpty) {
                                   Some(encrypter.encryptRaw(org.json4s.jackson.Serialization.write(payment).getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                 } else None
                               },


                               "addresses" -> {
                                 if(address.nonEmpty) {
                                   Some(encrypter.encryptRaw(org.json4s.jackson.Serialization.write(address).getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                 } else None
                               },

                               "devices" -> {
                                 val device = extractDeviceParameter(in0, "device")
                                 if(device.nonEmpty) {
                                   Some(encrypter.encryptRaw(org.json4s.jackson.Serialization.write(device).getBytes(StandardCharsets.UTF_8), encData._1, encData._2))
                                 } else None
                               },

                               "shipping_details" -> {
                                 val shippingDetail = (in0.payload.hcursor --\ "parametersJson" --\ "shippingDetails").focus.map(x => x.nospaces)
                                 if(shippingDetail.nonEmpty && address.nonEmpty && address.map(_.addressType.getOrElse("").equals("shipping")).contains(true)) {
                                    val data = compact(render(JsonMethods.parse(shippingDetail.get))).getBytes(StandardCharsets.UTF_8)
                                    Some(encrypter.encryptRaw(data, encData._1, encData._2))
                                 } else None
                               },

                               "merchant_details" -> {
                                val merchantDetail = (in0.payload.hcursor --\ "parametersJson" --\ "merchantDetails").focus.map(x => x.nospaces)
                                if (merchantDetail.nonEmpty) {
                                  val data = compact(render(JsonMethods.parse(merchantDetail.get))).getBytes(StandardCharsets.UTF_8)
                                  Some(encrypter.encryptRaw(data, encData._1, encData._2))
                                } else None
                               },

                               "tetl_proc_time" -> in0.tetlProcTime.toString,
      "business_name" -> {
        extractParameter(in0, "businessName") match {
          case Some(businessName) if (businessName.trim.nonEmpty) =>
            Some(
              encrypter.encryptRaw(businessName.getBytes(StandardCharsets.UTF_8), encData._1, encData._2)
            )
          case _                                            => None
        }
      },
      "ein" -> {
        extractParameter(in0, "ein") match {
          case Some(ein) if (ein.trim.nonEmpty) =>
            Some(
              encrypter.encryptRaw(ein.getBytes(StandardCharsets.UTF_8), encData._1, encData._2)
            )
          case _                                            => None
        }
      }
                             )
    ParserResponse(
                    data = TransactionPii(
                                           transactionId = in0.transactionId,
                                           accountId = in0.accountId.map(acctid => acctid.toString).getOrElse(""),
                                           payload = if(transaction.isEmpty || (in0.accountId.isDefined && in0.accountId.map(acctid => acctid.toString).getOrElse("").equals("0"))) None else Some(org.json4s.jackson.Serialization.write(transaction))
                                         ),
                    streamType = if(nonConsentingAccounts.contains(in0.accountId.getOrElse(throw new Exception(s"For trxId ${in0.transactionId} account id not found")))) KinesisStreamTypes.NonConsentingTransactionPiiStream.toString else KinesisStreamTypes.TransactionPiiStream.toString
                  )
  }

}

object TransactionPiiParser {
  def apply(nonConsentingAccounts: List[Long]): TransactionPiiParser = {
    new TransactionPiiParser(nonConsentingAccounts)
  }
}
