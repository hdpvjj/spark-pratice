package me.socure.etlv3.parser.reasoncode

import argonaut.Parse
import me.socure.etlv3.common._
import me.socure.etlv3.parser.SimpleDataParser
import org.json4s.{DefaultFormats, Formats}
import scala.collection.JavaConversions._
import scala.collection.immutable.ListMap
import org.json4s.native.Serialization
import org.json4s._
import me.socure.etlv3.parser._
import com.google.gson._

class ReasonCodeParser extends SimpleDataParser[TransactionInput, ParserResponse] {

  val REASON_CODES = "reasonCodes"

  private implicit val formats: Formats = DefaultFormats

  def parseResponse(keys:java.util.Set[java.util.Map.Entry[String, JsonElement]], jsnObj: JsonObject) = {
    val iterateResponse  = keys.iterator()
    var reasonCodeBucket = Set[String]()
    while(iterateResponse.hasNext) {
      val reasonCodeSet  = iterateResponse.next()
      if(reasonCodeSet.getKey.equals(REASON_CODES)) {
        val rCode        = jsnObj.get(reasonCodeSet.getKey)
        reasonCodeBucket = reasonCodeBucket ++ rCode.getAsJsonArray.map(s=> s.getAsString).toSet
        reasonCodeBucket
      } else {
        reasonCodeBucket
      }
    }
    reasonCodeBucket
  }

  override
  def parse(input: TransactionInput): ParserResponse = {

    implicit val formats = Serialization.formats(NoTypeHints)

    val reasonCodes = (input.payload.hcursor --\ "reasonCodes")
      .opt(_.as[Option[String]])
      .map(_.flatten.map(_.trim.toLowerCase).filterNot(_.isEmpty))
      .map(_.map {
        rcStr =>
        Parse
        .parse(rcStr)
        .orError("reason code", input.transactionId)
        .as[Set[String]]
          .map(_.map(_.trim).filterNot(_.isEmpty))
          .map(_.map(ReasonCodeValue))
          .orError("reason code", input.transactionId)
      }
          )
      .map(_.getOrElse(Set.empty[ReasonCodeValue]))
      .result
      .orError("reason code", input.transactionId)

    ParserResponse(
                    data = ReasonCode(
                                       transactionId    = input.transactionId,
                                       accountId = input.accountId.map(acctId => acctId.toString).getOrElse(""),
                                       payload = if(reasonCodes.isEmpty) {
                                         val response   = (input.payload.hcursor --\ "response")
                                           .focusSafe
                                           .map(_.as[Option[String]])
                                           .lift
                                           .map(_.flatten)
                                           .orError("response", input.transactionId)

                                         response match {
                                           case Some(trxResponse) =>
                                               val jsonObject       = new JsonParser().parse(trxResponse).getAsJsonObject()
                                               val keys             = jsonObject.entrySet()
                                               val iterateResponse  = keys.iterator()
                                               var reasonCodeBucket = Set[String]()
                                               while(iterateResponse.hasNext) {
                                                 val nxt = iterateResponse.next()
                                                 if(jsonObject.get(nxt.getKey).isJsonObject) {
                                                   val jsnObj = jsonObject.get(nxt.getKey).getAsJsonObject()
                                                   val keys   = jsnObj.entrySet()
                                                   reasonCodeBucket= reasonCodeBucket ++ parseResponse(keys, jsnObj)
                                                 }
                                               }
                                               Some(org.json4s.jackson.Serialization.write(ListMap("transaction_id" -> input.transactionId,
                                                                                                   "account_id" -> input.accountId.map(acctId => acctId.toString).getOrElse(""),
                                                                                                   "run_id" -> (input.payload.hcursor --\ "runId").focusSafe.map(_.as[Option[String]]).lift.map(_.flatten).orError("runId", input.transactionId),
                                                                                                   "transaction_date" -> input.transactionDate.toString,
                                                                                                   "reason_codes" -> reasonCodeBucket.map(_.toLowerCase()),
                                                                                                   "tetl_proc_time" -> input.tetlProcTime.toString)

                                                                                           ++ reasonCodeBucket.map{case r:String => {r.toLowerCase -> true}}.toMap))
                                           case _ => None
                                         }
                                       } else {
                                               Some(org.json4s.jackson.Serialization.write(ListMap("transaction_id" -> input.transactionId,
                                                                                                   "account_id" -> input.accountId.map(acctId => acctId.toString).getOrElse(""),
                                                                                                   "run_id" -> (input.payload.hcursor --\ "runId").focusSafe.map(_.as[Option[String]]).lift.map(_.flatten).orError("runId", input.transactionId),
                                                                                                   "transaction_date" -> input.transactionDate.toString,
                                                                                                   "reason_codes" -> reasonCodes.toArray.sortBy(_.value).map(_.value),
                                                                                                   "tetl_proc_time" -> input.tetlProcTime.toString)

                                                                                           ++ reasonCodes.map{case r:ReasonCodeValue => {r.value -> true }}.toMap))}
                                     ),
                    streamType = KinesisStreamTypes.ReasonCodeStream.toString
                  )
  }
}

object ReasonCodeParser {
  def apply(): ReasonCodeParser = {
    new ReasonCodeParser()
  }
}
