package me.socure.etlv3.parser.watchlist

import me.socure.etlv3.common._
import me.socure.etlv3.parser.SimpleDataParser
import org.json4s.{DefaultFormats, Formats}
import me.socure.etlv3.parser._
import org.json4s.jackson.JsonMethods
import scala.collection.immutable.ListMap
import org.json4s.jackson.Serialization.write

class WatchlistParser extends SimpleDataParser[TransactionInput, ParserResponse] {

  private implicit val formats: Formats = DefaultFormats

  override def parse(input: TransactionInput): ParserResponse = {

    val matches = (input.payload.hcursor --\ "responseJson"
     --\ "globalWatchlist" --\ "matches").focus.map(x => x.nospaces)

    val settings = (input.payload.hcursor --\ "debugJson" --\
     "watchlist3_0_settings").focus.map(x => x
                                             .nospaces).getOrElse("{}")

    val payload = matches match {
      case Some(records) if(!records.trim.equals("{}") || !settings.trim.equals("{}")) =>  Some(write(ListMap("transaction_id" -> input.transactionId,
                                                "account_id" -> input.accountId.map(acctId => acctId
                                                                                              .toString).getOrElse(""),
                                                "run_id" -> (input.payload.hcursor --\ "runId")
                                                  .focusSafe.map(_.as[Option[String]]).lift.map(_.flatten).orError("runId", input.transactionId),
                                                "transaction_date" -> input.transactionDate.toString,
                                                "matches" ->  JsonMethods.parse(records),
                                                "settings" -> JsonMethods.parse(settings),
                                                "tetl_proc_time" -> input.tetlProcTime.toString
                                               )
                                       ))
      case _ => None
    }

    ParserResponse(
                    data = Watchlist(transactionId = input.transactionId,
                                     accountId = input.accountId.map(acctId => acctId.toString).getOrElse(""),
                                     payload = payload
                                    ),
                    streamType = KinesisStreamTypes.WatchlistStream.toString
                  )
  }
}

object WatchlistParser {
  def apply(): WatchlistParser = {
    new WatchlistParser()
  }
}
