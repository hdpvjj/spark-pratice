package me.socure.etlv3.parser

import scala.util.control.NoStackTrace

case class DataParsingException(data: String, error: String) extends Exception(s"Error while parsing data [$data] " +
                                                                          s": $error"
                                                                         ) with NoStackTrace
