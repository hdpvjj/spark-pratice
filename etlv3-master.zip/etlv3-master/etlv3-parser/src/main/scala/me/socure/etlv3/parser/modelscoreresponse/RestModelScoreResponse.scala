package me.socure.etlv3.parser.modelscoreresponse

case class RestModelScoreResponse(
                                   score: Option[Double]
                                 )