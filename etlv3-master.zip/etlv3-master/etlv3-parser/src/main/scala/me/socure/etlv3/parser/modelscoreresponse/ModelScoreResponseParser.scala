package me.socure.etlv3.parser.modelscoreresponse

import argonaut.{ACursor, DecodeJson, DecodeResult}
import me.socure.etlv3.common.{KinesisStreamTypes, ModelScoreOutput, ParserResponse, TransactionInput}
import me.socure.etlv3.parser.{SimpleDataParser, _}
import org.json4s.{DefaultFormats, Formats}
import me.socure.etlv3.common.ModuleTypes._

import scala.collection.immutable.ListMap


class ModelScoreResponseParser extends SimpleDataParser[TransactionInput, ParserResponse] {

  private implicit val formats: Formats = DefaultFormats

  private implicit
  val decodeFraudModelScore: DecodeJson[FraudModelScoreResponse] = DecodeJson {
    h =>
      for {
        name <- (h --\ "name").as[Option[String]]
        version <- (h --\ "version").as[Option[String]]
        score <- (h --\ "score").as[Option[Double]]
      } yield {
        FraudModelScoreResponse(
          name = name,
          version = version,
          score = score
        )
      }
  }

  private implicit
  val decodeSyntheticModelScore: DecodeJson[SyntheticModelScoreResponse] = DecodeJson {
    h =>
      for {
        name <- (h --\ "name").as[Option[String]]
        version <- (h --\ "version").as[Option[String]]
        score <- (h --\ "score").as[Option[Double]]
      } yield {
        SyntheticModelScoreResponse(
          name = name,
          version = version,
          score = score
        )
      }
  }

  private implicit
  val decodeKycModelScore: DecodeJson[KycModelScoreResponse] = DecodeJson {
    h =>
      for {
        firstName <- (h --\ "firstName").as[Option[Double]]
        surName <- (h --\ "surName").as[Option[Double]]
        streetAddress <- (h --\ "streetAddress").as[Option[Double]]
        city <- (h --\ "city").as[Option[Double]]
        state <- (h --\ "state").as[Option[Double]]
        zip <- (h --\ "zip").as[Option[Double]]
        mobileNumber <- (h --\ "mobileNumber").as[Option[Double]]
        dob <- (h --\ "dob").as[Option[Double]]
        ssn <- (h --\ "ssn").as[Option[Double]]

      } yield {
        KycModelScoreResponse(
          firstName=firstName,
          surName=surName,
          streetAddress=streetAddress,
          city=city,
          state=state,
          zip=zip,
          mobileNumber=mobileNumber,
          dob=dob,
          ssn=ssn
        )
      }
  }

  private implicit
  val decodeRestModelScore: DecodeJson[RestModelScoreResponse] = DecodeJson {
    h =>
      for {
        score <- (h --\ "score").as[Option[Double]]
      } yield {
        RestModelScoreResponse(
          score = score
        )
      }
  }

  private def parseRestModelScore(cursor: ACursor, moduleType: ModuleType): DecodeResult[Option[ModelScoreResponse]] = {
    cursor.focusSafe.map(_.as[RestModelScoreResponse]).lift
      .map(_.map(model =>
        ModelScoreResponse(
          moduleType = Some(moduleType),
          modelName = None,
          modelVersion = None,
          fieldValidations = None,
          score = model.score
        )))
  }

  private def parseFraudModelScore(cursor: ACursor, moduleType: ModuleType): DecodeResult[Option[List[ModelScoreResponse]]] = {
    (cursor --\ "scores").focusSafe.map(_.as[List[FraudModelScoreResponse]]).lift
      .map(_.map(_.map(
        model => ModelScoreResponse(
          moduleType = Some(moduleType),
          modelName = model.name,
          modelVersion = model.version,
          fieldValidations = None,
          score = model.score
        )
      )))
  }

  private def parseSyntheticModelScore(cursor: ACursor, moduleType: ModuleType): DecodeResult[Option[List[ModelScoreResponse]]] = {
    (cursor --\ "scores").focusSafe.map(_.as[List[SyntheticModelScoreResponse]]).lift
      .map(_.map(_.map(
        model => ModelScoreResponse(
          moduleType = Some(moduleType),
          modelName = model.name,
          modelVersion = model.version,
          fieldValidations = None,
          score = model.score
        )
      )))
  }

  private def parseKycModelScore(cursor: ACursor, moduleType: ModuleType): DecodeResult[Option[scala.collection.immutable.Iterable[ModelScoreResponse]]] = {
    (cursor --\ "fieldValidations").focusSafe.map(_.as[KycModelScoreResponse]).lift
    .map(_.map(model => model.getClass.getDeclaredFields.map(_.getName).zip(model.productIterator.to).toMap
      .asInstanceOf[Map[String, Option[Double]]]
      .map(
        key =>
          ModelScoreResponse(
            moduleType = Some(moduleType),
            modelName = None,
            modelVersion = None,
            fieldValidations = Some(key._1),
            score = key._2
        ))))
  }


  override
  def parse(input: TransactionInput): ParserResponse = {
    val response = input.payload.hcursor --\ "responseJson"

    val decodeResult = for {
      /*
      deviceRisk & deviceIdentityCorrelation response score field has been depreciated.
      Keeping it for backfill purposes
      Docs: https://developer.socure.com/reference#tag/ID+/operation/ID+
       */
      kyc <- parseKycModelScore(response --\ "kyc", Kyc)
      fraud <- parseFraudModelScore(response --\ "fraud", Fraud)
      synthetic <- parseSyntheticModelScore(response --\ "synthetic", Synthetic)
      nameAddressCorrelation <- parseRestModelScore(response --\ "nameAddressCorrelation", NameAddressCorrelation)
      nameEmailCorrelation <- parseRestModelScore(response --\ "nameEmailCorrelation", NameEmailCorrelation)
      namePhoneCorrelation <- parseRestModelScore(response --\ "namePhoneCorrelation", NamePhoneCorrelation)
      deviceIdentityCorrelation <- parseRestModelScore(response --\ "deviceIdentityCorrelation", DeviceIdentityCorrelation)
      addressRisk <- parseRestModelScore(response --\ "addressRisk", AddressRisk)
      emailRisk <- parseRestModelScore(response --\ "emailRisk", EmailRisk)
      phoneRisk <- parseRestModelScore(response --\ "phoneRisk", PhoneRisk)
      deviceRisk <- parseRestModelScore(response --\ "deviceRisk", DeviceRisk)

    }
    yield {
      val modelScores = Seq(kyc, fraud, synthetic).flatten.flatten ++
        Seq(
          nameAddressCorrelation,
          nameEmailCorrelation,
          namePhoneCorrelation,
          deviceIdentityCorrelation,
          addressRisk,
          emailRisk,
          phoneRisk,
          deviceRisk
        ).flatten

      modelScores.filterNot(_.isEmpty)
    }
    val models = decodeResult.result.orError("ModelScoreResponse Parsing Error", input.transactionId)

    val ownershipScore    = (response --\ "accountIntelligence" --\ "account" --\ "ownershipScore")
      .focusSafe.map(_.as[Option[Double]]).lift.map(_.flatten).orError("ownershipScore", input.transactionId)

    val availabilityScore = (response --\ "accountIntelligence" --\ "account" --\ "availabilityScore")
      .focusSafe.map(_.as[Option[Double]]).lift.map(_.flatten).orError("availabilityScore", input.transactionId)

    val result = if(!models.isEmpty) {
      models.map {
        model =>
        ListMap(
                 "transaction_id" -> input.transactionId,
                 "account_id" -> input.accountId.map(acctid => acctid.toString).getOrElse(""),
                 "transaction_date" -> input.transactionDate.toString,
                 "environment_id" -> input.environmentId,
                 "run_id" -> input.runId,
                 "module_type" -> model.moduleType.map(_.toString),
                 "model_name" -> model.modelName,
                 "model_version" -> model.modelVersion,
                 "field_validations" -> model.fieldValidations,
                 "score" -> model.score,
                 "ownership_score" -> ownershipScore,
                 "availability_score" -> availabilityScore,
                 "tetl_proc_time" -> input.tetlProcTime.toString
               )
      }
    } else {
      Seq(ListMap(
                   "transaction_id" -> input.transactionId,
                   "account_id" -> input.accountId.map(acctid => acctid.toString).getOrElse(""),
                   "transaction_date" -> input.transactionDate.toString,
                   "environment_id" -> input.environmentId,
                   "run_id" -> input.runId,
                   "ownership_score" -> ownershipScore,
                   "availability_score" -> availabilityScore,
                   "tetl_proc_time" -> input.tetlProcTime.toString
                 ))
    }


    ParserResponse(
      data = ModelScoreOutput(
        transactionId = input.transactionId,
        accountId = input.accountId.map(acctid => acctid.toString).getOrElse(""),
        payload = Some(trimSquareFoldJson(org.json4s.jackson.Serialization.write
        (result)))
      ),
      streamType = KinesisStreamTypes.ModelScoreResponseStream.toString
    )


  }

  def trimSquareFoldJson(json: String): String = {
    if (!json.isEmpty || !json.equals("[]") || !json.equals("{}"))
      json.substring(1, json.length - 1)
    else
      json
  }
}

object ModelScoreResponseParser {
  def apply(): ModelScoreResponseParser = {
    new ModelScoreResponseParser()
  }
}