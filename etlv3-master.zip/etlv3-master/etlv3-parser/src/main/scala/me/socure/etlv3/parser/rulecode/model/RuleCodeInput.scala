package me.socure.etlv3.parser.rulecode.model

import argonaut.DecodeResult
import me.socure.etlv3.common.RuleCode

case
class RuleCodeInput(
                     transactionId    : String,
                     accountId        : String,
                     transactionDate  : String,
                     runId            : String,
                     input            : DecodeResult[Set[RuleCode]]
                   )
