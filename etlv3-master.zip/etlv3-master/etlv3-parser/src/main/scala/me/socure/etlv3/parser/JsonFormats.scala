package me.socure.etlv3.parser

import org.json4s.ext.EnumNameSerializer
import org.json4s.{DefaultFormats, Formats}

object JsonFormats {

  lazy
  val formats: Formats = {
    DefaultFormats ++ List(
                            new EnumNameSerializer(EnvironmentConstants)
                          )
  }
}
