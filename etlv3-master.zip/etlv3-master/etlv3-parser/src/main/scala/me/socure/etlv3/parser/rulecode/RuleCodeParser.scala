package me.socure.etlv3.parser.rulecode

import me.socure.etlv3.common.{ParserResponse, RuleCode, TransactionInput}
import me.socure.etlv3.parser.rulecode.RuleCodeCommon.formParserResponse
import me.socure.etlv3.parser.util.Constants.UNCATEGORIZED_RC
import me.socure.etlv3.parser.{SimpleDataParser, _}

class RuleCodeParser extends SimpleDataParser[TransactionInput, ParserResponse] {
  /**
   * parse a transaction for a specific rule code table (or ruleType, or kinesis stream).
   * The target rule code table can be 1 of the 5 partitioned tables, or uncategorized.
   * The ONE target rule code table is passed in as the ruleCodeSchema portion of the input.
   * For uncategorized table, this method's output includes all rule codes not in the 5 partitioned tables
   * for this transaction.
   */
  override
  def parse(input: TransactionInput): ParserResponse = {
    val rules = input.rulCodeSchema.head
    val filteredRuleCode = if(input.rulCodeSchema.head.kinesisStream.toLowerCase.contains(UNCATEGORIZED_RC)) {
      val inputRuleCodeSet =  input.ruleCode.result.orError("rule code", input.transactionId)
      inputRuleCodeSet.filterNot(rule => rules.ruleCodes.contains(rule.name.getOrElse("")))
    } else {
      val inputRuleCodeSet = input.ruleCode.result.orError("rule code", input.transactionId)
      inputRuleCodeSet.filter(rule => rules.ruleCodes.contains(rule.name.getOrElse("")))
    }

    formParserResponse(filteredRuleCode, input)
  }

  /**
   * Establish ONE ruleType (or table, or kinesis stream) to rule codes mapping at the schema level.
   * Oddly, uncategorized ruleType contains all rule codes from 5 partitioned tables.
   */
  def extractRuleCode(ruleType: String, input: TransactionInput) = {
    if (ruleType.toLowerCase.contains(UNCATEGORIZED_RC)) {
      List(input.rulCodeSchema.filter(_.kinesisStream.equals(ruleType)).head.copy(
                                                                                   ruleCodes = input.rulCodeSchema
                                                                                     .filterNot(_.kinesisStream
                                                                                                  .equals(ruleType))
                                                                                     .map(_.ruleCodes).flatten.toSet
                                                                                 )
          )
    }
    else {
      input.rulCodeSchema.filter {
        rcSchema =>
        val name = rcSchema.kinesisStream
        name.equals(ruleType)
      }
    }
  }

}

object RuleCodeParser {

  def apply() = {
    new RuleCodeParser()
  }

}
