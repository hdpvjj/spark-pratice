package me.socure.etlv3.parser.kyccode

import argonaut.ACursor
import me.socure.etlv3.common._
import me.socure.etlv3.parser.{RichCursor, RichDecodeResult, RichDecodeResultOpt, SimpleDataParser}
import org.json4s.{DefaultFormats, Formats}

import scala.collection.immutable.ListMap

class KYCCodeParser extends SimpleDataParser[TransactionInput, ParserResponse] {

  implicit val jsonFormats: Formats = DefaultFormats

  def extractFromPayload(trxInput: TransactionInput, param: String): ACursor = {
    trxInput.payload.hcursor --\ "detailsJson" --\ "kyc" --\ param
  }

  def extractParameter(trxInput: TransactionInput, param: String): Option[String] = {
    extractFromPayload(trxInput, param).focusSafe.map(_.as[Option[JsonValue[String]]]).lift
      .map(_.flatten).orError(param,
      trxInput.transactionId) match {
      case Some(param_v) => param_v.value
      case _ => None
    }
  }

  override
  def parse(in0: TransactionInput): ParserResponse = {
    val transaction = ListMap(
      "transaction_id" -> in0.transactionId,

      "transaction_date" -> in0.transactionDate.toString,

      "account_id" -> in0.accountId.map(acctid => acctid.toString).getOrElse(""),

      "run_id" -> (in0.payload.hcursor --\ "runId")
        .focusSafe.map(_.as[Option[String]]).lift.map(_.flatten).orError("runId", in0.transactionId),

      "zip" -> {
        extractParameter(in0, "zip") match {
          case Some(zip) if zip.trim.nonEmpty => zip
          case _ => None
        }
      },

      "first_name" -> {
        extractParameter(in0, "firstname") match {
          case Some(first_name) if first_name.trim.nonEmpty => first_name
          case _ => None
        }
      },

      "mobile_number" -> {
        extractParameter(in0, "mobilenumber") match {
          case Some(mobile_number) if mobile_number.trim.nonEmpty => mobile_number
          case _ => None
        }
      },

      "city" -> {
        extractParameter(in0, "city") match {
          case Some(city) if city.trim.nonEmpty => city
          case _ => None
        }
      },

      "dob" -> {
        extractParameter(in0, "dob") match {
          case Some(dob) if dob.trim.nonEmpty => dob
          case _ => None
        }
      },

      "surname" -> {
        extractParameter(in0, "surname") match {
          case Some(surname) if surname.trim.nonEmpty => surname
          case _ => None
        }
      },

      "street_address" -> {
        extractParameter(in0, "streetaddress") match {
          case Some(street_address) if street_address.trim.nonEmpty => street_address
          case _ => None
        }
      },

      "state" -> {
        extractParameter(in0, "state") match {
          case Some(state) if state.trim.nonEmpty => state
          case _ => None
        }
      },

      "ssn" -> {
        extractParameter(in0, "ssn") match {
          case Some(ssn) if ssn.trim.nonEmpty => ssn
          case _ => None
        }
      },

      "email" -> {
        extractParameter(in0, "email") match {
          case Some(email) if email.trim.nonEmpty => email
          case _ => None
        }
      },
      "tetl_proc_time" -> in0.tetlProcTime.toString
    )
    ParserResponse(
      data = KYCCode(
        transactionId = in0.transactionId,
        accountId = in0.accountId.map(acctid => acctid.toString).getOrElse(""),
        payload = if (transaction.isEmpty) None else Some(org.json4s.jackson.Serialization.write(transaction))
      ),
      streamType = KinesisStreamTypes.KYCCodeStream.toString
    )
  }
}

object KYCCodeParser {
  def apply(): KYCCodeParser = {
    new KYCCodeParser()
  }
}

