package me.socure.etlv3.parser.modelscore

object ModelTypes extends Enumeration {
  type ModelType = Value

  val Fraud                 : ModelType = Value(1, "Fraud")
  val AddressRisk           : ModelType = Value(2, "AddressRisk")
  val EmailRisk             : ModelType = Value(3, "EmailRisk")
  val PhoneRisk             : ModelType = Value(4, "PhoneRisk")
  val NameAddressCorrelation: ModelType = Value(5, "NameAddressCorrelation")
  val NameEmailCorrelation  : ModelType = Value(6, "NameEmailCorrelation")
  val NamePhoneCorrelation  : ModelType = Value(7, "NamePhoneCorrelation")
  val Synthetic             : ModelType = Value(8, "Synthetic")
}
