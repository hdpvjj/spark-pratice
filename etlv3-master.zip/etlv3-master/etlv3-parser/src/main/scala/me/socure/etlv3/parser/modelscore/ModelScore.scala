package me.socure.etlv3.parser.modelscore

import me.socure.etlv3.parser.modelscore.AssociationTypes.AssociationType
import me.socure.etlv3.parser.modelscore.ModelTypes.ModelType

case
class ModelScore(
                  modelName: Option[String],
                  modelVersion  : Option[String],
                  modelIdentifier: Option[String],
                  associationType: Option[AssociationType],
                  modelType: Option[ModelType],
                  modelId: Option[Long],
                  originalScore: Option[Double],
                  quantileScore: Option[Double],
                  outputScore: Option[Double]
                ) {
  def isEmpty: Boolean = modelIdentifier.isEmpty
}
