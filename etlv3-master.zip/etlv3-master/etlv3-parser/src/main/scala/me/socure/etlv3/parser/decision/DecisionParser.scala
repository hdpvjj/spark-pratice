package me.socure.etlv3.parser.decision

import me.socure.etlv3.common._
import me.socure.etlv3.parser.{SimpleDataParser, _}
import org.json4s.{DefaultFormats, Formats}

import scala.collection.immutable.ListMap
import scala.language.implicitConversions

class DecisionParser extends SimpleDataParser[TransactionInput, ParserResponse] {

  implicit val jsonFormats: Formats = DefaultFormats


  def extractStrJsonValue(paramValue: Option[JsonValue[String]]): Option[String] = {
    paramValue match {
      case Some(pValue) => pValue.value
      case _ => None
    }
  }

  override
  def parse(input: TransactionInput): ParserResponse = {
    val detailsOpt = (input.payload.hcursor --\ "responseJson" --\ "decision" --\ "details")
      .focus.map(x => x.nospaces).getOrElse("{}") match {
      case "{}" => None
      case jStr => Some(jStr)
    }
    val transaction = ListMap(
      "transaction_id" -> input.transactionId,
      "account_id" -> input.accountId.map(acctid => acctid.toString).getOrElse(""),
      "transaction_date" -> input.transactionDate.toString,
      "run_id" -> extractStrJsonValue((input.payload.hcursor --\ "runId").focusSafe.map(_.as[Option[JsonValue[String]]])
        .lift.map(_.flatten).orError("runId", input.transactionId)),
      "value" -> extractStrJsonValue((input.payload.hcursor --\ "responseJson" --\ "decision" --\ "value")
        .as[Option[JsonValue[String]]].orError("value", input.transactionId)),
      "model_name" -> extractStrJsonValue((input.payload.hcursor --\ "responseJson" --\ "decision" --\ "modelName")
        .as[Option[JsonValue[String]]].orError("model_name", input.transactionId)),
      "model_version" -> extractStrJsonValue((input.payload.hcursor --\ "responseJson" --\ "decision" --\ "modelVersion")
        .as[Option[JsonValue[String]]].orError("model_version", input.transactionId)),
      "details" -> detailsOpt,
      "tetl_proc_time" -> input.tetlProcTime.toString
    )
    ParserResponse(
      data = Decision(
        transactionId = input.transactionId,
        accountId = input.accountId.map(acctid => acctid.toString).getOrElse(""),
        payload = if (transaction.isEmpty ||
//          transaction("model_name").toString.isEmpty || // empty evaluate to "Some()" which always pass
//          transaction("model_version").toString.isEmpty
          transaction("model_name").asInstanceOf[Option[JsonValue[String]]].getOrElse("").asInstanceOf[String].equals("") ||
          transaction("model_version").asInstanceOf[Option[JsonValue[String]]].getOrElse("").asInstanceOf[String].equals("")
          ) None
        else
          Some(org.json4s.jackson.Serialization.write(transaction))
      ),
      streamType = KinesisStreamTypes.DecisionStream.toString
    )
  }
}

object DecisionParser {
  def apply(): DecisionParser = {
    new DecisionParser()
  }
}
