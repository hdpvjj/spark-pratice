package me.socure.etlv3.parser.util

object Constants {

   val UNCATEGORIZED_RC  = "uncategorized"

}
