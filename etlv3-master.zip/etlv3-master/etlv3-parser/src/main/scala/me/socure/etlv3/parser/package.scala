package me.socure.etlv3

import argonaut.{ACursor, DecodeResult, HCursor, Json}

package object parser {

  implicit class RichDecodeResultEither[E, A](val self: Either[E, A]) extends AnyVal {
    def orError(data: String, transactionId: String): A = {
      self match {
        case Right(res) => res
        case Left(err)  => throw DataParsingException(s"[TrxId=$transactionId] $data", String.valueOf(err))
      }
    }
  }

  implicit class RichDecodeResult[A](val self: DecodeResult[A]) extends AnyVal {
    def orError(data: String, transactionId: String): A = self.result.orError(data, transactionId)
  }

  implicit class RichDecodeResultOpt[A](val self: Option[DecodeResult[A]]) extends AnyVal {
    def lift: DecodeResult[Option[A]] = {
      self match {
        case Some(res) => res.map(Option(_))
        case None      => DecodeResult.ok(None)
      }
    }
  }

  implicit class RichCursor[A](val self: ACursor) extends AnyVal {

    def focusSafe: Option[Json] = self.focus.filterNot(_.isNull)

    def opt[B](f: Json => DecodeResult[B]): DecodeResult[Option[B]] = {
      self
      .focusSafe
      .map(f)
      .lift
    }

    def opth[B](f: HCursor => DecodeResult[B]): DecodeResult[Option[B]] = {
      self
      .focusSafe
      .map(j => f(j.hcursor))
      .lift
    }
  }

}
