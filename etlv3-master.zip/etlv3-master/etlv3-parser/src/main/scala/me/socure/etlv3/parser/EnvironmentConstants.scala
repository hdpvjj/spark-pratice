package me.socure.etlv3.parser

object EnvironmentConstants extends Enumeration {

  type EnvironmentConstants = Value

  val PRODUCTION_ENVIRONMENT  = Value(1, "Production")
  val DEVELOPMENT_ENVIRONMENT = Value(2, "Development")
  val SANDBOX_ENVIRONMENT     = Value(3, "Sandbox")

}
