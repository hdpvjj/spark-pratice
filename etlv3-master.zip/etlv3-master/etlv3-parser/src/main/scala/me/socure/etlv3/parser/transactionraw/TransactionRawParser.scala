package me.socure.etlv3.parser.transactionraw

import java.nio.charset.StandardCharsets
import me.socure.dapl.snowflake.crypto.Encryption
import me.socure.etlv3.common.{KinesisStreamTypes, ParserResponse, TransactionInput, TransactionRaw}
import org.json4s.{DefaultFormats, Formats}
import scala.language.implicitConversions
import me.socure.etlv3.parser._
import scala.collection.immutable.ListMap


class TransactionRawParser(nonConsentingAccounts: List[Long]) extends SimplePiiDataParser[TransactionInput, Map[String, Array[Byte]], ParserResponse] {

  implicit val jsonFormats: Formats = DefaultFormats

  override
  def parse(in0: TransactionInput, in1: Map[String, Array[Byte]]): ParserResponse = {
    val encData = in0.accountId.map(acctid => acctid.toString) match {
      case Some(actId) => in1.get(actId) match {
        case Some(key) => (key, actId.getBytes(StandardCharsets.UTF_8))
        case _         => throw new Exception(s"For trxId ${in0.transactionId} account id ${actId} DataKey not found")
      }
      case _           => throw new Exception(s"For trxId ${in0.transactionId} account id not found")
    }

    val response = (in0.payload.hcursor --\ "response").focusSafe.map(_.as[Option[String]]).lift
                                                              .map(_.flatten).orError("response", in0.transactionId)

    val payload = response match {
      case Some(res) => Some(org.json4s.jackson.Serialization.write(
        ListMap("transaction_id" -> in0.transactionId,
                                   "account_id" -> in0.accountId.map(acctId => acctId.toString).getOrElse(""),
                                   "run_id" -> (in0.payload.hcursor --\ "runId").focusSafe.map(_.as[Option[String]]).lift.map(_.flatten).orError("runId", in0.transactionId),
                                   "transaction_date" -> in0.transactionDate.toString,
                                   "transaction_response" -> Some(Encryption().encryptRaw(res.getBytes(StandardCharsets.UTF_8),encData._1, encData._2)),
                                   "tetl_proc_time" -> in0.tetlProcTime.toString
        )))
      case _ => None
    }

    ParserResponse(
                    data = TransactionRaw(
                                        transactionId = in0.transactionId,
                                        accountId = in0.accountId.map(acctid => acctid.toString).getOrElse(""),
                                        payload = payload
                                      ),
                    streamType =  if(nonConsentingAccounts.contains(in0.accountId.getOrElse(throw new Exception(s"For trxId ${in0.transactionId} account id not found")))) KinesisStreamTypes.NonConsentingTransactionRawStream.toString else KinesisStreamTypes.TransactionRawStream.toString
                  )

  }

}

object TransactionRawParser {
  def apply(nonConsentingAccounts: List[Long]): TransactionRawParser = {
    new TransactionRawParser(nonConsentingAccounts)
  }
}
