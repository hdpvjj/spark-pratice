package me.socure.etlv3.parser.util

import java.net.InetAddress

object IpAddressMatcherUtil {

  def isIpInRange(ipAddress: String, address: String): Boolean = {
    var maskBits:Int = 0
    var ip = address
    var requiredAddress: InetAddress = null
    if (ip.indexOf(47) > 0) {
      val addressAndMask = ip.split("/")
      ip = addressAndMask(0)
      maskBits = addressAndMask(1).toInt
    } else {
      maskBits = -1
    }

    requiredAddress = InetAddress.getByName(ip)

    val remoteAddress = InetAddress.getByName(ipAddress)

    if(maskBits < 0) {
      return remoteAddress.equals(requiredAddress)
    } else {

      val remAddress = remoteAddress.getAddress

      val reqAddress = requiredAddress.getAddress

      val nMaskFullBytes = maskBits / 8

      val finalByte: Byte = ('\uff00' >> (maskBits.toByte & 7)).toByte

      var i = 0
      while ( {i < nMaskFullBytes }) {
        if (remAddress(i) != reqAddress(i)) return false

        {i += 1; i }
      }

      if (finalByte != 0) {
        return (remAddress(nMaskFullBytes) & finalByte) == (reqAddress(nMaskFullBytes) & finalByte)
      }
      else {
        return true
      }
    }

  }

}
