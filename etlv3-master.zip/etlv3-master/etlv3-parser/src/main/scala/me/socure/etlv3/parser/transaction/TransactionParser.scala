package me.socure.etlv3.parser.transaction

import me.socure.etlv3.common._
import me.socure.etlv3.parser.SimpleDataParser
import org.json4s.{DefaultFormats, Formats}
import me.socure.etlv3.parser.util.ParserUtil._
import argonaut.DecodeResult
import scala.io.Source
import scala.language.implicitConversions
import me.socure.etlv3.parser._
import me.socure.etlv3.parser.util.ParserUtil
import scala.collection.immutable.ListMap
import me.socure.etlv3.parser.transaction.HeuristicUtil._
import scala.util.Try

class TransactionParser extends SimpleDataParser[TransactionInput, ParserResponse] {

  implicit val jsonFormats: Formats = DefaultFormats

  private
  val errorCodesMapping: Map[String, Int] = {
    val source = Source.fromURL(getClass.getResource("/error_codes.csv"))
    val res = source
      .getLines()
      .flatMap {
        line =>
          Option(line)
            .map(_.trim)
            .filterNot(_.isEmpty)
            .map(_.split(",", 2).map(_.trim).filterNot(_.isEmpty))
            .filter(_.length == 2)
            .map {
              case Array(errorCode, errorMsg) =>
                errorMsg -> errorCode.toInt
            }
      }
      .toMap
    source.close()
    res
  }

  def isParameterProvided(param: Option[String]) = {
    param match {
      case Some(p) if (p.trim.nonEmpty) => true
      case _ => false
    }
  }

  def extractStrJsonValue(paramValue: Option[JsonValue[String]]) = {
    paramValue match {
      case Some(pValue) => pValue.value
      case _ => None
    }
  }

  def extractLongJsonValue(paramValue: Option[JsonValue[Long]]) = {
    paramValue match {
      case Some(pValue) => pValue.value
      case _ => None
    }
  }

  def getPhysicalAddress(input: TransactionInput, param: String) = {
    extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ param)
                          .focusSafe.map(_.as[Option[JsonValue[String]]]).lift.map(_.flatten)
                          .orError(param, input.transactionId)
                       )
  }

  def resolveAddress(input: TransactionInput, param: String) = {
    if(input.environmentId.isDefined && input.environmentId.contains(3)) {
      Try {
        getPhysicalAddress(input, param)
      }.getOrElse(
                   (input.payload.hcursor --\ "parametersJson" --\ param).focus.map(x => x.nospaces)

                 )

    } else {
      getPhysicalAddress(input, param)
    }

  }

  override
  def parse(input: TransactionInput): ParserResponse = {
    val error_message = for {error_message <- (input.payload.hcursor --\ "responseJson" --\ "msg").opt(_.as[Option[String]]).map(_.flatten)} yield error_message
    val status = (input.payload.hcursor --\ "error").as[Option[JsonValue[Boolean]]].orError("status", input.transactionId) match {
      case Some(pValue) => pValue.value.map(err => !err)
      case _ => None
    }

    val isIpAddress = (input.payload.hcursor --\ "parametersJson" --\ "ipaddress").as[Option[JsonValue[String]]]

    val ipAddress = if (isIpAddress.isError) {
      Some((input.payload.hcursor --\ "parametersJson" --\ "ipaddress").as[Option[Set[String]]].map(_.getOrElse
      (Set.empty[String]).map(_.trim.toLowerCase).filterNot(_.isEmpty)).orError("ipAddress", input.transactionId).mkString("|"))
    } else {
      isIpAddress.result.right.getOrElse(None) match {
        case Some(ipAddress) => ipAddress.value
        case _ => None
      }
    }

    val userId = if(input.accountId.map(id => input.userIdConsentingAccounts.contains(id)).getOrElse(false)){
      extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "userid").focusSafe.map(_.as[Option[JsonValue[String]]]).lift.map(_.flatten).orError("userid", input.transactionId))
    } else {
      None
    }

    val firstName = extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "firstname").focusSafe.map(_.as[Option[JsonValue[String]]])
      .lift.map(_.flatten).orError("firstname", input.transactionId))
    val surName = extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "surname").focusSafe.map(_.as[Option[JsonValue[String]]]).lift
      .map(_.flatten).orError("surname", input.transactionId))
    val dob = extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "dob").focusSafe.map(_.as[Option[JsonValue[String]]]).lift.map(_.flatten).orError("dob", input.transactionId))
    val mobileNumber = extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "mobilenumber").focusSafe.map(_.as[Option[JsonValue[String]]]).lift.map(_.flatten).orError("mobilenumber", input.transactionId))
    val mobileHeuristic = extractMobileInfo(mobileNumber)
    val nationalId = extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "nationalid").focusSafe.map(_.as[Option[JsonValue[String]]]).lift.map(_.flatten).orError("nationalId", input.transactionId))
    val ssnHeuristic = nationalId match {
      case Some(ssn) if (ssn.nonEmpty) =>
        Some(NationalId(
          isAllOne = isAllOneOrZero(Some(ssn), '1'),
          isAllZero = isAllOneOrZero(Some(ssn), '0'),
          isValid = isValidSSN(Some(ssn)),
          sizeOfSSN = getSSNSize(Some(ssn))
        ))

      case _ => None
    }
    val zip = extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "zip").focusSafe.map(_.as[Option[JsonValue[String]]]).lift.map(_.flatten).orError("zip", input.transactionId))
    val email = extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "email").focusSafe.map(_.as[Option[JsonValue[String]]]).lift.map(_.flatten).orError("email", input.transactionId))
    val physicalAddress = resolveAddress(input, "physicaladdress")
    val physicalAddress2 = resolveAddress(input, "physicaladdress2")
    val fullname = extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "fullname").focusSafe.map(_.as[Option[JsonValue[String]]])
      .lift.map(_.flatten).orError("fullname", input.transactionId))
    val modules = (input.payload.hcursor --\ "parametersJson" --\ "modules").opt(_.as[Set[String]]).map(_.getOrElse
    (Set.empty[String]).map(_.trim.toLowerCase).filterNot(_.isEmpty)).value
    val overallDecision = extractStrJsonValue((input.payload.hcursor --\ "responseJson" --\ "decision" --\ "value" ||| input.payload.hcursor --\ "responseJson" --\ "decision" --\ "response").focusSafe.map(_.as[Option[JsonValue[String]]]).lift.map(_.flatten).orError("overalldecision", input.transactionId))
    val state  = extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "state").focusSafe.map(_.as[Option[JsonValue[String]]])
      .lift.map(_.flatten).orError("state", input.transactionId))
    val city = extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "city").focusSafe.map(_.as[Option[JsonValue[String]]])
      .lift.map(_.flatten).orError("city", input.transactionId))
    val geocode = extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "geocode").focusSafe.map(_.as[Option[JsonValue[String]]])
      .lift.map(_.flatten).orError("geocode", input.transactionId))

    val transaction = ListMap(
      "transaction_id" -> input.transactionId,
      "account_id" -> input.accountId.map(acctid => acctid.toString).getOrElse(""),
      "environment_id" -> input.environmentId,
      "api_key" -> extractStrJsonValue((input.payload.hcursor --\ "apiKey").focusSafe.map(_.as[Option[JsonValue[String]]])
        .lift.map(_.flatten).orError("apiKey", input.transactionId)),
      "api_type" -> input.api.apiType.id,
      "api_version" -> input.api.version.id,
      "customer_user_id" -> extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "customeruserid")
        .as[Option[JsonValue[String]]].result.orError("customeruserid", input.transactionId)),
      "run_id" -> extractStrJsonValue((input.payload.hcursor --\ "runId").focusSafe.map(_.as[Option[JsonValue[String]]])
        .lift.map(_.flatten).orError("runId", input.transactionId)),
      "status" -> status,
      "error_code" -> DecodeResult.ok(error_message.orError("error_message", input
        .transactionId).flatMap(errorCodesMapping.get)).orError("error_code", input
        .transactionId),
      "error_msg" -> error_message.orError("error_message", input.transactionId),
      "processing_time" -> extractLongJsonValue((input.payload.hcursor --\ "processingTime").as[Option[JsonValue[Long]]]
        .orError("processing_time", input.transactionId)),
      "transaction_date" -> input.transactionDate.toString,
      "force_refresh" -> {
        (input.payload.hcursor --\ "parametersJson" --\ "forcerefresh").as[Option[JsonValue[Boolean]]].orError("force_refresh", input.transactionId) match {
          case Some(pValue) => pValue.value
          case _ => None
        }
      },
      "entity_type" -> extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "entityType")
                                             .as[Option[JsonValue[String]]].orError("entityType", input.transactionId)),
      "order_channel" -> extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "orderchannel")
        .as[Option[JsonValue[String]]].orError("order_channel", input.transactionId)),
      "last_order_date" -> extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "lastorderdate")
        .as[Option[JsonValue[String]]].orError("last_order_date", input.transactionId)),
      "prev_order_count" -> extractLongJsonValue((input.payload.hcursor --\ "parametersJson" --\ "prevordercount")
        .as[Option[JsonValue[Long]]].orError("processing_time", input.transactionId)),
      "account_creation_date" -> extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\
        "accountcreationdate").as[Option[JsonValue[String]]].orError("account_creation_date", input.transactionId)),
      "order_amount" -> {
        (input.payload.hcursor --\ "parametersJson" --\ "orderamount")
          .as[Option[JsonValue[BigDecimal]]].orError("order_amount", input.transactionId) match {
          case Some(orderAmount) => orderAmount.value
          case _ => None
        }
      },
      "submission_date" -> extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "submissiondate")
        .as[Option[JsonValue[String]]].orError("submission_date", input.transactionId)),
      "error_reason" -> {
        if (!status.contains(true)) DecodeResult.ok((input.payload.hcursor --\ "responseJson" --\ "data").focusSafe.map(_.nospaces)).orError("error_reason", input.transactionId)
        else DecodeResult.ok(None).orError("error_reason", input.transactionId)
      },
      "is_consenting" -> {
        (input.payload.hcursor --\ "parametersJson" --\ "isConsenting")
          .as[Option[JsonValue[Boolean]]].orError("is_consenting", input.transactionId) match {
          case Some(isConsenting) => isConsenting.value
          case _ => None
        }
      },
      "device_session_id" -> extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\
        "deviceSessionId").as[Option[JsonValue[String]]].orError("device_session_id", input.transactionId)),
      "prev_unpaid_order_count" -> extractLongJsonValue((input.payload.hcursor --\ "parametersJson" --\ "prevUnpaidOrderCount")
        .as[Option[JsonValue[Long]]].orError("prev_unpaid_order_count", input.transactionId)),
      "user_consent" -> {
        (input.payload.hcursor --\ "parametersJson" --\ "userConsent").as[Option[JsonValue[Boolean]]].orError("user_consent", input.transactionId) match {
          case Some(userConsent) => userConsent.value
          case _ => None
        }
      },
      "document_uuid" -> input.documentUuid,
      "firstname_provided" -> isParameterProvided(firstName),
      "surname_provided" -> isParameterProvided(surName),
      "dob_provided" -> isParameterProvided(dob),
      "mobilenumber_provided" -> isParameterProvided(mobileNumber),
      "nationalid_provided" -> isParameterProvided(nationalId),
      "zip_provided" -> isParameterProvided(zip),
      "email_provided" -> isParameterProvided(email),
      "ipaddress_provided" -> isParameterProvided(ipAddress),
      "physicaladdress_provided" -> isParameterProvided(physicalAddress),
      "physicaladdress2_provided" -> isParameterProvided(physicalAddress2),
      "originofinvocation_provided" -> isParameterProvided((input.payload.hcursor --\ "originOfInvocation").focusSafe.map(_.as[Option[JsonValue[String]]]).lift.map(_.flatten).orError("originOfInvocation", input.transactionId) match {
        case Some(originOfInvocation) => originOfInvocation.value
        case _ => None
      }),
      "email_characters" -> {
        if (email.nonEmpty) email.map(e => e.length)
        else None
      },
      "firstname_characters" -> {
        if (firstName.nonEmpty) firstName.map(fn => fn.length)
        else None
      },
      "surname_characters" -> {
        if (surName.nonEmpty) surName.map(sn => sn.length)
        else None
      },
      "fullname_provided" -> isParameterProvided(fullname),
      "companyname_provided" -> isParameterProvided((input.payload.hcursor --\ "parametersJson" --\
        "companyname").focusSafe.map(_.as[Option[JsonValue[String]]]).lift.map
      (_.flatten).orError("companyname", input.transactionId)),

      "entity_name_provided" -> isParameterProvided((input.payload.hcursor --\ "parametersJson" --\
                                                     "entityName").focusSafe.map(_.as[Option[JsonValue[String]]]).lift.map
      (_.flatten).orError("entityName", input.transactionId)),
      "entity_type_provided" -> isParameterProvided((input.payload.hcursor --\ "parametersJson" --\
                                                     "entityType").focusSafe.map(_.as[Option[JsonValue[String]]]).lift.map
      (_.flatten).orError("entityType", input.transactionId)),
      "userid_provided" -> isParameterProvided(extractStrJsonValue(((input.payload.hcursor --\ "parametersJson" --\ "userid").as[Option[JsonValue[String]]])
        .result.orError("userid", input.transactionId))),
      "dob_age_decade" -> getDecade(input.transactionDate.getMillis, dob),
      "mobile_country_code" -> getCountryCode(mobileNumber, Some(input.transactionId)),
      "driverlicense_provided" -> isParameterProvided((input.payload.hcursor --\ "parametersJson" --\
        "driverlicense").focusSafe.map(_.as[Option[JsonValue[String]]]).lift
        .map(_.flatten).orError("driverlicense", input.transactionId)),
      "business_name_provided" -> isParameterProvided((input.payload.hcursor --\ "parametersJson" --\
                                                       "businessName").focusSafe.map(_.as[Option[JsonValue[String]]]).lift
                                                                      .map(_.flatten).orError("businessName", input.transactionId)),
      "driverlicensestate_provided" -> isParameterProvided((input.payload.hcursor --\ "parametersJson" --\
        "driverlicensestate").focusSafe.map(_.as[Option[JsonValue[String]]]).lift.map(_.flatten).orError("driverlicensestate", input.transactionId)),
      "module_alertlist" -> modules.forall(p => p.contains(ModuleTypes.AlertList.toString)),
      "module_kyc" -> modules.forall(p => p.contains(ModuleTypes.Kyc.toString)),
      "module_phonerisk" -> modules.forall(p => p.contains(ModuleTypes.PhoneRisk.toString)),
      "module_emailrisk" -> modules.forall(p => p.contains(ModuleTypes.EmailRisk.toString)),
      "module_addressrisk" -> modules.forall(p => p.contains(ModuleTypes.AddressRisk
        .toString)),
      "module_fraud" -> modules.forall(p => p.contains(ModuleTypes.Fraud.toString)),
      "module_synthetic" -> modules.forall(p => p.contains(ModuleTypes.Synthetic.toString)),
      "module_noop" -> modules.forall(p => p.contains(ModuleTypes.Noop.toString)),
      "module_watchlistpremier" -> modules.forall(p => p.contains(ModuleTypes
        .WatchlistPremier
        .toString)),
      "module_watchlistplus" -> modules.forall(p => p.contains(ModuleTypes.WatchlistPlus
        .toString)),
      "module_watchliststandard" -> modules.forall(p => p.contains(ModuleTypes
        .WatchlistStandard
        .toString)),
      "module_decision" -> modules.forall(p => p.contains(ModuleTypes.Decision.toString)),
      "module_ecbsv" -> modules.forall(p => p.contains(ModuleTypes.Ecbsv.toString)),
      "module_allcorrelations" -> modules.forall(p => p.contains(ModuleTypes.AllCorrelations
        .toString)),
      "module_social" -> modules.forall(p => p.contains(ModuleTypes.Social.toString)),
      "module_documentverification" -> modules.forall(p => p.contains(ModuleTypes
        .DocumentVerification.toString)),
      "module_prefill" -> modules.forall(p => p.contains(ModuleTypes.Prefill.toString)),
      "module_namephonecorrelation" -> modules.forall(p => p.contains(ModuleTypes
        .NamePhoneCorrelation.toString)),
      "module_nameemailcorrelation" -> modules.forall(p => p.contains(ModuleTypes
        .NameEmailCorrelation.toString)),
      "module_nameaddresscorrelation" -> modules.forall(p => p.contains(ModuleTypes
        .NameAddressCorrelation.toString)),
      "module_devicerisk" -> modules.forall(p => p.contains(ModuleTypes.DeviceRisk.toString)),
      "module_kycplus" -> modules.forall(p => p.contains(ModuleTypes.KycPlus.toString)),
      "module_accountintelligence" -> modules.forall(p => p.contains(ModuleTypes.AccountIntelligence.toString)),
      "previous_reference_id" -> extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "previousReferenceId").focusSafe.map(_.as[Option[JsonValue[String]]])
        .lift.map(_.flatten).orError("previousReferenceId", input.transactionId)),
      "overall_decision" -> overallDecision,
      "account_ip_address" -> extractStrJsonValue((input.payload.hcursor --\ "accountIpAddress").focusSafe.map(_.as[Option[JsonValue[String]]])
        .lift.map(_.flatten).orError("accountIpAddress", input.transactionId)),
      "city_provided" -> isParameterProvided(city),
      "state_provided" -> isParameterProvided(state),
      "geocode_provided" -> isParameterProvided(geocode),
      "email_domain" -> extractDomain(email),
      "yob" -> ParserUtil.getYear(dob),
      "dob_is_impossible_date" -> {
        if (ParserUtil.date(dob)) false else true
      },
      "ipaddress_is_in_private_subnet" -> {
        if (ipAddress.isDefined) Some(ipInRange(ipAddress)) else None
      },
      "mobilenumber_is_in_seq" -> {
        mobileHeuristic match {
          case Some(mobile) => mobile.isInSeq
          case _ => None
        }
      },
      "mobilenumber_is_all_one" -> {
        mobileHeuristic match {
          case Some(mobile) => mobile.isAllOne
          case _ => None
        }
      },
      "mobilenumber_is_all_same" -> {
        mobileHeuristic match {
          case Some(mobile) => mobile.isAllSame
          case _ => None
        }
      },
      "mobilenumber_is_alternate" -> {
        mobileHeuristic match {
          case Some(mobile) => mobile.isAlternate
          case _ => None
        }
      },
      "mobilenumber_digits" -> {
        mobileHeuristic match {
          case Some(mobile) => mobile.sizeOfMobileNumber
          case _ => None
        }
      },
      "nationalid_is_all_one" -> {
        ssnHeuristic match {
          case Some(ssn) => ssn.isAllOne
          case _ => None
        }
      },
      "nationalid_is_all_zero" -> {
        ssnHeuristic match {
          case Some(ssn) => ssn.isAllZero
          case _ => None
        }
      },
      "nationalid_is_valid" -> {
        ssnHeuristic match {
          case Some(ssn) => ssn.isValid
          case _ => None
        }
      },
      "nationalid_digits" -> {
        ssnHeuristic match {
          case Some(ssn) => ssn.sizeOfSSN
          case _ => None
        }
      },
      "zip_digits" -> {
        zip match {
          case Some(zip) => zip.size
          case _ => None
        }
      },
      "sai_inquries" -> {
        val res = PaymentExtractor.extractPaymentParameter(input, "payments")
        if (res.nonEmpty) {
          res.head.account match {
            case Some(payment) =>
              val inquiries = payment.inquiries
              inquiries match {
                case Some(inq) if (inq.nonEmpty) => inq.mkString(",")
                case _ => None
              }
            case _ => None
          }
        } else {
          None
        }
      },
      "tetl_proc_time" -> input.tetlProcTime.toString,
      "social" -> (input.payload.hcursor --\ "detailsJson" --\ "profilesFound").focusSafe.map(_.as[Option[String]])
        .lift.map(_.flatten).orError("city", input.transactionId).isDefined,
      "debug_transaction_id" -> (input.payload.hcursor --\ "debugJson" --\ "transactionId").focusSafe.map(_.as[Option[String]]).lift.map(_.flatten).orError("debug_transaction_id", input.transactionId),
      "country" -> extractStrJsonValue((input.payload.hcursor --\ "parametersJson" --\ "country").focusSafe.map(_.as[Option[JsonValue[String]]])
        .lift.map(_.flatten).orError("country", input.transactionId)),
      "user_id" -> userId
    )

    ParserResponse(
      data = Transaction(
        transactionId = input.transactionId,
        accountId = input.accountId.map(acctid => acctid.toString).getOrElse(""),
        payload = if (transaction.isEmpty) None else Some(org.json4s.jackson.Serialization.write(transaction))
      ),
      streamType = KinesisStreamTypes.TransactionStream.toString
    )
  }
}

object TransactionParser {
  def apply(): TransactionParser = {
    new TransactionParser()
  }
}
