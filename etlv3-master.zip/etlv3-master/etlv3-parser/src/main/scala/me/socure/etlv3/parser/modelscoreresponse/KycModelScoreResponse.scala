package me.socure.etlv3.parser.modelscoreresponse

case class KycModelScoreResponse(
                                  firstName: Option[Double],
                                  surName: Option[Double],
                                  streetAddress: Option[Double],
                                  city: Option[Double],
                                  state: Option[Double],
                                  zip: Option[Double],
                                  mobileNumber: Option[Double],
                                  dob: Option[Double],
                                  ssn: Option[Double]
                                )