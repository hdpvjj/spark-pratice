package me.socure.etlv3.parser.modelscore

object AssociationTypes extends Enumeration {
  type AssociationType = Value
  val Primary: AssociationType = Value(1, "primary")
  val Sigma  : AssociationType = Value(2, "sigma")
  val Custom : AssociationType = Value(3, "custom")
}
