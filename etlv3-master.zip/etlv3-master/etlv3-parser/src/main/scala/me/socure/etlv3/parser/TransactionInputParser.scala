package me.socure.etlv3.parser

import java.util.Base64
import me.socure.etlv3.common.{Api, RuleCodeSchema, TransactionInput, WrappedMsg}
import argonaut.{Json, Parse}
import me.socure.etlv3.parser.rulecode.RuleCodeCommon
import me.socure.etlv3.parser.util.ParserUtil
import org.joda.time.{DateTime, DateTimeZone}
import org.json4s.DefaultFormats
import scala.io.Source

trait TransactionInputParser {
  private implicit val FORMATS: DefaultFormats = DefaultFormats
  private def parseJson(json: Json, prop: String, transactionId: String): Json = {
    val jsonStrOpt = (json.hcursor --\ prop)
      .as[Option[String]]
      .map(_
             .flatMap(Option(_))
             .map(_.trim)
             .filter(_.nonEmpty)
             .filterNot(_.equalsIgnoreCase("null"))
          ).orError(prop, transactionId)
    jsonStrOpt.map { jsonStr =>
    Parse.parse(jsonStr).orError(prop, transactionId)
    }.getOrElse(Json.jEmptyObject)
  }

  private lazy val ruleCodesMapping: List[RuleCodeSchema] = {
    val ruleCodeFile = Source.fromURL(getClass.getResource("/rule_code_types.csv"))

    val mapTableToRuleCodes = ruleCodeFile.getLines.drop(1).map {
      line => {
        val cols = line.split(",").map(_.trim)
        (cols(3), cols(0).toLowerCase.replace(".", "_"))
      }
    }.toList.flatMap{case (t,c) => t.split('+').map(_.trim).map ((_, c)) }.groupBy(_._1).map{case (t, l) => t->l.map(_._2).toSet}

    val mapTableToParserAndStream = Map(
                                "rule_code_fraud" -> ("RuleCodeFraudParser", "ruleCodeFraudStream"),
                                "rule_code_compliance" -> ("RuleCodeComplianceParser", "ruleCodeComplianceStream"),
                                "rule_code_globals" -> ("RuleCodeGlobalParser", "ruleCodeGlobalStream"),
                                "rule_code_docv" -> ("RuleCodeDocvParser", "ruleCodeDocvStream"),
                                "rule_code_fraud_legacy" -> ("RuleCodeFraudLegacyParser", "ruleCodeFraudLegacyStream"),
                                "rule_code_uncategorized" -> ("RuleCodeUncategorizedParser", "ruleCodeUncategorizedStream")
                                       )
    mapTableToRuleCodes.map(x => RuleCodeSchema(mapTableToParserAndStream.get(x._1).get._1, mapTableToParserAndStream.get(x._1).get._2, x._2)).toList
  }

  def parse(message: WrappedMsg, userIdConsentingAccounts: List[Long] = List.empty[Long]): TransactionInput = {
    val messageId = message.id
    val jsonStr = ParserUtil.gzipDecompress(Base64.getDecoder.decode(message.body))
    val json = Parse.parse(jsonStr).orError("MessageBody", "unknown")
    val transactionId = (json.hcursor --\ "transactionId").as[String].orError("transactionId", "unknown")
    val apiName = (json.hcursor --\ "apiName").as[String].orError("apiName", transactionId)
    val api = Api.parse(apiName).getOrElse(throw UnsupportedApiException(apiName))
    val transactionDate = (json.hcursor --\ "transactionDate").as[Long].map(millis => new DateTime(millis, DateTimeZone.UTC)).orError("transactionDate", transactionId)
    val parameters = parseJson(json, "parameters", transactionId)
    val details = parseJson(json, "details", transactionId)
    val debugBase = parseJson(json, "debug", transactionId)
    val debugOpt = if(debugBase.isArray) debugBase.arrayOrEmpty.headOption else Some(debugBase)
    val debug = debugOpt.getOrElse(Json.jEmptyObject)
    val response = parseJson(json, "response", transactionId)
    val reasonCodes = parseJson(json, "reasonCodes", transactionId)
    val accountId = (json.hcursor --\ "accountId").focusSafe.map(_.as[Option[Long]]).lift.map(_.flatten).orError("accountId", transactionId)
    val environmentId = (json.hcursor --\ "environmentType").focusSafe.map(_.as[Option[Long]]).lift.map(_.flatten).orError("environmentId", transactionId)
    val runId = (json.hcursor --\ "runId").focusSafe.map(_.as[Option[String]]).lift.map(_.flatten).orError("runId", transactionId)
    val country = (parameters.hcursor --\ "country").focusSafe.map(_.as[Option[String]]).lift.map(_.flatten).orError("country", transactionId)
    val documentUuid: Option[String] = (parameters.hcursor --\ "documentuuid").focusSafe.map(_.as[Option[String]]).lift.map(_.flatten).orError("documentUuid", transactionId)
    val internalWorkLogs = parseJson(json, "internalWorkLogs", transactionId)
    val payload = json.deepmerge(Json.obj(
                                           "parametersJson" -> parameters,
                                           "detailsJson" -> details,
                                           "debugJson" -> debug,
                                           "responseJson" -> response,
                                           "reasonCodesJson" -> reasonCodes,
                                           "internalWorkLogsJson" -> internalWorkLogs
                                         ))

    TransactionInput(
                      messageId = messageId,
                      transactionId = transactionId,
                      transactionDate = transactionDate,
                      api = api,
                      accountId = accountId,
                      environmentId = environmentId,
                      runId = runId,
                      country = country,
                      payload = payload,
                      ruleCode = RuleCodeCommon.parseRuleCode(payload),
                      rulCodeSchema  = ruleCodesMapping,
                      documentUuid = documentUuid,
                      userIdConsentingAccounts = userIdConsentingAccounts
                    )
  }
}

object TransactionInputParser extends TransactionInputParser
