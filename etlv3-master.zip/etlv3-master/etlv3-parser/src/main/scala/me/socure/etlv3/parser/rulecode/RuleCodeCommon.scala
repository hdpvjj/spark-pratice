package me.socure.etlv3.parser.rulecode

import argonaut.{ACursor, DecodeJson, DecodeResult, Json}
import me.socure.etlv3.parser.util.Constants._
import me.socure.etlv3.common.{ParserResponse, RuleCode, RuleCodeValue, TransactionInput}
import me.socure.etlv3.parser._
import org.json4s.{DefaultFormats, Formats}
import scala.collection.immutable.ListMap

object RuleCodeCommon {
  private implicit val formats: Formats = DefaultFormats
  val renameMapping = Map(
                           "acxiom_val" -> "acval",
                           "bossval" -> "boval",
                           "ssnval" -> "ssval",
                           "ofacval" -> "ofval",
                           "sdnval" -> "sdval",
                           "fseval" -> "feval"
                         )

  val decodeNumerical: DecodeJson[RuleCode] = DecodeJson {
    h =>
    for {
      ruleCodeName <- (h --\ "rulecode").as[Option[String]]
      ruleCodeValue <- (h --\ "originalScore").as[Option[String]]
    } yield RuleCode(
                      name = ruleCodeName.map(rcName => rcName.substring(rcName.indexOf('.') + 1)).map(rc => rc
                                                                                                             .replace
                                                                                                             (".", "_")
                                                                                                      ),
                      value = ruleCodeValue
                    )
  }

  val decodeCategorical: DecodeJson[RuleCode] = DecodeJson {
    h =>
    for {
      ruleCodeName <- (h --\ "rulecode").as[Option[String]]
      ruleCodeValue <- (h --\ "value").as[Option[String]]
    } yield RuleCode(
                      name = ruleCodeName.map(rc => rc.replace(".", "_")),
                      value = ruleCodeValue
                    )
  }

  def parseNumerical(debug: ACursor): DecodeResult[Set[RuleCode]] = {
    (debug --\ "rule_codes").opt {
      json =>
      implicit val decodeJson: DecodeJson[RuleCode] = decodeNumerical
      json.as[Set[RuleCode]]
    }.map(_.getOrElse(Set.empty[RuleCode]))
  }

  def parseCategorical(debug: ACursor): DecodeResult[Set[RuleCode]] = {
    (debug --\ "categorical_values").opt {
      json =>
      implicit val decodeJson: DecodeJson[RuleCode] = decodeCategorical
      json.as[Set[RuleCode]]
    }.map(_.getOrElse(Set.empty[RuleCode]))
  }

  def remap(rc: RuleCode): RuleCode = {
    val rcLower = rc.lower
    rcLower.copy(
                  name = rcLower.name.map(n => renameMapping.getOrElse(n, n))
                )
  }

  def parseRuleCode(input: Json) = {
    val debug = input.hcursor --\ "debugJson"
    for {
      numerical <- parseNumerical(debug)
      categorical <- parseCategorical(debug)
    } yield {
      val allRules = numerical ++ categorical
      allRules
      .filterNot(_.isEmpty)
      .map(remap)
    }
  }

  def formParserResponse(filteredRuleCode: Set[RuleCode], input: TransactionInput) = {

    def getPayload() = {
                                            ListMap("transaction_id"
                                                          -> input
                                                             .transactionId,
                                                          "account_id" ->
                                                          input.accountId.map
                                                          (acctId =>
                                                             acctId
                                                             .toString
                                                          )
                                                          .getOrElse(""),
                                                          "run_id" -> (
                                                                      input
                                                                      .payload.hcursor --\
                                                                      "runId"
                                                                      )
                                                            .focusSafe.map(_.as[Option[String]])
                                                            .lift.map(_.flatten).orError("runId",
                                                                                         input
                                                                                         .transactionId
                                                                                        ),
                                                          "transaction_date" -> input
                                                                                .transactionDate.toString,
                                                          "tetl_proc_time" -> input.tetlProcTime.toString
                                                         )
    }

    def getResponse(payload: Option[String]) = {
      ParserResponse(
                      data = RuleCodeValue(
                                            transactionId = input.transactionId,
                                            accountId = input.accountId.map(acctId => acctId.toString).getOrElse(""),
                                            payload = payload
                                          ),
                      streamType = input.rulCodeSchema.head.kinesisStream
                    )
    }

    if(!input.rulCodeSchema.head.kinesisStream.toLowerCase.contains(UNCATEGORIZED_RC)) {
      val rc = filteredRuleCode.map {r: RuleCode => (r.name.get -> r.value.getOrElse(""))}.toMap
      val payload = if(rc.isEmpty) None else Some(org.json4s.jackson.Serialization.write(getPayload() ++ rc))
      getResponse(payload)
    } else {

      val rc = Map("rule_codes" -> filteredRuleCode.foldLeft(Map.empty[String, String]){(s,v) =>
      s ++ Map(v.name.get -> v.value.get)
      })

      val payload = rc.get("rule_codes") match {
        case Some(ruleMap) if(ruleMap.isEmpty) => None
        case Some(_) =>  Some(org.json4s.jackson.Serialization.write(getPayload() ++ rc))
        case _ => None
      }

      getResponse(payload)
    }
  }

}
