package me.socure.etlv3.parser.util

import java.io.{BufferedInputStream, ByteArrayInputStream}
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.zip.GZIPInputStream

import com.google.i18n.phonenumbers.PhoneNumberUtil
import org.apache.commons.io.IOUtils
import org.apache.commons.lang3.time.DateFormatUtils
import org.apache.commons.validator.routines.DateValidator
import org.joda.time.format.DateTimeFormat
import org.joda.time.{DateTime, DateTimeZone}
import org.slf4j.LoggerFactory

import scala.concurrent.Future
import scala.io.Source
import scala.util.{Failure, Success, Try}
import scala.util.control.NonFatal

object ParserUtil {

  private val logger = LoggerFactory.getLogger(getClass)
  val dateFormat    = "yyyyMMdd"
  val dateFormatAlt = "yyyy/MM/dd"
  val dateValidator = DateValidator.getInstance
  val Max_Dob_Age   = 20

  def gzipDecompress(bytes: Array[Byte]): String = {
    new String(
                IOUtils.toByteArray(
                                     new GZIPInputStream(
                                                          new BufferedInputStream(
                                                                                   new ByteArrayInputStream(bytes)
                                                                                 )
                                                        )
                                   ),
                StandardCharsets.UTF_8
              )
  }

  def safeF[A](f: => Future[A]): Future[A] = {
    try f
    catch {
      case NonFatal(ex) => Future.failed(ex)
    }
  }

  def getDateTime(str: String): Option[DateTime] = {
    if (str.isEmpty) return None
    if (str.contains("/")) {
      Some(new DateTime(new SimpleDateFormat(dateFormatAlt).parse(str), DateTimeZone.UTC))
    }
    else if (str.contains("-")) {
      Some(new DateTime(new SimpleDateFormat(DateFormatUtils.ISO_DATE_FORMAT.getPattern).parse(str), DateTimeZone.UTC))
    }
    else if (str.matches("""(\d\d\d\d)(\d\d)(\d\d)""")) {
      Some(DateTimeFormat.forPattern(dateFormat).parseDateTime(str))
    }
    else {
      Try(new DateTime(new SimpleDateFormat(dateFormat).parse(str), DateTimeZone.UTC)) match {
        case Success(value) => Some(value)
        case Failure(_)     => None
      }
    }
  }

  def getYear(dt: Option[String]): Option[Int] =
    dt match {
      case Some(date) =>
      if (validateDate(date)) {
        getDateTime(date) match {
          case Some(d) => Some(d.year().get())
          case _ => None
        }
      } else None
      case _ => None
    }

  def validateDate(date: String): Boolean = {
    if (date.nonEmpty &&
        (
        dateValidator.isValid(date, DateFormatUtils.ISO_DATE_FORMAT.getPattern) ||
        dateValidator.isValid(date, dateFormat) ||
        dateValidator.isValid(date, dateFormatAlt)
        )) true
    else false
  }

  def getDecade(transactionDate: Long, dob: Option[String]): Option[Int] = {
    dob match {
      case Some(date) =>
      if (validateDate(date)) {
        getDateTime(date) match {
          case Some(dateOfBirth) =>
          val yearsDiff = new DateTime(transactionDate, DateTimeZone.UTC).getYear - dateOfBirth.getYear
          val decade = yearsDiff / 10
          if (yearsDiff < 0 || decade >= Max_Dob_Age)
            None
          else
            Some(decade)
          case _                 => None
        }
      }
      else None
      case _          => None
    }
  }

  def date(dt: Option[String]): Boolean =
    dt match {
      case Some(date) =>
      val v = validateDate(date)
      if (v) {
        val dateTime = getDateTime(date)
        if (!dateTime.isEmpty || dateTime.map(_.isBefore(DateTime.now(DateTimeZone.UTC))).contains(true)) true else false
      } else false
      case _ => false
    }

  def getCountryCode(phone: Option[String], trxId:Option[String] = None): Option[Int] = {
    val phoneUtil = PhoneNumberUtil.getInstance
    try {
      phone match {
        case Some(p) if (p.nonEmpty && phone.getOrElse("").matches("[0-9\\+]+")) =>
        val mobNum = p.filterNot(c => c == '-' || c == '(' || c == ')').replaceAll("\\s", "")
        val number = if (!mobNum.startsWith("+")) "+" + mobNum
                     else mobNum
        val numberProto = phoneUtil.parse(number, null)
        val regionCode = phoneUtil.getRegionCodeForNumber(numberProto)
        val countryCode = phoneUtil.getCountryCodeForRegion(regionCode)
        if (countryCode != 0 && countryCode != null) {
          Option(countryCode)
        }
        else {
          logger.warn(s"${trxId} Invalid/Missing country code for mobile number")
          None
        }
        case _                                                                   => None
      }
    }
    catch {
      case ex: Exception =>
      logger.warn(s"${trxId} Got error parsing mobile number ${ex.getMessage}")
      None
    }
  }

  val errorCodesMapping: Map[String, Int] = {
    val source = Source.fromURL(getClass.getResource("/error_codes.csv"))
    val res = source
              .getLines()
              .flatMap {
                line =>
                Option(line)
                .map(_.trim)
                .filterNot(_.isEmpty)
                .map(_.split(",", 2).map(_.trim).filterNot(_.isEmpty))
                .filter(_.length == 2)
                .map {
                  case Array(errorCode, errorMsg) =>
                  errorMsg -> errorCode.toInt
                }
              }
              .toMap
    source.close()
    res
  }
}
