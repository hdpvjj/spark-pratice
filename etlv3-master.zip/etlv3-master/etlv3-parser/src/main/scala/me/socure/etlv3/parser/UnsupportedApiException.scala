package me.socure.etlv3.parser

import scala.util.control.NoStackTrace

case class UnsupportedApiException(apiName: String) extends Exception(s"$apiName is not supported") with NoStackTrace
