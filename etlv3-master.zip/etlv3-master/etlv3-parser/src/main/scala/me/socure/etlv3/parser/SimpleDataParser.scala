package me.socure.etlv3.parser

import me.socure.etlv3.common.{ParserResponse, TransactionInput}

trait SimpleDataParser[In <: TransactionInput, Out <: ParserResponse] {
  def parse(input: In): Out
}
