-- address another issue about "String is too long and would be truncated"
ALTER TABLE rule_code_fraud ALTER COLUMN fcevl_100028 SET DATA TYPE STRING;