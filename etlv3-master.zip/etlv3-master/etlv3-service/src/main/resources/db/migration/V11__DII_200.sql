DROP TABLE IF EXISTS transaction_pii;

CREATE TABLE IF NOT EXISTS transaction_pii
(
  transaction_id VARCHAR(36),
  transaction_date TIMESTAMP_NTZ,
  account_id INTEGER,
  run_id VARCHAR(255),
  account_ip_address VARIANT,
  origin_of_invocation VARIANT,
  email VARIANT,
  first_name VARIANT,
  surname VARIANT,
  full_name VARIANT,
  company_name VARIANT,
  user_id VARIANT,
  physical_address VARIANT,
  physical_address2 VARIANT,
  city VARIANT,
  state VARIANT,
  zip VARIANT,
  country VARIANT,
  ip_address VARIANT,
  national_id VARIANT,
  dob VARIANT,
  mobile_number VARIANT,
  driver_license VARIANT,
  driver_license_state VARIANT,
  geocode VARIANT,
  payments VARIANT,
  addresses VARIANT,
  devices VARIANT,
  PRIMARY KEY (transaction_id)
)
STAGE_COPY_OPTIONS = (MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE);


CREATE TABLE IF NOT EXISTS transaction_raw
(
  transaction_id VARCHAR(36),
  transaction_date TIMESTAMP_NTZ,
  account_id INTEGER,
  run_id VARCHAR(255),
  transaction_response VARIANT,
  PRIMARY KEY (transaction_id)
  )
STAGE_COPY_OPTIONS = (MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE);

CREATE TABLE IF NOT EXISTS rule_code
(
  transaction_id VARCHAR(36),
  transaction_date TIMESTAMP_NTZ,
  account_id INTEGER,
  run_id VARCHAR(255),
  rule_codes VARIANT,
  PRIMARY KEY (transaction_id)
  )
STAGE_COPY_OPTIONS = (MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE);


ALTER TABLE transaction ADD COLUMN previous_reference_id STRING;
ALTER TABLE transaction ADD COLUMN overall_decision STRING;