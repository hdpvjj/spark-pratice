-- address the issue "String is too long and would be truncated"
ALTER TABLE rule_code_fraud ALTER COLUMN dfpvl_100037 SET DATA TYPE STRING;

-- address the issue "Failed to cast variant value "" to FIXED"
ALTER TABLE rule_code_fraud RENAME COLUMN ifavl_100011 TO ifavl_100011_bak;
ALTER TABLE rule_code_fraud ADD COLUMN ifavl_100011 STRING DEFAULT NULL;
UPDATE rule_code_fraud rc1 SET ifavl_100011 = rc2.ifavl_100011_bak FROM rule_code_fraud rc2 WHERE rc1.transaction_id = rc2.transaction_id AND rc2.ifavl_100011_bak IS NOT NULL;
ALTER TABLE rule_code_fraud DROP COLUMN ifavl_100011_bak;