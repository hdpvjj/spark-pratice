ALTER TABLE reason_code add COLUMN
i860 BOOLEAN DEFAULT NULL;

ALTER TABLE rule_code_fraud ADD COLUMN
     falvl_100001 Float DEFAULT NULL,
     falvl_100002 Float DEFAULT NULL,
     falvl_100003 Float DEFAULT NULL,
     falvl_100004 Integer DEFAULT NULL,
     falvl_100130 Float DEFAULT NULL,
     falvl_100131 Float DEFAULT NULL;

-- This needs to be included every time rule_code%partitioned% tables are altered.
create or replace table tbl_rule_code_mapping as
(select 'RULE_CODE_FRAUD' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_FRAUD' order by ordinal_position) union
(select 'RULE_CODE_COMPLIANCE' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_COMPLIANCE' order by ordinal_position) union
(select 'RULE_CODE_DOCV' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_DOCV' order by ordinal_position) union
(select 'RULE_CODE_GLOBALS' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_GLOBALS' order by ordinal_position) union
(select 'RULE_CODE_FRAUD_LEGACY' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_FRAUD_LEGACY' order by ordinal_position);
