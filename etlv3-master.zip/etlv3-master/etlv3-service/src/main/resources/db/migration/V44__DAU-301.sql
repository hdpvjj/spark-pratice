ALTER TABLE transaction_pii ADD COLUMN shipping_details VARIANT;
ALTER TABLE transaction_pii ADD COLUMN merchant_details VARIANT;