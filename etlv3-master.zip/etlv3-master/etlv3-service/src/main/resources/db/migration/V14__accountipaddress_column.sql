ALTER TABLE transaction DROP COLUMN accountipaddress_provided;
ALTER TABLE transaction ADD COLUMN account_ip_address STRING;
ALTER TABLE transaction_pii DROP COLUMN account_ip_address;