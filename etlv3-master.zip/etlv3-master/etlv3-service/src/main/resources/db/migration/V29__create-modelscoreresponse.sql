CREATE TABLE IF NOT EXISTS model_score_response
(
  transaction_id VARCHAR(36),
  account_id INTEGER,
  transaction_date TIMESTAMP_NTZ,
  run_id VARCHAR(255),
  environment_id	NUMBER(20),
  module_type	VARCHAR,
  model_name	VARCHAR,
  model_version	VARCHAR,
  field_validations	VARCHAR,
  score	FLOAT8
  )
  STAGE_COPY_OPTIONS = (MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE);
