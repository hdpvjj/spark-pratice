ALTER TABLE transaction add COLUMN module_accountintelligence BOOLEAN DEFAULT FALSE;
ALTER TABLE transaction_pii add COLUMN business_name VARIANT;
ALTER TABLE transaction_pii add COLUMN ein VARIANT;