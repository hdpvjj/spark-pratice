-- address another 2 issues about "String is too long and would be truncated"
ALTER TABLE rule_code_fraud ALTER COLUMN exevl_100018 SET DATA TYPE STRING;
ALTER TABLE rule_code_fraud ALTER COLUMN dfpvl_500008 SET DATA TYPE STRING;