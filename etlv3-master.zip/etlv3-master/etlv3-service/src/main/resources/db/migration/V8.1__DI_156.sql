-- address another 2 issues about "String is too long and would be truncated"
ALTER TABLE transaction ALTER COLUMN error_msg SET DATA TYPE STRING;
ALTER TABLE transaction ALTER COLUMN error_reason SET DATA TYPE STRING;