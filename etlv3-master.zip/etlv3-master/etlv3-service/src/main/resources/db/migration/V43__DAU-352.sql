ALTER TABLE transaction ADD COLUMN entity_name_provided boolean DEFAULT false;
ALTER TABLE transaction ADD COLUMN entity_type_provided boolean DEFAULT false;
ALTER TABLE transaction ADD COLUMN entity_type VARCHAR(255) DEFAULT NULL;
ALTER TABLE transaction_pii ADD COLUMN entity_name VARCHAR(255);