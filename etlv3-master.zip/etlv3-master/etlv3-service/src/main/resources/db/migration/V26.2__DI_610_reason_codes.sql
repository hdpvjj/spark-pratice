ALTER TABLE reason_code ADD COLUMN
  reason_codes VARIANT DEFAULT NULL
;

