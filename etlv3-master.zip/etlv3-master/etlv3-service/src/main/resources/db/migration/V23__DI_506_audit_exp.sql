ALTER TABLE transaction add COLUMN social VARIANT;

CREATE TABLE IF NOT EXISTS kyc_code
(
  transaction_id STRING,
  transaction_date TIMESTAMP_NTZ,
  account_id INTEGER,
  run_id STRING,
  zip  FLOAT8,
  first_name  FLOAT8,
  last_name  FLOAT8,
  mobile_number  FLOAT8,
  city  FLOAT8,
  dob  FLOAT8,
  surname  FLOAT8,
  street_address  FLOAT8,
  state  FLOAT8,
  ssn  FLOAT8,
  email  FLOAT8,
  PRIMARY KEY (transaction_id)
)
STAGE_COPY_OPTIONS = (MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE);


CREATE TABLE IF NOT EXISTS decision
(
  transaction_id VARCHAR,
  account_id NUMBER(20),
  transaction_date TIMESTAMP_NTZ,
  run_id VARCHAR,
  model_name VARCHAR,
  model_version VARCHAR,
  value VARCHAR,
  details VARCHAR,
  PRIMARY KEY (transaction_id, model_name, model_version)
)
STAGE_COPY_OPTIONS = (MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE);

CREATE TABLE IF NOT EXISTS document_verification
(
  transaction_id VARCHAR,
  account_id NUMBER(20),
  transaction_date TIMESTAMP_NTZ,
  run_id VARCHAR,
  reference_id VARCHAR,
  customer_profile VARIANT,
  document_verification VARIANT,
  PRIMARY KEY (transaction_id)
)
STAGE_COPY_OPTIONS = (MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE);

 CREATE TABLE IF NOT EXISTS prefill
 (
   transaction_id VARCHAR,
   account_id NUMBER(20),
   transaction_date TIMESTAMP_NTZ,
   run_id VARCHAR,
   first_name VARIANT,
   middle_name VARIANT,
   sur_name VARIANT,
   suffix VARIANT,
   ssn_first_5 VARIANT,
   dob VARIANT,
   associated_addresses VARIANT,
   PRIMARY KEY (transaction_id)
 )
 STAGE_COPY_OPTIONS = (MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE);