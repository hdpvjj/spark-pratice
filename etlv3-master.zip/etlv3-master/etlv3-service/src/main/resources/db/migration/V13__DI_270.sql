ALTER TABLE rule_code_fraud ADD COLUMN
     ssevl_100037	Integer DEFAULT NULL,
     ssevl_100048	Float DEFAULT NULL,
     exevl_100038	Integer DEFAULT NULL,
     exxvl_100301	Float DEFAULT NULL,
     exxvl_100302	Float DEFAULT NULL,
     exsvl_200051	Integer DEFAULT NULL,
     exsvl_200052	Integer DEFAULT NULL,
     nsrvl_200034	Integer DEFAULT NULL,
     nsrvl_200035	Integer DEFAULT NULL;

-- DI-294 to create table with table to rule_codes mapping. This needs to be included every time rule_code%partitioned% tables are altered.
create or replace table tbl_rule_code_mapping as
(select 'RULE_CODE_FRAUD' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_FRAUD' order by ordinal_position) union
(select 'RULE_CODE_COMPLIANCE' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_COMPLIANCE' order by ordinal_position) union
(select 'RULE_CODE_DOCV' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_DOCV' order by ordinal_position) union
(select 'RULE_CODE_GLOBALS' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_GLOBALS' order by ordinal_position) union
(select 'RULE_CODE_FRAUD_LEGACY' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_FRAUD_LEGACY' order by ordinal_position);
