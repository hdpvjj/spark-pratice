ALTER TABLE kyc_code add COLUMN tetl_proc_time TIMESTAMP_NTZ;
ALTER TABLE decision add COLUMN tetl_proc_time TIMESTAMP_NTZ;
ALTER TABLE document_verification add COLUMN tetl_proc_time TIMESTAMP_NTZ;
ALTER TABLE prefill add COLUMN tetl_proc_time TIMESTAMP_NTZ;
