ALTER TABLE rule_code_docv ADD COLUMN
  CVVAL_100001 Float DEFAULT NULL,
  CVVAL_100002 Float DEFAULT NULL,
  CVVAL_100003 Float DEFAULT NULL,
  CVVAL_100004 Integer DEFAULT NULL,
  CVVAL_100005 Float DEFAULT NULL,
  CVVAL_100006 Float DEFAULT NULL,
  CVVAL_100130 Float DEFAULT NULL,
  CVVAL_100131 Float DEFAULT NULL
;

create or replace table tbl_rule_code_mapping as
(select 'RULE_CODE_FRAUD' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_FRAUD' order by ordinal_position) union
(select 'RULE_CODE_COMPLIANCE' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_COMPLIANCE' order by ordinal_position) union
(select 'RULE_CODE_DOCV' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_DOCV' order by ordinal_position) union
(select 'RULE_CODE_GLOBALS' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_GLOBALS' order by ordinal_position) union
(select 'RULE_CODE_FRAUD_LEGACY' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_FRAUD_LEGACY' order by ordinal_position);
