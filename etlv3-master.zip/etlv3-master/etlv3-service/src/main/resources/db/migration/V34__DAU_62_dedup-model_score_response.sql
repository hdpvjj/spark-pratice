ALTER TABLE model_score_response add COLUMN tetl_proc_time TIMESTAMP_NTZ;
