ALTER TABLE transaction ADD COLUMN business_name_provided BOOLEAN;
ALTER TABLE model_score_response ADD COLUMN ownership_score FLOAT8;
ALTER TABLE model_score_response ADD COLUMN availability_score FLOAT8;