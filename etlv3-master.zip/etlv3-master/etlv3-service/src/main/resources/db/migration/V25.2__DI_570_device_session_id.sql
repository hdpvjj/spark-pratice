ALTER TABLE transaction alter COLUMN
    device_session_id SET DATA TYPE STRING;