ALTER TABLE rule_code_docv ADD COLUMN
  AID6VAL_100001 String DEFAULT NULL,
  AID6VAL_100002 String DEFAULT NULL,
  AID6VAL_100003 String DEFAULT NULL,
  AID6VAL_100004 String DEFAULT NULL,
  AID6VAL_100005 String DEFAULT NULL,
  AID6VAL_100006 Integer DEFAULT NULL,
  AID6VAL_100007 Integer DEFAULT NULL,
  AID6VAL_100008 Integer DEFAULT NULL,
  AID6VAL_100009 Integer DEFAULT NULL,
  AID6VAL_100011 Integer DEFAULT NULL,
  AID6VAL_100012 TIMESTAMP_NTZ DEFAULT NULL,
  AID6VAL_100013 TIMESTAMP_NTZ DEFAULT NULL,
  AID6VAL_100014 Integer DEFAULT NULL,
  AID6VAL_100015 Integer DEFAULT NULL,
  AID6VAL_100016 Integer DEFAULT NULL,
  AID6VAL_100017 Integer DEFAULT NULL,
  AID6VAL_100018 Integer DEFAULT NULL,
  AID6VAL_100019 Integer DEFAULT NULL,
  AID6VAL_100020 Integer DEFAULT NULL,
  AID6VAL_100021 Integer DEFAULT NULL,
  AID6VAL_100022 Integer DEFAULT NULL,
  AID6VAL_100023 Integer DEFAULT NULL,
  AID6VAL_100024 Integer DEFAULT NULL,
  AID6VAL_100025 Integer DEFAULT NULL,
  AID6VAL_100026 Integer DEFAULT NULL,
  AID6VAL_100027 Integer DEFAULT NULL,
  AID6VAL_100028 Integer DEFAULT NULL,
  AID6VAL_100029 Integer DEFAULT NULL,
  AID6VAL_100030 Integer DEFAULT NULL,
  AID6VAL_100031 Integer DEFAULT NULL,
  AID6VAL_100032 Integer DEFAULT NULL,
  AID6VAL_100033 Integer DEFAULT NULL,
  AID6VAL_100034 Integer DEFAULT NULL,
  AID6VAL_100035 Integer DEFAULT NULL,
  AID6VAL_100036 Integer DEFAULT NULL,
  AID6VAL_100037 Float DEFAULT NULL,
  AID6VAL_100038 String DEFAULT NULL,
  AID6VAL_100039 Integer DEFAULT NULL,
  AID6VAL_100040 Integer DEFAULT NULL
;

create or replace table tbl_rule_code_mapping as
(select 'RULE_CODE_FRAUD' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_FRAUD' order by ordinal_position) union
(select 'RULE_CODE_COMPLIANCE' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_COMPLIANCE' order by ordinal_position) union
(select 'RULE_CODE_DOCV' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_DOCV' order by ordinal_position) union
(select 'RULE_CODE_GLOBALS' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_GLOBALS' order by ordinal_position) union
(select 'RULE_CODE_FRAUD_LEGACY' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_FRAUD_LEGACY' order by ordinal_position);
