ALTER TABLE rule_code_compliance ADD COLUMN
  ASAVL_100000 Integer DEFAULT NULL,
  ASAVL_100001 Integer DEFAULT NULL,
  ASAVL_100002 Float DEFAULT NULL,
  ASAVL_100004 Integer DEFAULT NULL,
  ASAVL_100005 Float DEFAULT NULL,
  ASAVL_100006 Integer DEFAULT NULL,
  ASAVL_100007 Float DEFAULT NULL,
  ASAVL_100008 Integer DEFAULT NULL,
  ASAVL_100009 Integer DEFAULT NULL,
  ASAVL_100010 Integer DEFAULT NULL,
  ASAVL_100011 Integer DEFAULT NULL,
  ASAVL_100012 Integer DEFAULT NULL,
  ASAVL_100019 Integer DEFAULT NULL,
  ASAVL_100020 Integer DEFAULT NULL,
  ASAVL_100021 Integer DEFAULT NULL,
  ASAVL_100024 Integer DEFAULT NULL,
  ASAVL_100130 Integer DEFAULT NULL,
  ASAVL_100131 Integer DEFAULT NULL,
  ASAVL_100135 Integer DEFAULT NULL,
  ATTMVL_100000 Integer DEFAULT NULL,
  ATTMVL_100001 Integer DEFAULT NULL,
  ATTMVL_100002 float DEFAULT NULL,
  ATTMVL_100003 Integer DEFAULT NULL,
  ATTMVL_100004 float DEFAULT NULL,
  ATTMVL_100005 Integer DEFAULT NULL,
  ATTMVL_100006 float DEFAULT NULL,
  ATTMVL_100007 Integer DEFAULT NULL,
  ATTMVL_100009 float DEFAULT NULL,
  ATTMVL_100010 float DEFAULT NULL,
  ATTMVL_100011 float DEFAULT NULL,
  ATTMVL_100012 float DEFAULT NULL,
  ATTMVL_100013 float DEFAULT NULL,
  ATTMVL_100014 float DEFAULT NULL,
  ATTMVL_100015 Integer DEFAULT NULL,
  ATTMVL_100016 Integer DEFAULT NULL,
  ATTMVL_100130 Integer DEFAULT NULL,
  ATTMVL_100131 Integer DEFAULT NULL
;
-- This needs to be included every time rule_code%partitioned% tables are altered.
create or replace table tbl_rule_code_mapping as
(select 'RULE_CODE_FRAUD' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_FRAUD' order by ordinal_position) union
(select 'RULE_CODE_COMPLIANCE' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_COMPLIANCE' order by ordinal_position) union
(select 'RULE_CODE_DOCV' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_DOCV' order by ordinal_position) union
(select 'RULE_CODE_GLOBALS' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_GLOBALS' order by ordinal_position) union
(select 'RULE_CODE_FRAUD_LEGACY' as table_name, column_name from information_schema.columns where table_schema = 'PUBLIC' and table_name = 'RULE_CODE_FRAUD_LEGACY' order by ordinal_position);
