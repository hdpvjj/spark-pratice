# Configs

This repository uses the Socure Common library to read the configs on which the app runs. This library determines a
specific pattern for how configs should be stored in S3 where they are retrieved on app start up.

- If the APP_ENVIRONMENT = test and CONFIGURATION_NAME = test, then the configs `test.conf` and `test.groovy` are
  retrieved from the `src/main/resources` directory.
- If the APP_ENVIRONMENT and CONFIGURATION_NAME are set to anything else, then the config is retrieved from S3 according
  to a set of environment variables.
    - CONFIGURATION_NAME, CONFIGURATION,BUCKET, CONFIGURATION_VERSION, APP_REGION, APP_ENVIRONMENT must all be set.
    - `s3:
      //${CONFIGURATION_BUCKET}/{CONFIGURATION_NAME}/{CONFIGURATION_VERSION}/configurations/{APP_REGION}/{APP_ENVIORNMENT}.conf`
        - e.g. `s3://dapl-microservice-configurations/transaction-etl/0.1-SNAPSHOT/configurations/us-east-1/prod.conf`
    - `s3://${CONFIGURATION_BUCKET}/{CONFIGURATION_NAME}/{CONFIGURATION_VERSION}/logs/{APP_ENVIORNMENT}.groovy`
        - e.g. `s3://dapl-microservice-configurations/transaction-etl/0.1-SNAPSHOT/logs/prod.groovy`