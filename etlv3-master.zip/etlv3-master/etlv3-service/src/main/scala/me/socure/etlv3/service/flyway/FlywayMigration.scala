package me.socure.etlv3.service.flyway

import java.io.{ByteArrayInputStream, InputStreamReader}
import java.security.Security
import java.util.Base64

import com.typesafe.config.Config
import me.socure.etlv3.service.Main.getClass
import net.snowflake.client.jdbc.SnowflakeBasicDataSource
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo
import org.bouncycastle.jcajce.provider.BouncyCastleFipsProvider

import org.bouncycastle.openssl.PEMParser
import org.bouncycastle.openssl.jcajce.{JcaPEMKeyConverter, JceOpenSSLPKCS8DecryptorProviderBuilder}
import org.bouncycastle.pkcs.PKCS8EncryptedPrivateKeyInfo
import org.flywaydb.core.Flyway
import org.flywaydb.core.api.MigrationVersion
import org.flywaydb.core.api.configuration.ClassicConfiguration
import org.json4s.DefaultFormats
import org.json4s.native.JsonMethods
import org.slf4j.{Logger, LoggerFactory}
import software.amazon.awssdk.regions.Region
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient
import software.amazon.awssdk.services.secretsmanager.model.{GetSecretValueRequest, GetSecretValueResponse}

object FlywayMigration {
  val logger: Logger = LoggerFactory.getLogger(getClass)
  private implicit val FORMATS: DefaultFormats = DefaultFormats

  def getPrivateKey(privateKey: String, passphrase: String) = {
    Security.addProvider(new BouncyCastleFipsProvider())
    val pemParser = new PEMParser(new InputStreamReader(new ByteArrayInputStream(Base64.getDecoder.decode(privateKey))))
    val pemObject = pemParser.readObject()
    val privateKeyInfo =
      if (pemObject.isInstanceOf[PKCS8EncryptedPrivateKeyInfo]) {
        val encryptedPrivateKeyInfo = pemObject.asInstanceOf[PKCS8EncryptedPrivateKeyInfo]
        val pkcs8Prov = new JceOpenSSLPKCS8DecryptorProviderBuilder().build(passphrase.toCharArray())
        Some(encryptedPrivateKeyInfo.decryptPrivateKeyInfo(pkcs8Prov))
      }
      else if (pemObject.isInstanceOf[PrivateKeyInfo]) {
        Some(pemObject.asInstanceOf[PrivateKeyInfo])
      }
      else {
        None
      }
    pemParser.close()
    val converter = new JcaPEMKeyConverter().setProvider(BouncyCastleFipsProvider.PROVIDER_NAME)
    converter.getPrivateKey(privateKeyInfo.getOrElse(throw new Exception("could not obtain private key")))
  }

  def getSecret(secretsClient: SecretsManagerClient, secretValueReq: GetSecretValueRequest) = {
    val getSecretValueResponse: GetSecretValueResponse = secretsClient.getSecretValue(secretValueReq)
    getSecretValueResponse.secretString()
  }

  def parseSecretString(secretString: String)= {
    JsonMethods.parse(secretString).extract[CustomKeyInfo]
  }

  def migrate(conf: Config) = {
    if (conf.getBoolean("withMigration")) {
      logger.info("applying flyway migration")
      val secretsClient = SecretsManagerClient.builder()
                          .region(Region.of(conf.getString("region")))
                          .build()
      val secret = parseSecretString(getSecret(secretsClient, GetSecretValueRequest.builder()
                                       .secretId(conf.getString("secretName"))
                                       .build()
                            ))
      secretsClient.close()
      val dataSource = new SnowflakeBasicDataSource()
      dataSource.setUrl(conf.getString("snowFlakeUrl"))
      dataSource.setWarehouse(conf.getString("warehouse"))
      dataSource.setUser(conf.getString("snowFlakeUser"))
      dataSource.setDatabaseName(conf.getString("snowFlakeDbName"))
      dataSource.setRole(conf.getString("snowFlakeRole"))
      dataSource.setSchema(conf.getString("snowFlakeSchema"))
      dataSource.setPrivateKey(getPrivateKey(secret.private_key, secret.passphrase))
      val classicConfig = new ClassicConfiguration()
      classicConfig.setDataSource(dataSource)
      classicConfig.setBaselineOnMigrate(true)
      classicConfig.setBaselineVersion(MigrationVersion.NEXT)
      val flyway = new Flyway(classicConfig)

      try {
        flyway.migrate()
      } catch {
        case e: org.flywaydb.core.api.exception.FlywayValidateException =>
        // repair and retry once
          flyway.repair()
          flyway.migrate()
      }
    } else {
      logger.info("flyway migration is disabled")
    }
  }

}
