package me.socure.etlv3.service.module

import com.google.inject.{AbstractModule, Provides}
import com.typesafe.config.Config
import javax.inject.Singleton
import me.socure.common.clock.RealClock
import me.socure.etlv3.service.{PipelineFactory, PipelineService, StoppableService}
import net.codingwell.scalaguice.ScalaModule
import scala.concurrent.ExecutionContext

class Etlv3ServiceModule extends AbstractModule with ScalaModule {

  override
  def configure(): Unit = {
    bind(classOf[RealClock]).toInstance(new RealClock)
  }

  @Provides
  @Singleton
  def pipeline(config: Config, ec: ExecutionContext, clock: RealClock): StoppableService = {
    PipelineFactory(config, clock)(ec).create()
  }

  @Provides
  @Singleton
  def pipelineService(pipeline: StoppableService, ec: ExecutionContext): PipelineService = {
    new PipelineService(pipeline)(ec)
  }
}
