package me.socure.etlv3.service

import me.socure.common.sqs.v2.Pipeline
import scala.concurrent.Future

class StoppablePipelineService(pipeline: Pipeline[_]) extends StoppableService {
  override def start(): Future[Unit] = pipeline.start()

  override def stop(): Unit = pipeline.stop()
}
