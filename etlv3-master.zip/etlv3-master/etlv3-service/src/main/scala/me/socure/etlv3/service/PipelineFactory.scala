package me.socure.etlv3.service

import akka.util.Timeout
import com.github.blemale.scaffeine.Scaffeine
import com.typesafe.config.Config
import me.socure.common.clock.RealClock
import me.socure.common.metrics.JavaMetricsFactory
import me.socure.common.sqs.sns.v2.extended.common.{Configuration, Constants, S3Wrapper}
import me.socure.common.sqs.v2.extended.ExtendedSqsAsyncClient
import me.socure.common.sqs.v2.{MessageId, Pipeline, SqsMessagesDeleter}
import me.socure.common.storage.{CachedValueSync, FileStorageSync}
import me.socure.common.uuid.RandomUuidProvider
import me.socure.dapl.snowflake.crypto.HexadecimalFactory
import me.socure.datakey.client.factory.DataKeyClientFactory
import me.socure.etlv3.common.WrappedMsg
import me.socure.etlv3.kinesis.KinesisProcessorService
import me.socure.etlv3.parser.TransactionInputParser
import me.socure.etlv3.processor.{CachedMsg, TransactionProcessor}
import me.socure.types.scala.batch.BatchConf
import org.slf4j.LoggerFactory
import software.amazon.awssdk.auth.credentials.{AwsCredentialsProviderChain, WebIdentityTokenFileCredentialsProvider}
import software.amazon.awssdk.regions.Region
import software.amazon.awssdk.services.s3.S3AsyncClient
import software.amazon.awssdk.services.sqs.SqsAsyncClient
import software.amazon.awssdk.services.sqs.model.{GetQueueUrlRequest, Message, MessageSystemAttributeName, ReceiveMessageRequest}

import java.nio.file.Paths
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import scala.collection.JavaConversions._
import scala.concurrent.ExecutionContext
import scala.concurrent.duration.{Duration, MINUTES, _}
import scala.util.{Failure, Success, Try}

class PipelineFactory(config: Config, clock: RealClock)(implicit ec: ExecutionContext) {
  private val logger = LoggerFactory.getLogger(getClass)
  private val metrics = JavaMetricsFactory.get(getClass)

  def getDataKeyServiceClient() = {
    val endpoint = config.getString("data.key.service.endpoint")
    val sqsRegion = config.getString("pipeline.region")
    val credentialsProvider = AwsCredentialsProviderChain.builder().addCredentialsProvider(WebIdentityTokenFileCredentialsProvider.create())
    new DataKeyClientFactory(sqsRegion, endpoint, credentialsProvider.build()).create()
  }

  val getDataDogEnvTag = config.getString("dataDogEnvTag")

  val cacheDataKeys =
    Scaffeine()
    .refreshAfterWrite(1 hour)
    .buildAsyncFuture[Int, Map[String, Array[Byte]]]((_: Int) => getDataKeyServiceClient().fetch().map {
      res =>
      res match {
        case Right(dataKeys) =>
        val resDataKeys = dataKeys.result.value.map{case (k, v) => k.toString ->  HexadecimalFactory.convertHexStrToBytes(v)}
        logger.info(s"Refreshing ${resDataKeys.size} data keys")
        logger.info(s"Last 10 account ids are:  ${resDataKeys.keys.map(_.toInt).toList.sorted.reverse.take(10)}")
        resDataKeys
        case Left(ex)        =>
        logger.error(s"Error calling DataKeyServiceClient ${ex}")
        metrics.increment(s"etlv3.gdm.service.error", s"${getDataDogEnvTag}")
        throw new Exception(s"Error calling DataKeyServiceClient ${ex.result}")
      }
    })

  def create(): StoppableService = {
    logger.info(s"The config is ${config.toString}")
    val sqsRegion = config.getString("pipeline.region")
    val failAccountIdZero = try {
      config.getBoolean("failAccountIdZero")
    } catch {
      case _: Throwable =>
      logger.info("failAccountIdZero not found, and will be set to false by default. We will ignore transactions with account_id 0.")
      false
    }
    val baseClient = SqsAsyncClient.builder().credentialsProvider(WebIdentityTokenFileCredentialsProvider.create()).region(Region.of(sqsRegion)).build()
    val largeFilesConf = config.getConfig("pipeline.sqs.large.files")
    val extendedSqsConf = Configuration(
                                         s3BucketName = largeFilesConf.getString("s3.bucket.name"),
                                         basePath = if (largeFilesConf.hasPath("s3.base.path")) Option(largeFilesConf
                                                                                                       .getString
                                                                                                       ("s3.base" +
                                                                                                        ".path"))
                                                                                                .map(Paths.get(_))
                                                    else None,
                                         messageSizeThreshold = if (largeFilesConf.hasPath("message.size.threshold"))
                                                                  config.getInt("message.size.threshold")
                                                                else Constants.DefaultMessageSizeThreshold
                                       )
    val asyncS3Client = S3AsyncClient.create()
    val s3Client = S3Wrapper(asyncS3Client)
    val client = new ExtendedSqsAsyncClient(baseClient, s3Client, extendedSqsConf, ignoreS3NoSuchKey = true,
                                            uuidProvider = RandomUuidProvider)
    val queueName = config.getString("pipeline.sqs.queue.name")
    logger.info(s"The queueName is ${queueName}")
    val getQueueUrlRequest = GetQueueUrlRequest.builder().queueName(queueName).build()
    val queueUrl = Try {
      client.getQueueUrl(getQueueUrlRequest).get(10, TimeUnit.SECONDS).queueUrl()
    } match {
      case Success(url) => url
      case Failure(ex: Exception) =>
      logger.error("sqs queue url is not obtained using queue name ", ex.getMessage)

      val url = config.getString("pipeline.sqs.queue.url")
      logger.info(s"The queue url is ${url}")
      url
    }
    logger.info(s"Processing using queue url ${queueUrl}")
    val receiveMessageCount = getInt(config, "pipeline.sqs.receive.message.count").getOrElse(10)
    if (receiveMessageCount > 10) {
      throw new IllegalStateException("No more than 10 messages can be requested at a time")
    }
    val deleteMaxRetries = getInt(config, "sqs.delete.messages.max.retries").getOrElse(3)
    val sqsMessagesDeleter = new SqsMessagesDeleter(
                                                     client = client,
                                                     queueUrl = queueUrl,
                                                     maxRetries = deleteMaxRetries,
                                                     metrics = JavaMetricsFactory.get("etl.sqs.delete.messages"),
                                                     logger = LoggerFactory.getLogger("etl.sqs.delete.messages")
                                                   )
    val receiveMessageRequest = ReceiveMessageRequest
                                .builder()
                                .queueUrl(queueUrl)
                                .maxNumberOfMessages(receiveMessageCount)
                                .visibilityTimeout(config.getInt("pipeline.sqs.visibility.timeout.seconds"))
                                .attributeNamesWithStrings(MessageSystemAttributeName.APPROXIMATE_RECEIVE_COUNT
                                                           .toString)
                                .build()
    val cacheBaseDir = if (config.hasPath("pipeline.cache.base.path")) Paths.get(config.getString("pipeline.cache" +
                                                                                                  ".base.path"))
                       else Paths.get("/tmp/etl-v3/caching")
    val messageCacheDir = cacheBaseDir.resolve("original_msgs")
    messageCacheDir.toFile.mkdirs()
    val msgIdExtractor = (m: MessageId) => m.id
    val storageMsgs = FileStorageSync.serializable[WrappedMsg](messageCacheDir).toGeneric(msgIdExtractor)
    val duration = config.getInt("ask.timeout")
    implicit val askTimeout: Timeout = Timeout(FiniteDuration(duration, MINUTES))
    val nonConsentingAccounts = config.getLongList("pipeline.non.consenting.accounts")
    val userIdConsentingAccounts = config.getLongList("pipeline.userid.consenting.accounts")
    val transactionProcessor: TransactionProcessor = new TransactionProcessor(
                                                                               extractor = TransactionInputParser,
                                                                               kinesisService = new KinesisProcessorService(config = config),
                                                                               cacheDataKeys = cacheDataKeys,
                                                                               datadogEnvTag = getDataDogEnvTag,
                                                                               nonConsentingAccounts = nonConsentingAccounts.map(_.toLong).toList,
                                                                               failAccountIdZero = failAccountIdZero,
                                                                               piiFeatureFlag = config.getBoolean("piiFeatureFlag"),
                                                                               userIdConsentingAccounts = userIdConsentingAccounts.map(_.toLong).toList
                                                                             )
    val bufferConf = if (config.hasPath("pipeline.buffering")) {
      Some(BatchConf(
                      targetCount = config.getInt("pipeline.buffering.targetCount"),
                      maxDuration = Duration(config.getString("pipeline.buffering.maxDuration"))
                    )
          )
    }
                     else None

    val pipelineFailureSleepTimeInMillis = if (config.hasPath("pipeline.failure.sleep.time")) {
      Duration(config.getString("pipeline.failure.sleep.time")).toMillis
    } else Duration("1 minute").toMillis

    val pipeline = Pipeline[CachedMsg](
                                        client = client,
                                        req = receiveMessageRequest,
                                        messagesProcessor = transactionProcessor,
                                        batchConf = bufferConf,
                                        sqsMessagesDeleter = sqsMessagesDeleter,
                                        autoDeleteMessages = true,
                                        proceed = {
                                          ex: Throwable =>
                                          logger.error(s"Pipeline failed unexpectedly. Sleeping for $pipelineFailureSleepTimeInMillis ms before proceeding. ${ex}")
                                          // in case of pipeline failures sleep for sometime before proceeding
                                          Thread.sleep(pipelineFailureSleepTimeInMillis)
                                          true
                                        },
                                        ignoreEmpty = true,
                                        metrics = JavaMetricsFactory.get("etl.pipeline"),
                                        logger = LoggerFactory.getLogger("etl.pipeline"),
                                        messageExtractor = (msg: Message) => {
                                          val messageReceiveCount = if (msg.hasAttributes) {
                                            val receiveCountStr = msg.attributes().get(MessageSystemAttributeName.APPROXIMATE_RECEIVE_COUNT)
                                            if (receiveCountStr != null && receiveCountStr.nonEmpty) {
                                              Some(receiveCountStr.toInt)
                                            }
                                            else Option.empty[Int]
                                          }
                                                                    else Option.empty[Int]
                                          val messageId = MessageId(id = msg.messageId(), recipientHandle = msg.receiptHandle())
                                          val wrappedMsg = WrappedMsg(id = messageId, body = msg.body(), messageReceiveCount)
                                          CachedValueSync(storageMsgs, messageId, wrappedMsg)
                                        },
                                        messageIdExtractor = (cachedMsg: CachedMsg) => cachedMsg.key
                                      )
    val parallelism = config.getInt("pipeline.parallelism")
    if (parallelism == 1) new StoppablePipelineService(pipeline)
    else {
      new CompositeStoppableServices(
                                      (1 to parallelism).toSet[Int].map {
                                        _ =>
                                        new StoppablePipelineService(
                                                                      pipeline.copy(
                                                                                     isRunningState = new AtomicBoolean()
                                                                                   )
                                                                    )
                                      }
                                    )
    }
  }

  private
  def getInt(conf: Config, path: String): Option[Int] = {
    if (conf.hasPath(path)) Option(conf.getInt(path))
    else None
  }
}

object PipelineFactory {
  def apply(config: Config, clock: RealClock)(implicit ec: ExecutionContext) = {
    new PipelineFactory(config, clock)
  }
}