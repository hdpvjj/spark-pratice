package me.socure.etlv3.service

import com.google.common.util.concurrent.AbstractService
import org.slf4j.LoggerFactory
import scala.concurrent.ExecutionContext
import scala.util.{Failure, Success}

class PipelineService(pipeline: StoppableService)(implicit ec: ExecutionContext) extends AbstractService {

  private val logger = LoggerFactory.getLogger(getClass)

  override
  def doStart(): Unit = {
    try {
      val future = pipeline.start()
      future.onComplete {
        case Success(_)  =>
        logger.error("Pipeline stopped unexpectedly.")
        notifyFailed(new IllegalStateException("Pipeline stopped unexpectedly."))
        case Failure(ex) =>
        logger.error("Pipeline stopped unexpectedly with an error", ex)
        notifyFailed(ex)
      }
      notifyStarted()
    }
    catch {
      case e: Throwable =>
      logger.error("Error while running pipeline", e)
      notifyFailed(e)
    }
  }

  override
  def doStop(): Unit = {
    pipeline.stop()
  }
}
