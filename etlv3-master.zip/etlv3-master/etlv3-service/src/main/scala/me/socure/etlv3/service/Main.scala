package me.socure.etlv3.service

import java.nio.file.Paths
import com.google.inject.{Guice, Injector}
import com.typesafe.config.Config
import me.socure.common.guice.module.CommonModule
import me.socure.common.microservice.defaults.DefaultMicroservice
import me.socure.etlv3.service.flyway.FlywayMigration
import me.socure.etlv3.service.module.Etlv3ServiceModule
import org.apache.commons.io.FileUtils
import org.slf4j.{Logger, LoggerFactory}
import scala.util.{Failure, Success, Try}
import net.codingwell.scalaguice.InjectorExtensions._

object Main extends DefaultMicroservice {

  val Pipline_Cache_Base_Path         = "pipeline.cache.base.path"
  val Pipline_Cache_Default_Base_Path = "/tmp/etl-v3/caching"

  def startUp(args: Array[String]): Unit = {
    val logger: Logger = LoggerFactory.getLogger(getClass)

    Try {
      val injector: Injector = Guice.createInjector(
                                                     new CommonModule,
                                                     new Etlv3ServiceModule
                                                   )

      val service: Etlv3Service = injector.instance[Etlv3Service]
      val config: Config = injector.instance[Config]

      FlywayMigration.migrate(config)

      service.startService()

      sys.addShutdownHook {
        val cacheBaseDir = if (config.hasPath(Pipline_Cache_Base_Path)) Paths.get(config.getString
        (Pipline_Cache_Base_Path)
                                                                                 )
                           else Paths.get(Pipline_Cache_Default_Base_Path)
        FileUtils.deleteQuietly(cacheBaseDir.toFile)
      }

    } match {
      case Success(_)  =>
      case Failure(ex) =>
      logger.error("Unable to start service", ex)
      System.exit(1)
    }
  }
}
