package me.socure.etlv3.service

import java.util.concurrent.TimeUnit
import com.google.common.util.concurrent.ServiceManager.Listener
import com.google.common.util.concurrent.{MoreExecutors, Service, ServiceManager}
import com.typesafe.config.Config
import javax.inject.Inject
import me.socure.common.environment.AppName
import me.socure.common.environment.Environment.AppEnvironment
import org.slf4j.LoggerFactory
import scala.collection.JavaConverters._
import scala.concurrent.ExecutionContext

class Etlv3Service @Inject()(
                              appName        : AppName,
                              environment    : AppEnvironment,
                              config         : Config,
                              executorContext: ExecutionContext,
                              pipelineService: PipelineService
                            ) {

  private val logger = LoggerFactory.getLogger(getClass)

  def startService(): ServiceManager = {

    implicit val executorContextImp: ExecutionContext = executorContext
    val services: Set[Service] = Set(pipelineService)
    val manager: ServiceManager = new ServiceManager(services.asJava)

    manager.addListener(new Listener() {
      override
      def stopped(): Unit = {
        logger.info("Service stopped.")
      }

      override
      def healthy(): Unit = {
        logger.info("Services are healthy.")
      }

      override
      def failure(service: Service): Unit = {
        logger.error(s"Service ${service.getClass} failed.")
        System.exit(1)
      }
    }, MoreExecutors.directExecutor()
                       )

    sys.addShutdownHook {
      manager.stopAsync().awaitStopped(5, TimeUnit.SECONDS)
    }
    manager.startAsync()
  }
}
