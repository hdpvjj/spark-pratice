package me.socure.etlv3.service.flyway

case
class CustomKeyInfo(
                     private_key : String,
                     passphrase  : String
                   )