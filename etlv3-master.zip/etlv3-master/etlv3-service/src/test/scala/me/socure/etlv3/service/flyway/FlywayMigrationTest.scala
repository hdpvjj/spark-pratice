package me.socure.etlv3.service.flyway

import org.scalatest.{FunSuite, Matchers}
import org.scalatest.mockito.MockitoSugar
import scala.io.Source

class FlywayMigrationTest extends FunSuite with Matchers with MockitoSugar {

  test("parse secret string  as expected") {
    val response = FlywayMigration.parseSecretString("{\"private_key\":\"pkey\", \"passphrase\":\"pass\"}")
    response.private_key shouldBe "pkey"
    response.passphrase shouldBe "pass"
  }

  test("get private key as expected") {
    val pkFile = Source.fromURL(getClass.getResource("/test.json")).mkString
    val parsedOutput = FlywayMigration.parseSecretString(pkFile)
    val response = FlywayMigration.getPrivateKey(parsedOutput.private_key, parsedOutput.passphrase)
    response.getAlgorithm shouldBe "RSA"
  }

}
