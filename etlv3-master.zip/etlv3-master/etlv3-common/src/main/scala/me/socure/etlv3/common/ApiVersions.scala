package me.socure.etlv3.common

object ApiVersions extends Enumeration {
  type ApiVersion = Value

  val V30: ApiVersion = Value(30, "3.0")
}
