package me.socure.etlv3.common

case
class Address(
               addressType: Option[String],
               line1           : Option[String],
               line2           : Option[String],
               city            : Option[String],
               state           : Option[String],
               postalCode      : Option[String],
               country         : Option[String]
             ) {
  def isEmpty: Boolean = addressType.isEmpty
}
