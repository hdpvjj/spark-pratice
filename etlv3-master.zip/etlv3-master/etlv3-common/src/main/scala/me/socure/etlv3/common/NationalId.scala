package me.socure.etlv3.common

case class NationalId(
                       isAllOne: Boolean,
                       isAllZero: Boolean,
                       isValid: Boolean,
                       sizeOfSSN: Int
                     )