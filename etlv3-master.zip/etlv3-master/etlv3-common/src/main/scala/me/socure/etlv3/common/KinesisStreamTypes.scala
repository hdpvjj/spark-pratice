package me.socure.etlv3.common

object KinesisStreamTypes extends Enumeration {
  type KinesisStreamType = Value
  val TransactionStream                 = Value("transactionKinesisStream")
  val ReasonCodeStream                  = Value("reasoncodeKinesisStream")
  val RuleCodeStream                    = Value("ruleCodeStream")
  val WatchlistStream                   = Value("watchlistStream")
  val ModelScoreStream                  = Value("modelScoreStream")
  val ModelScoreResponseStream          = Value("modelScoreResponseStream")
  val TransactionPiiStream              = Value("transactionPiiKinesisStream")
  val TransactionRawStream              = Value("transactionRawKinesisStream")
  val RuleCodeIntactStream              = Value("ruleCodeIntactKinesisStream")
  val NonConsentingTransactionPiiStream = Value("nonConsentingTransactionPiiStream")
  val NonConsentingTransactionRawStream = Value("nonConsentingTransactionRawStream")
  val KYCCodeStream                 = Value("KYCCodeStream")
  val DecisionStream                    = Value("decisionKinesisStream")
  val DocVStream                        = Value("DocVStream")
  val NonConsentingDocVStream           = Value("nonConsentingDocVStream")
  val PrefillStream                        = Value("PrefillStream")
  val NonConsentingPrefillStream           = Value("nonConsentingPrefillStream")

  def getKinesisName(name: String) = {
    KinesisStreamTypes.withName(name).toString
  }
}
