package me.socure.etlv3.common

object ErrorResponses {

  def dataValidationFailed(error: String) = ErrorResponseWithHttpStatus(ErrorResponse(
    code = 108,
    message = s"Data validation failed due to : $error"
  ), httpStatus = 400)

  def internalException(error: String) = ErrorResponseWithHttpStatus(ErrorResponse(
    code = 108,
    message = s"Request failed with error : $error"
  ), httpStatus = 500)

  def internalError(exception: Exception): ErrorResponse = {
    ErrorResponse(
      code = 108,
      message = s"Request failed with error : ${exception.getMessage}"
    )
  }

}
