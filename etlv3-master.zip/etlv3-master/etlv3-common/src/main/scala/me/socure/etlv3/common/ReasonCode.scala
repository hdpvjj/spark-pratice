package me.socure.etlv3.common

case class ReasonCode(
                  transactionId: String,
                  accountId    : String,
                  payload      : Option[String]
                ) extends Data

case class ReasonCodeValue(
                       value: String
                     ) extends AnyVal
