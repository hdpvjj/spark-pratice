package me.socure.etlv3.common

import me.socure.common.sqs.v2.MessageId

case class WrappedMsg(id: MessageId, body: String, messageReceiveCount: Option[Int])
