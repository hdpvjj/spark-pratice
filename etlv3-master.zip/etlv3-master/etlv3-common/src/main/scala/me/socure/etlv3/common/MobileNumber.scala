package me.socure.etlv3.common

case class MobileNumber(
                         isInSeq: Boolean,
                         isAllOne: Boolean,
                         isAllSame: Boolean,
                         isAlternate: Boolean,
                         sizeOfMobileNumber: Int
                       )