package me.socure.etlv3.common

case class Decision(
                           transactionId : String,
                           accountId     : String,
                           payload       : Option[String]
                         ) extends Data