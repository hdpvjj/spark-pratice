package me.socure.etlv3.common

object ParserTypes extends Enumeration {

  type ParserType = Value

  val TransactionParser        : ParserType = Value("transaction")
  val ReasonCodeParser         : ParserType = Value("reasoncode")
  val RuleCodeParser           : ParserType = Value("rulecode")
  val WatchlistParser          : ParserType = Value("watchlist")
  val ModelScoreParser         : ParserType = Value("modelscore")
  val ModelScoreResponseParser : ParserType = Value("modelscoreresponse")
  val TransactionPiiParser     : ParserType = Value("transactionpii")
  val TransactionRawParser     : ParserType = Value("transactionraw")
  val RuleCodeIntactParser     : ParserType = Value("rulecodeintact")
  val KYCCodeParser            : ParserType = Value("kyccode")
  val DecisionParser           : ParserType = Value("decision")
  val DocVParser               : ParserType = Value("docv")
  val PrefillParser            : ParserType = Value("prefill")
}
