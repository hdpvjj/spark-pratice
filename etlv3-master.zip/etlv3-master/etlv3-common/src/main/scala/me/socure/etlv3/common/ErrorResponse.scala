package me.socure.etlv3.common

case class ErrorResponse(val code: scala.Int, val message: scala.Predef.String) extends scala.AnyRef with scala.Product
  with scala.Serializable {
}
