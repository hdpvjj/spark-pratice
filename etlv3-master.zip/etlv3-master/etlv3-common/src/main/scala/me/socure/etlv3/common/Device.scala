package me.socure.etlv3.common

case
class Device(
              deviceType: Option[String],
              operatingSystem: Option[String],
              deviceInterface: Option[String]
            ) {
  def isEmpty: Boolean = deviceType.isEmpty && operatingSystem.isEmpty && deviceInterface.isEmpty
}
