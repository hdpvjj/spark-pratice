package me.socure.etlv3.common

import me.socure.common.sqs.v2.MessageId
import org.joda.time.{DateTime, DateTimeZone}
import argonaut.{DecodeResult, Json}

case class TransactionInput(
                        messageId                : MessageId,
                        transactionId            : String,
                        transactionDate          : DateTime,
                        api                      : Api,
                        accountId                : Option[Long],
                        environmentId            : Option[Long],
                        runId                    : Option[String],
                        country                  : Option[String],
                        payload                  : Json,
                        ruleCode                 : DecodeResult[Set[RuleCode]],
                        rulCodeSchema            : List[RuleCodeSchema],
                        documentUuid             : Option[String],
                        userIdConsentingAccounts : List[Long] = List.empty[Long],
                        tetlProcTime             : DateTime = DateTime.now(DateTimeZone.UTC)
                      )
