package me.socure.etlv3.common

case
class Watchlist(
                 transactionId: String,
                 accountId    : String,
                 payload      : Option[String]
               ) extends Data
