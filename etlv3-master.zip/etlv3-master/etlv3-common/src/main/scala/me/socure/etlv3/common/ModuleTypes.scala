package me.socure.etlv3.common

object ModuleTypes extends Enumeration {
  type ModuleType = Value
  val AlertList             : ModuleType = Value("alertlist")
  val Kyc                   : ModuleType = Value("kyc")
  val PhoneRisk             : ModuleType = Value("phonerisk")
  val EmailRisk             : ModuleType = Value("emailrisk")
  val AddressRisk           : ModuleType = Value("addressrisk")
  val Fraud                 : ModuleType = Value("fraud")
  val Synthetic             : ModuleType = Value("synthetic")
  val Noop                  : ModuleType = Value("noop")
  val WatchlistPremier      : ModuleType = Value("watchlistpremier")
  val WatchlistPlus         : ModuleType = Value("watchlistplus")
  val WatchlistStandard     : ModuleType = Value("watchliststandard")
  val Decision              : ModuleType = Value("decision")
  val Ecbsv                 : ModuleType = Value("ecbsv")
  val AllCorrelations       : ModuleType = Value("allcorrelations")
  val Social                : ModuleType = Value("social")
  val DocumentVerification  : ModuleType = Value("documentverification")
  val Prefill               : ModuleType = Value("prefill")
  val NamePhoneCorrelation  : ModuleType = Value("namephonecorrelation")
  val NameEmailCorrelation  : ModuleType = Value("nameemailcorrelation")
  val NameAddressCorrelation: ModuleType = Value("nameaddresscorrelation")
  val DeviceIdentityCorrelation: ModuleType = Value("deviceidentitycorrelation")
  val DeviceRisk            : ModuleType = Value("devicerisk")
  val KycPlus               : ModuleType = Value("kycplus")
  val AccountIntelligence   : ModuleType = Value("accountintelligence")
}
