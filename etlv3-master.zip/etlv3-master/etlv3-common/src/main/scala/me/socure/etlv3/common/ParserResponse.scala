package me.socure.etlv3.common

case class ParserResponse(
                      data: Data,
                      streamType: String
                    )
