package me.socure.etlv3.common

object ApiTypes extends Enumeration {
  type ApiType = Value
  val EmailAuthScore         : ApiType = Value(2, "EmailAuthScore")
  val EncryptedEmailAuthScore: ApiType = Value(4, "EncryptedEmailAuthScore")
}
