package me.socure.etlv3.common

case
class RuleCode(
                name : Option[String],
                value: Option[String]
              ) {
  self =>

  def lower: RuleCode = copy(name = self.name.map(_.toLowerCase()))

  def isEmpty: Boolean = name.isEmpty
}

case
class RuleCodeValue(
                     transactionId: String,
                     accountId    : String,
                     payload      : Option[String]
                   ) extends Data
