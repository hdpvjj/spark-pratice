package me.socure.etlv3.common

import argonaut.{DecodeJson, DecodeResult, HCursor}

import scala.language.implicitConversions

case class JsonValue[T](value: Option[T])

object JsonValue {

  private def emptyJsonValue[T]: JsonValue[T] = JsonValue(Option.empty[T])

  private def extract[T](h: HCursor, decodeJson: DecodeJson[T]): DecodeResult[JsonValue[T]] = {
    h.as[Option[T]](DecodeJson.OptionDecodeJson[T](decodeJson)).result match {
      case Right(b) => DecodeResult.ok(JsonValue(b))
      case Left(_) => DecodeResult.ok(emptyJsonValue[T])
    }
  }

  private def extractAsStringOpt[T](h: HCursor, decodeJson: DecodeJson[T]): Option[String] = {
    h.as[Option[T]](DecodeJson.OptionDecodeJson[T](decodeJson)).result match {
      case Right(b) => b.map(_.toString)
      case Left(_) => Option.empty[String]
    }
  }

  implicit val stringJsonValueCodec: DecodeJson[JsonValue[String]] = DecodeJson { h =>
  extractAsStringOpt(h, DecodeJson.StringDecodeJson)
  .orElse(extractAsStringOpt(h, DecodeJson.BooleanDecodeJson))
  .orElse(extractAsStringOpt(h, DecodeJson.BigDecimalDecodeJson))
  .orElse(extractAsStringOpt(h, DecodeJson.LongDecodeJson)) match {
    case Some(x) => DecodeResult.ok(JsonValue(x))
    case None => DecodeResult.fail("Unable to extract as string", h.history)
  }
  }

  implicit val booleanJsonValueCodec: DecodeJson[JsonValue[Boolean]] = DecodeJson(extract(_, DecodeJson.BooleanDecodeJson))

  implicit val longJsonValueCodec: DecodeJson[JsonValue[Long]] = DecodeJson(extract(_, DecodeJson.LongDecodeJson))

  implicit val intJsonValueCodec: DecodeJson[JsonValue[Int]] = DecodeJson(extract(_, DecodeJson.IntDecodeJson))

  implicit val bigDecimalJsonValueCodec: DecodeJson[JsonValue[BigDecimal]] = DecodeJson(extract(_, DecodeJson.BigDecimalDecodeJson))

  implicit def stringJsonValueOptToStringOpt(jsonValueOpt: Option[JsonValue[String]]): Option[String] = jsonValueOpt.flatMap(_.value)

  implicit def booleanJsonValueOptToBooleanOpt(jsonValueOpt: Option[JsonValue[Boolean]]): Option[Boolean] = jsonValueOpt.flatMap(_.value)

  implicit def longJsonValueOptToBooleanOpt(jsonValueOpt: Option[JsonValue[Long]]): Option[Long] = jsonValueOpt.flatMap(_.value)

  implicit def intJsonValueOptToIntOpt(jsonValueOpt: Option[JsonValue[Int]]): Option[Int] = jsonValueOpt.flatMap(_.value)

  implicit def bigDecimaJsonValueOptToBooleanOpt(jsonValueOpt: Option[JsonValue[BigDecimal]]): Option[BigDecimal] = jsonValueOpt.flatMap(_.value)

  implicit def stringToStringOpt(str: String): Option[String] = Some(str)

}