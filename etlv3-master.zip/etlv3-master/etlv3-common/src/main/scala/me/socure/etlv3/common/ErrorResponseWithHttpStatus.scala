package me.socure.etlv3.common

case class ErrorResponseWithHttpStatus(val errorResponse : ErrorResponse, val httpStatus : scala.Int) extends scala.Exception with scala.Product with scala.Serializable {
}
