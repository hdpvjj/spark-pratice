package me.socure.etlv3.common

import me.socure.etlv3.common.ApiTypes.ApiType
import me.socure.etlv3.common.ApiVersions.ApiVersion

case class Api(apiType: ApiType, version: ApiVersion)

object Api {
  def parse(apiName: String): Option[Api] = {
    Option(apiName).map(_.trim.toLowerCase.stripPrefix("/")) match {
      case Some("api/3.0/emailauthscore")          => Some(Api(apiType = ApiTypes.EmailAuthScore, version =
        ApiVersions.V30))
      case Some("api/3.0/encryptedemailauthscore") => Some(Api(apiType = ApiTypes.EncryptedEmailAuthScore, version =
        ApiVersions.V30))
      case _                                       => None
    }
  }
}
