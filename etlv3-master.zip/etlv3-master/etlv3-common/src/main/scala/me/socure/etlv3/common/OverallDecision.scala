package me.socure.etlv3.common

case class OverallDecision(value: String) extends AnyVal
