package me.socure.etlv3.common

case
class Payment(
               paymentType: Option[String],
               recipientCountry: Option[String],
               disbursementType: Option[String],
               account: Option[Account] = None
             ) {
  def isEmpty: Boolean = {
    paymentType.isEmpty
  }
}

case class Account(
                    accountNumber  : Option[String],
                    routingNumber  : Option[String],
                    inquiries      : Option[Set[String]],
                    validInquiries : Option[Boolean]
                  )