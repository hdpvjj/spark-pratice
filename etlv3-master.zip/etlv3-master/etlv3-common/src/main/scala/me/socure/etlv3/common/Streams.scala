package me.socure.etlv3.common

object Streams extends Enumeration {
  type Stream = Value

  val TRANSACTION    = Value("transaction")
  val RULECODE       = Value("rulecode")
  val WATCHLIST      = Value("watchlist")
  val REASONCODE     = Value("reasoncode")
  val MODELSCORE     = Value("modelscore")
  val MODELSCORERESPONSE = Value("modelscoreresponse")
  val TRANSACTIONPII = Value("transactionpii")
  val TRANSACTIONRAW = Value("transactionraw")
  val RULECODEINTACT = Value("rulecodeintact")

}
