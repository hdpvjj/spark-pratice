package me.socure.etlv3.common

case class DataKeyServiceResponse(
                                   data: Array[Array[String]]
                                 )