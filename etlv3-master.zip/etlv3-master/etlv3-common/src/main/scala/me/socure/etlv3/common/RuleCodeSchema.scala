package me.socure.etlv3.common

case
class RuleCodeSchema(
                      name         : String,
                      kinesisStream: String,
                      ruleCodes    : Set[String]
                    )
