package me.socure.etlv3.common

trait Data {
  val transactionId: String
  val accountId    : String
  val payload      : Option[String]
}
