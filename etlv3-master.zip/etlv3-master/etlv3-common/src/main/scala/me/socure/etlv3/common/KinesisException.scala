package me.socure.etlv3.common

import scala.util.control.NoStackTrace

case class KinesisException(error: String) extends Exception(s"Error while parsing data $error") with NoStackTrace
