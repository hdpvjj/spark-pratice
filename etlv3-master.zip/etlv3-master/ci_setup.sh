#!/bin/bash

# CI shared setup before running maven
amazon-linux-extras enable corretto8
yum update -y
yum install -y wget tar
yum install -y java-1.8.0-amazon-corretto-devel
# JAVA_HOME needs some fips setup as per the following doc:
# https://confluence.socure.com/display/ENG/FIPS+Compliance+Migration+on+Socure+Microservices
wget https://downloads.bouncycastle.org/fips-java/bc-fips-1.0.2.3.jar
export JAVA_HOME=/usr/lib/jvm/jre-1.8.0-openjdk
cp bc-fips-1.0.2.3.jar $JAVA_HOME/lib/ext/
ls $JAVA_HOME/lib/ext/
yum install -y which
wget https://www-eu.apache.org/dist/maven/maven-3/3.8.8/binaries/apache-maven-3.8.8-bin.tar.gz
tar xzvf apache-maven-3.8.8-bin.tar.gz
ls -l
ls -l apache-maven-3.8.8/bin
export M2_HOME=apache-maven-3.8.8
export MAVEN_HOME=apache-maven-3.8.8
export PATH=${M2_HOME}/bin:${PATH}