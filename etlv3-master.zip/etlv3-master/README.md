# Transaction ETL

ETL pipeline that separates out PII from non PII and delivers in Snowflake with Sensitive Data Management.

## Build and Run

Build Service Locally:
- mvn clean install

Running Tests Locally:
- Running test through IDE
- mvn clean test
- mvn test -DskipTests=false -pl etlv3-parser -am (for running test per module)

Running Service Locally:
Setup environment variables in IDE:
- APP_ENVIRONMENT=test
- CONFIGURATION_NAME=test
- AWS_REGION=us-east-1
- Setup additional compiler options under scala compiler settings "-target:jvm-1.8"
- AWS_CBOR_DISABLE=true
- Run Main.scala


## Version
The version of the parent module is tied to the revision property in the parent pom.xml as documented here ( https://maven.apache.org/maven-ci-friendly.html

## Code flow
etlv3-service: The service that binds everything and is the entrypoint
etlv3-processor: The processing logic which calls the parser
etlv3-parser: The parsing logic for each table that gets to firehose
etlv3-kinesis: The pushing loging for each table data in its respective firehose
etlv3-common: The shared logic used by above modules

## Configs

This repository uses the Socure Common library to read the configs on which the app runs. This library determines a
specific pattern for how configs should be stored in S3 where they are retrieved on app start up.

- If the APP_ENVIRONMENT = test or dev and CONFIGURATION_NAME = test or dev, then the configs `test.conf` and `test.xml` are
  retrieved from the `src/main/resources` directory.
- If the APP_ENVIRONMENT and CONFIGURATION_NAME are set to stage, prod or ds, then the config is retrieved from S3 according
  to a set of environment variables.
    - CONFIGURATION_NAME, CONFIGURATION,BUCKET, CONFIGURATION_VERSION, APP_REGION, APP_ENVIRONMENT must all be set.
    - `s3:
      //${CONFIGURATION_BUCKET}/{CONFIGURATION_NAME}/{CONFIGURATION_VERSION}/configurations/{APP_REGION}/{APP_ENVIORNMENT}.conf`
        - e.g. `s3://dapl-microservice-configurations/transaction-etl/0.1-SNAPSHOT/configurations/us-east-1/prod.conf`
        - e.g. for GovCloud: `s3://dapl-microservice-configurations-049930887470-us-gov-west-1/transaction-etl/0.1-SNAPSHOT/configurations/us-gov-west-1/prod.conf`
    - `s3://${CONFIGURATION_BUCKET}/{CONFIGURATION_NAME}/{CONFIGURATION_VERSION}/logs/{APP_ENVIORNMENT}.xml`
        - e.g. `s3://dapl-microservice-configurations/transaction-etl/0.1-SNAPSHOT/logs/prod.xml`
        - e.g. for GovCloud: `s3://dapl-microservice-configurations-049930887470-us-gov-west-1/transaction-etl/0.1-SNAPSHOT/logs/prod.xml`

This requires a manual push to s3 post change.