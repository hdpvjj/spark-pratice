package me.socure.etlv3.processor.actor.transaction

import me.socure.etlv3.kinesis.KinesisProcessorService
import me.socure.etlv3.processor.actor.{DataExecutor, DataProcessorActor}

class TrasactionProcessorActor(
                                val kinesisProcessorService: KinesisProcessorService
                              ) extends DataExecutor {
  val processorType = DataProcessorActor.TransactionDataProcessor
}
