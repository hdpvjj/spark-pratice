package me.socure.etlv3.processor

import java.util.UUID
import me.socure.common.metrics.{JavaMetricsFactory, Metrics}
import me.socure.common.sqs.v2.{FailedMessageIds, MessageId, MessagesProcessor}
import me.socure.etlv3.kinesis.KinesisProcessorService
import me.socure.etlv3.processor.TransactionProcessor.Msged
import me.socure.etlv3.processor.actor.DataProcessorActor
import org.joda.time.DateTime
import org.slf4j.LoggerFactory
import akka.actor.{ActorSystem, Props}
import me.socure.etlv3.processor.actor.DataProcessorActor.{DataProcessorFailure, DataProcessorResult, DataProcessorTimeout, ProcessRequest}
import akka.pattern.{AskTimeoutException, ask}
import akka.util.Timeout
import com.github.blemale.scaffeine.AsyncLoadingCache
import me.socure.etlv3.common.{TransactionInput, WrappedMsg}
import me.socure.etlv3.parser.{TransactionInputParser, UnsupportedApiException}
import me.socure.etlv3.processor.provider.ParserProvider
import scala.concurrent.duration._
import scala.concurrent.{Await, ExecutionContext, Future}
import scala.util.control.NonFatal
import datadog.trace.api.Trace
import scala.collection.mutable
import io.opentracing.util.GlobalTracer

class TransactionProcessor(
                            extractor     : TransactionInputParser,
                            kinesisService: KinesisProcessorService,
                            cacheDataKeys : AsyncLoadingCache[Int, Map[String, Array[Byte]]],
                            datadogEnvTag : String,
                            nonConsentingAccounts: List[Long],
                            failAccountIdZero: Boolean,
                            piiFeatureFlag: Boolean,
                            userIdConsentingAccounts: List[Long]
                          )(implicit ec: ExecutionContext, askTimeout: Timeout) extends MessagesProcessor[CachedMsg] {

  private val logger           = LoggerFactory.getLogger(getClass)
  private val jMetrics         = JavaMetricsFactory.get(getClass)
  private val metrics: Metrics = jMetrics
  val system = ActorSystem("DataExecutor")


  override def process(messages: Iterable[CachedMsg]): Future[FailedMessageIds] = Future {
    batchProcess(messages)
  }

  private def processRequest(trxInput: TransactionInput, msg: WrappedMsg, logMessage: Option[String]):Future[TransactionProcessor.Msged[Option[String]]] = {

    val uniqueBatchName = UUID.randomUUID().toString.replaceAll("-", "")

    if(!failAccountIdZero && trxInput.accountId.isDefined && trxInput.accountId.contains(0)) {
      logger.info(s"Data processing is skipped for transaction ${trxInput.transactionId} as accountId is ${trxInput.accountId.get}")
      metrics.increment("etl.data.skip.processing.accountId.zero", s"env:${datadogEnvTag}" )
      Future.successful(Msged(Some(trxInput.transactionId), msg.id, trxInput.transactionId))
    } else {

      val dataKeys = if (piiFeatureFlag) {
        Await.result(cacheDataKeys.get(0), Duration.Inf)
      } else {
        Map.empty[String, Array[Byte]]
      }

      val dataProcessorActor = system.actorOf(Props(new DataProcessorActor(kinesisService, dataKeys, datadogEnvTag, nonConsentingAccounts)), uniqueBatchName)

      (
      metrics.timeFuture("etl.overall.transaction.processing.duration", s"env:${datadogEnvTag}")(dataProcessorActor ? ProcessRequest(ParserProvider.getParsers(), trxInput)).recoverWith {
        case ex: AskTimeoutException =>
        if (actorIsTerminated(ex)) {
          logger.info(s"Recover Ask Timeout Exception while recipient got terminated for trxId ${trxInput.transactionId} and message key : ${msg.id}", ex)
        }
        else {
          logger.info(s"Recover Ask Timeout Exception for trxId ${trxInput.transactionId} and message key : ${msg.id}", ex)
        }
        metrics.increment("etl.recover.ask.timeout.error", s"class:${ex.getClass.getSimpleName}", s"env: ${datadogEnvTag}")
        processRequest(trxInput, msg, Some(s"Reprocessing ${trxInput.transactionId} as AskTimeOut exception occurred"))
        case NonFatal(ex)            =>
        throw ex
      }
      ).map {
        case DataProcessorResult  =>
        logger.info(s"Data processing is successful for transaction ${trxInput.transactionId}")
        system.stop(dataProcessorActor)
        metrics.increment("etl.data.processing.success", s"env:${datadogEnvTag}")
        if (!logMessage.forall(_.isEmpty)) {
          metrics.increment("etl.data.reprocessing.timed.out.trx.success", s"env:${datadogEnvTag}")
        }
        Msged(Some(trxInput.transactionId), msg.id, trxInput.transactionId)
        case DataProcessorFailure =>
        logger.error(s"Data processing is failed for transaction ${trxInput.transactionId}")
        system.stop(dataProcessorActor)
        metrics.increment("etl.data.processing.failed", s"env:${datadogEnvTag}")
        Msged(None, msg.id, "")

        case DataProcessorTimeout =>
        logger.error(s"Data processing is timed out for transaction ${trxInput.transactionId}")
        system.stop(dataProcessorActor)
        metrics.increment("etl.data.processing.timed.out", s"env:${datadogEnvTag}")
        Msged(None, msg.id, "")
        case _                    =>
        logger.error(s"Transaction processing failure for transaction ${trxInput.transactionId}")
        system.stop(dataProcessorActor)
        Msged(Some(trxInput.transactionId), msg.id, "")
      }
    }
  }

  @Trace(operationName = "etlv3.msg.process", resourceName = "etlv3-processor.batchprocess")
  private def batchProcess(messages: Iterable[CachedMsg]): FailedMessageIds = {

    val trxTrack = mutable.Map.empty[String, (MessageId, DateTime)]

    val stats = messages.foldLeft(List.empty[Msged[Serializable]])((msgList, message) => {
      val messageResolved = message.getUnsafe
      message.remove()
      val processedMessages = try {
        val trxInput = metrics.time("etl.extract.duration", s"env:${datadogEnvTag}")(extractor.parse(messageResolved, userIdConsentingAccounts))
        if (!trxTrack.contains(trxInput.transactionId)) {
          val tracer = GlobalTracer.get()
          val span = tracer.buildSpan("process.request").start()
          span.setTag("transaction.id", trxInput.transactionId)
          trxTrack.put(trxInput.transactionId, (messageResolved.id, trxInput.transactionDate))
          Await.result(processRequest(trxInput, messageResolved, None), Duration.Inf)
        }
        else {
          metrics.increment("etl.duplicate.error", s"env:${datadogEnvTag}")
          Msged(None, message.key, trxInput.transactionId)
        }
      }
      catch {
        case ex: UnsupportedApiException =>
          logger.info(s"Unsupported Api Exception : ${message.key}", ex)
          metrics.increment("etl.unsupported.api.ignore", s"class:${ex.getClass.getSimpleName}", s"env:${datadogEnvTag}")
          Msged(Some(""), messageResolved.id, "")
        case ex: AskTimeoutException =>
          logger.info(s"Akka Ask Timeout Exception : ${message.key}", ex)
          metrics.increment("etl.ask.timeout.error", s"class:${ex.getClass.getSimpleName}", s"env:${datadogEnvTag}")
          Msged(None, messageResolved.id, "")
        case NonFatal(ex) =>
         logger.error(s"Error while extracting/parsing message using the TrxInputParser : ${message.key}", ex)
         metrics.increment("etl.parse.error", s"class:${ex.getClass.getSimpleName}", s"env:${datadogEnvTag}")
         Msged(Some(""), messageResolved.id, "")
      }
      msgList ++ List(processedMessages)
    }
                                                                  )
    trxTrack.clear()
    val result = stats.collect { case Msged(None, msg, trxId) => (msg, trxId) }
    FailedMessageIds(result.map(msgid => msgid._1))
  }

  private def actorIsTerminated(askTimeoutException: AskTimeoutException) = {
    actorTerminatedRegex.findFirstIn(askTimeoutException.getMessage).nonEmpty
  }

  private val actorTerminatedRegex = """Recipient\[.*]\] had already been terminated.""".r

}

object TransactionProcessor {

  case class Msged[+A](value: A, message: MessageId, transactionId: String) {
    def map[B](f: A => B): Msged[B] = {
      Msged(
             value = f(value),
             message = message,
             transactionId = transactionId
           )
    }
  }

}
