package me.socure.etlv3.processor.actor.kyccode

import me.socure.etlv3.kinesis.KinesisProcessorService
import me.socure.etlv3.processor.actor.{DataExecutor, DataProcessorActor}

class KYCCodeProcessorActor(val kinesisProcessorService: KinesisProcessorService) extends DataExecutor {
  val processorType = DataProcessorActor.KYCCodeDataProcessor
}
