package me.socure.etlv3.processor.actor.modelscore

import me.socure.etlv3.kinesis.KinesisProcessorService
import me.socure.etlv3.processor.actor.{DataExecutor, DataProcessorActor}

class ModelScoreProcessorActor(
                                val kinesisProcessorService: KinesisProcessorService
                              ) extends DataExecutor {
  val processorType = DataProcessorActor.ModelScoreDataProcessor
}

