package me.socure.etlv3.processor.actor

import akka.actor.Actor
import me.socure.common.metrics.{JavaMetricsFactory, Metrics}
import me.socure.etlv3.kinesis.KinesisProcessorService
import me.socure.etlv3.processor.actor.DataProcessorActor._
import org.slf4j.LoggerFactory
import scala.util.control.NonFatal

trait DataExecutor extends Actor {
  val processorType: DataProcessorType
  val kinesisProcessorService: KinesisProcessorService
  private val logger           = LoggerFactory.getLogger(getClass)
  private val jMetrics         = JavaMetricsFactory.get(getClass)
  private val metrics: Metrics = jMetrics

  def receive = {
    case ParseTransaction(parser, trxInput) =>
      try {
        val parserResponse = parser.parse(trxInput)
        logger.info(s"${trxInput.transactionId} : parsed successfully and is about to be written to stream ${parserResponse.streamType}")
        sender ! DataProcessorStatus(processorType, Some(parserResponse), trxInput.transactionId, false)
      } catch {
        case NonFatal(ex) =>
          logger.error(s"Transaction parsing failure ${trxInput.transactionId} $ex")
          sender ! DataProcessorStatus(processorType, None, trxInput.transactionId, true)
      }


    case ParseTransactionPii(parser, trxInput, dataKey, datadogEnvTag) =>
      try {
        logger.info(s"start to parse ${parser.toString}")
        val parserResponse = parser.parse(trxInput, dataKey)
        logger.info(s"${trxInput.transactionId} : parsed successfully and is about to be written to stream ${parserResponse.streamType}")
        sender ! DataProcessorStatus(processorType, Some(parserResponse), trxInput.transactionId, false)
      } catch {
        case NonFatal(ex) =>
        logger.error(s"${trxInput.transactionId} TransactionPii parsing failure $ex")
        metrics.increment("etlv3.pii.parser.failure.count", s"env:$datadogEnvTag")
        if (ex.toString contains "DataKey not found") {
          metrics.increment("etlv3.pii.parser.failure.datakey.count", s"env:$datadogEnvTag")
        }
        sender ! DataProcessorStatus(processorType, None, trxInput.transactionId, true)
      }
  }
}
