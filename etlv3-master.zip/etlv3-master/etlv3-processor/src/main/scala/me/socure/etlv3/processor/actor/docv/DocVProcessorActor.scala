package me.socure.etlv3.processor.actor.docv

import me.socure.etlv3.kinesis.KinesisProcessorService
import me.socure.etlv3.processor.actor.{DataExecutor, DataProcessorActor}

class DocVProcessorActor(
                             val kinesisProcessorService: KinesisProcessorService,
                             val dataKeys               : Map[String, Array[Byte]]
                           ) extends DataExecutor {
  val processorType = DataProcessorActor.DocVDataProcessor
}
