package me.socure.etlv3

import me.socure.common.sqs.v2.MessageId
import me.socure.common.storage.CachedValueSync
import me.socure.etlv3.common.WrappedMsg

package object processor {
  type CachedMsg = CachedValueSync[MessageId, WrappedMsg]
}
