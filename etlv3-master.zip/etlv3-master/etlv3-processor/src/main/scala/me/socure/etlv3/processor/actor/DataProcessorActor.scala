package me.socure.etlv3.processor.actor

import akka.actor.{Actor, ActorRef, Props, ReceiveTimeout}
import akka.util.Timeout
import me.socure.common.metrics.{JavaMetricsFactory, Metrics}
import me.socure.etlv3.common.ParserTypes.ParserType
import me.socure.etlv3.common.{ParserResponse, ParserTypes, TransactionInput}
import me.socure.etlv3.kinesis.KinesisProcessorService
import me.socure.etlv3.parser.{SimpleDataParser, SimplePiiDataParser}
import me.socure.etlv3.parser.modelscore.ModelScoreParser
import me.socure.etlv3.parser.modelscoreresponse.ModelScoreResponseParser
import me.socure.etlv3.parser.reasoncode.ReasonCodeParser
import me.socure.etlv3.parser.rulecode.RuleCodeParser
import me.socure.etlv3.parser.rulecodeintact.RuleCodeIntactParser
import me.socure.etlv3.parser.transaction.TransactionParser
import me.socure.etlv3.parser.transactionpii.TransactionPiiParser
import me.socure.etlv3.parser.transactionraw.TransactionRawParser
import me.socure.etlv3.parser.watchlist.WatchlistParser
import me.socure.etlv3.parser.kyccode.KYCCodeParser
import me.socure.etlv3.parser.decision.DecisionParser
import me.socure.etlv3.parser.docv.DocVParser
import me.socure.etlv3.parser.prefill.PrefillParser
import me.socure.etlv3.processor.actor.modelscore.ModelScoreProcessorActor
import me.socure.etlv3.processor.actor.modelscoreresponse.ModelScoreResponseProcessorActor
import me.socure.etlv3.processor.actor.reasoncode.ReasonCodeProcessorActor
import me.socure.etlv3.processor.actor.rulecode._
import me.socure.etlv3.processor.actor.rulecodeintact.RuleCodeIntactProcessorActor
import me.socure.etlv3.processor.actor.transaction.TrasactionProcessorActor
import me.socure.etlv3.processor.actor.transactionpii.TransactionPiiProcessorActor
import me.socure.etlv3.processor.actor.transactionraw.TransactionRawProcessorActor
import me.socure.etlv3.processor.actor.watchlist.WatchlistProcessorActor
import me.socure.etlv3.processor.actor.kyccode.KYCCodeProcessorActor
import me.socure.etlv3.processor.actor.decision.DecisionProcessorActor
import me.socure.etlv3.processor.actor.docv.DocVProcessorActor
import me.socure.etlv3.processor.actor.prefill.PrefillProcessorActor
import org.slf4j.LoggerFactory

import scala.util.control.NonFatal

object DataProcessorActor {

  sealed trait DataProcessorType

  case object TransactionDataProcessor extends DataProcessorType

  case object ReasonCodeDataProcessor extends DataProcessorType

  case object RuleCodeDataProcessor extends DataProcessorType

  case object WatchlistDataProcessor extends DataProcessorType

  case object ModelScoreDataProcessor extends DataProcessorType

  case object ModelScoreResponseDataProcessor extends DataProcessorType

  case object TransactionPiiDataProcessor extends DataProcessorType

  case object TransactionRawDataProcessor extends DataProcessorType

  case object RuleCodeIntactDataProcessor extends DataProcessorType

  case object KYCCodeDataProcessor extends DataProcessorType

  case object DecisionDataProcessor extends DataProcessorType

  case object DocVDataProcessor extends DataProcessorType

  case object PrefillDataProcessor extends DataProcessorType

  val AllDataProcessorsTypes: Set[DataProcessorType] = Set(
    TransactionDataProcessor,
    ReasonCodeDataProcessor,
    RuleCodeDataProcessor,
    WatchlistDataProcessor,
    ModelScoreDataProcessor,
    ModelScoreResponseDataProcessor,
    TransactionPiiDataProcessor,
    TransactionRawDataProcessor,
    RuleCodeIntactDataProcessor,
    KYCCodeDataProcessor,
    DecisionDataProcessor,
    DocVDataProcessor,
    PrefillDataProcessor
  )

  case class ProcessRequest(parser: Seq[ParserType], data: TransactionInput)

  case class ParseTransaction(parser: SimpleDataParser[TransactionInput, ParserResponse], data: TransactionInput)

  case class ParseTransactionPii(parser: SimplePiiDataParser[TransactionInput, Map[String, Array[Byte]], ParserResponse], data: TransactionInput, dataKeys: Map[String, Array[Byte]], datadogEnvTag: String)

  case object DataProcessorResult

  case object DataProcessorTimeout

  case class DataProcessorStatus(dataProcessorType: DataProcessorType, parserResponse: Option[ParserResponse], transactionId: String, isError: Boolean = false)

  case object DataProcessorFailure

  case class TransactionProcessingFailure(dataProcessorType: DataProcessorType)

}

class DataProcessorActor(kinesisProcessorService: KinesisProcessorService, dataKeys: Map[String, Array[Byte]], datadogEnvTag: String, nonConsentingAccounts: List[Long])(implicit askTimeout: Timeout) extends Actor {

  import DataProcessorActor._
  import context._

  private val jMetrics = JavaMetricsFactory.get(getClass)
  private val metrics: Metrics = jMetrics
  private val logger = LoggerFactory.getLogger(getClass)
  var parserResponseBucket = List.empty[ParserResponse]
  var isParserError = false

  override def receive: Receive = dataProcessorRequest

  def dataProcessorRequest: Receive = {
    case processRequest: ProcessRequest =>

      val reqStartTime = System.currentTimeMillis()
      // When dataKeys is empty PII processing should be ignored hence numberOfParsing = number of parsers - number of
      // PII parsers. Remember to change number of PII parsers to subtract when you add new PII parsers.
      val numberOfParsing = (if (dataKeys.nonEmpty) processRequest.parser.length else processRequest.parser.length -
        4) + processRequest.data.rulCodeSchema.length
      logger.info(s"Started processing ${processRequest.data.transactionId}")
      processRequest.parser.map {
        parser =>
          parser match {
            case ParserTypes.TransactionPiiParser =>
              if (dataKeys.nonEmpty) {
                logger.info(s"${processRequest.data.transactionId} : Transaction Pii parsing is processing")
                actorOf(Props(new TransactionPiiProcessorActor(kinesisProcessorService, dataKeys))) ! ParseTransactionPii(
                  TransactionPiiParser(nonConsentingAccounts), processRequest.data, dataKeys, datadogEnvTag)
              }
              else {
                logger.info(s"${processRequest.data.transactionId} : Transaction PII parsing is disabled")
              }

            case ParserTypes.TransactionRawParser =>
              if (dataKeys.nonEmpty) {
                logger.info(s"${processRequest.data.transactionId} : Transaction Raw parsing is processing")
                actorOf(Props(new TransactionRawProcessorActor(kinesisProcessorService, dataKeys))) ! ParseTransactionPii(
                  TransactionRawParser(nonConsentingAccounts), processRequest.data, dataKeys, datadogEnvTag)
              }
              else {
                logger.info(s"${processRequest.data.transactionId} : Transaction Raw parsing is disabled")
              }

            case ParserTypes.RuleCodeIntactParser =>
              logger.info(s"${processRequest.data.transactionId} : Rulecode Intact parsing is processing")
              actorOf(Props(new RuleCodeIntactProcessorActor(kinesisProcessorService))) ! ParseTransaction(RuleCodeIntactParser(),
                processRequest.data
              )

            case ParserTypes.TransactionParser =>
              logger.info(s"${processRequest.data.transactionId} : Transaction parsing is processing")
              actorOf(Props(new TrasactionProcessorActor(kinesisProcessorService))) ! ParseTransaction(TransactionParser(),
                processRequest.data
              )

            case ParserTypes.ReasonCodeParser =>
              logger.info(s"${processRequest.data.transactionId} : Reasoncode parsing is processing")
              actorOf(Props(new ReasonCodeProcessorActor(kinesisProcessorService))) ! ParseTransaction(ReasonCodeParser(),
                processRequest.data
              )

            case ParserTypes.RuleCodeParser =>
              processRequest.data.rulCodeSchema.map {
                rule =>
                  logger.info(s"${processRequest.data.transactionId} : ${rule.kinesisStream} parsing is processing")
                  actorOf(Props(new RuleCodeProcessorActor(kinesisProcessorService))) ! ParseTransaction(
                    RuleCodeParser(),
                    processRequest.data
                      .copy(
                        rulCodeSchema = RuleCodeParser().extractRuleCode(rule.kinesisStream, processRequest.data)
                      )
                  )
              }

            case ParserTypes.WatchlistParser =>
              logger.info(s"${processRequest.data.transactionId} : Watchlist parsing is processing")
              actorOf(Props(new WatchlistProcessorActor(kinesisProcessorService))) ! ParseTransaction(
                WatchlistParser(),
                processRequest.data
              )

            case ParserTypes.ModelScoreParser =>
              logger.info(s"${processRequest.data.transactionId} : Model Score parsing is processing")
              actorOf(Props(new ModelScoreProcessorActor(kinesisProcessorService))) ! ParseTransaction(
                ModelScoreParser(),
                processRequest.data
              )

            case ParserTypes.ModelScoreResponseParser =>
              logger.info(s"${processRequest.data.transactionId} : Model Score Respose parsing is processing")
              actorOf(Props(new ModelScoreResponseProcessorActor(kinesisProcessorService))) ! ParseTransaction(
                ModelScoreResponseParser(),
                processRequest.data
              )

            case ParserTypes.KYCCodeParser =>
              logger.info(s"${processRequest.data.transactionId} : KYC Decision parsing is processing")
              actorOf(Props(new KYCCodeProcessorActor(kinesisProcessorService))) ! ParseTransaction(
                KYCCodeParser(),
                processRequest.data
              )

            case ParserTypes.DecisionParser =>
              logger.info(s"${processRequest.data.transactionId} : The Decision parsing is processing")
              actorOf(Props(new DecisionProcessorActor(kinesisProcessorService))) ! ParseTransaction(
                DecisionParser(),
                processRequest.data
              )

            case ParserTypes.DocVParser =>
              if (dataKeys.nonEmpty) {
                logger.info(s"${processRequest.data.transactionId} : DocV parsing is processing")
                actorOf(Props(new DocVProcessorActor(kinesisProcessorService, dataKeys))) !
                  ParseTransactionPii(DocVParser(nonConsentingAccounts), processRequest.data, dataKeys, datadogEnvTag)
              }
              else {
                logger.info(s"${processRequest.data.transactionId} : DocV parsing is disabled")
              }

            case ParserTypes.PrefillParser =>
              if (dataKeys.nonEmpty) {
                logger.info(s"${processRequest.data.transactionId} : Prefill parsing is processing")
                actorOf(Props(new PrefillProcessorActor(kinesisProcessorService, dataKeys))) !
                  ParseTransactionPii(PrefillParser(nonConsentingAccounts), processRequest.data, dataKeys, datadogEnvTag)
              }
              else {
                logger.info(s"${processRequest.data.transactionId} : Prefill parsing is disabled")
              }
          }

          setReceiveTimeout(askTimeout.duration)
          become(dataProcessorResponse(sender, numberOfParsing - 1, reqStartTime))
      }

      def dataProcessorResponse(
                                 respondTo: ActorRef, totalNumberOfParsing: Int, reqStartTime: Long,
                                 dataProcessors: List[DataProcessorType] = List.empty
                               ): Receive = {
        case DataProcessorStatus(dataProcessorType, parserResponse, transactionId, isError) =>
          if (isError) {
            logger.info(s"${processRequest.data.transactionId} : $dataProcessorType is errored out")
          } else {
            logger.info(s"${processRequest.data.transactionId} : $dataProcessorType is processed successfully")
          }
          val completedDataProcessorList = dataProcessors ++ List(dataProcessorType)
          if (parserResponse.isDefined) {
            parserResponseBucket = parserResponseBucket ++ List(parserResponse.get)
          }
          if (isError) {
            isParserError = true
          }
          metrics.gauge(s"$dataProcessorType.process.time", System.currentTimeMillis() - reqStartTime, s"env:$datadogEnvTag")
          if (completedDataProcessorList.size == totalNumberOfParsing) {
            if (isParserError) {
              isParserError = false
              parserResponseBucket = List.empty[ParserResponse]
              respondTo ! DataProcessorFailure
            } else {
              try {
                parserResponseBucket.par.map {
                  parserResponse =>
                    kinesisProcessorService.processStream(parserResponse.data, parserResponse.streamType)
                }
                logger.info(s"ParserResponse bucket size for trx id $transactionId is ${parserResponseBucket.size}")
                parserResponseBucket = List.empty[ParserResponse]
                respondTo ! DataProcessorResult
              }
              catch {
                case NonFatal(ex) =>
                  logger.error(s"Kinesis processing failure $transactionId $dataProcessorType $ex")
                  parserResponseBucket = List.empty[ParserResponse]
                  respondTo ! DataProcessorFailure
              }
            }
          }
          else {
            become(dataProcessorResponse(respondTo, totalNumberOfParsing, reqStartTime, completedDataProcessorList))
          }

        case ReceiveTimeout =>
          respondTo ! DataProcessorTimeout
      }
  }
}
