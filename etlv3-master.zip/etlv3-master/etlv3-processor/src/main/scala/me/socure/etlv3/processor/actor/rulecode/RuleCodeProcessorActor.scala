package me.socure.etlv3.processor.actor.rulecode

import me.socure.etlv3.kinesis.KinesisProcessorService
import me.socure.etlv3.processor.actor.{DataExecutor, DataProcessorActor}

class RuleCodeProcessorActor(
                                           val kinesisProcessorService: KinesisProcessorService
                                         ) extends DataExecutor {
  val processorType = DataProcessorActor.RuleCodeDataProcessor
}
