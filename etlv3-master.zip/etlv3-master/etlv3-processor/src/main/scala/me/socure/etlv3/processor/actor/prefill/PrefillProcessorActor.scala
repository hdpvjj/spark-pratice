package me.socure.etlv3.processor.actor.prefill

import me.socure.etlv3.kinesis.KinesisProcessorService
import me.socure.etlv3.processor.actor.{DataExecutor, DataProcessorActor}

class PrefillProcessorActor(
                             val kinesisProcessorService: KinesisProcessorService,
                             val dataKeys               : Map[String, Array[Byte]]
                           ) extends DataExecutor {
  val processorType = DataProcessorActor.PrefillDataProcessor
}
