package me.socure.etlv3.processor.provider

import me.socure.etlv3.common.ParserTypes

object ParserProvider {
  def getParsers(): Seq[ParserTypes.ParserType] = {
    Seq(
         ParserTypes.TransactionRawParser,
         ParserTypes.TransactionPiiParser,
         ParserTypes.TransactionParser,
         ParserTypes.ReasonCodeParser,
         ParserTypes.RuleCodeParser,
         ParserTypes.WatchlistParser,
         ParserTypes.ModelScoreParser,
         ParserTypes.ModelScoreResponseParser,
         ParserTypes.RuleCodeIntactParser,
         ParserTypes.KYCCodeParser,
         ParserTypes.DecisionParser,
         ParserTypes.PrefillParser,
         ParserTypes.DocVParser
       )
  }
}
