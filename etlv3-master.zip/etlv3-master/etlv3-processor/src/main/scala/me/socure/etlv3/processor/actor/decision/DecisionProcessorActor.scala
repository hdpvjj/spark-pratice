package me.socure.etlv3.processor.actor.decision

import me.socure.etlv3.kinesis.KinesisProcessorService
import me.socure.etlv3.processor.actor.{DataExecutor, DataProcessorActor}

class DecisionProcessorActor(
                                val kinesisProcessorService: KinesisProcessorService
                              ) extends DataExecutor {
  val processorType = DataProcessorActor.DecisionDataProcessor
}

