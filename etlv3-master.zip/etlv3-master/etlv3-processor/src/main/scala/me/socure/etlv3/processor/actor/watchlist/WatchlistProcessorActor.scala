package me.socure.etlv3.processor.actor.watchlist

import me.socure.etlv3.kinesis.KinesisProcessorService
import me.socure.etlv3.processor.actor.{DataExecutor, DataProcessorActor}

class WatchlistProcessorActor(
                               val kinesisProcessorService: KinesisProcessorService
                             ) extends DataExecutor {
  val processorType = DataProcessorActor.WatchlistDataProcessor

}
