package me.socure.etlv3.processor.actor.transactionpii

import me.socure.etlv3.kinesis.KinesisProcessorService
import me.socure.etlv3.processor.actor.{DataExecutor, DataProcessorActor}

class TransactionPiiProcessorActor(
                                    val kinesisProcessorService: KinesisProcessorService,
                                    val dataKeys               : Map[String, Array[Byte]]
                                  ) extends DataExecutor {
  val processorType = DataProcessorActor.TransactionPiiDataProcessor
}
