package me.socure.etlv3.kinesis.module

import com.google.inject.AbstractModule
import me.socure.etlv3.kinesis.KinesisProcessorService
import me.socure.etlv3.kinesis.provider.KinesisProcessorServiceProvider

class KinesisProcessorServiceModule extends AbstractModule {
  override
  def configure(): Unit = {
    bind(classOf[KinesisProcessorService]).toProvider(classOf[KinesisProcessorServiceProvider]).asEagerSingleton()
  }
}
