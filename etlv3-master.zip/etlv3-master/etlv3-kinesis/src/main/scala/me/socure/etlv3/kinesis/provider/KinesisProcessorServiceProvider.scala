package me.socure.etlv3.kinesis.provider

import com.typesafe.config.Config
import javax.inject.{Inject, Provider}
import me.socure.etlv3.kinesis.KinesisProcessorService

class KinesisProcessorServiceProvider @Inject()(config: Config) extends Provider[KinesisProcessorService] {
  override
  def get(): KinesisProcessorService = {
    new KinesisProcessorService(config = config)
  }
}
