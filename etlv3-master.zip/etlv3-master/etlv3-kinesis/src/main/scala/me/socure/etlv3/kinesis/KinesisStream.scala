package me.socure.etlv3.kinesis

import me.socure.common.metrics.JavaMetricsFactory
import me.socure.etlv3.common.KinesisStreamTypes.KinesisStreamType
import me.socure.etlv3.common._
import org.json4s.DefaultFormats
import org.slf4j.LoggerFactory
import software.amazon.awssdk.core.SdkBytes
import software.amazon.awssdk.services.firehose.FirehoseClient
import software.amazon.awssdk.services.firehose.model.{PutRecordResponse, Record, PutRecordRequest => PutFirehoseRecordRequest}

import scala.compat.Platform.EOL

trait KinesisStream[A <: Data] {
  def process[A <: Data](data: A)
}

object KinesisStream {

  private implicit val FORMATS: DefaultFormats = DefaultFormats
  private          val logger                  = LoggerFactory.getLogger(getClass)
  private          val metrics                 = JavaMetricsFactory.get(getClass)
  private          val RULE_KEY                = "ruleCode"
  private
  class TransactionStream(
                           streamName: String,
                           builder   : FirehoseClient,
                           datadogEnvTag: String
                         ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val transaction = data.asInstanceOf[Transaction]
      processFirehoseRequest(builder, streamName, transaction.transactionId, transaction.accountId, data, datadogEnvTag)
    }
  }

  private
  class TransactionRawStream(
                           streamName: String,
                           builder   : FirehoseClient,
                           datadogEnvTag: String
                         ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val transaction = data.asInstanceOf[TransactionRaw]
      processFirehoseRequest(builder, streamName, transaction.transactionId, transaction.accountId, data, datadogEnvTag)
    }
  }

  private
  class TransactionPiiStream(
                              streamName: String,
                              builder   : FirehoseClient,
                              datadogEnvTag: String
                            ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val transaction = data.asInstanceOf[TransactionPii]
      processFirehoseRequest(builder, streamName, transaction.transactionId, transaction.accountId, data, datadogEnvTag)
    }
  }

  private
  class ReasonCodeStream(
                          streamName: String,
                          builder: FirehoseClient,
                          datadogEnvTag: String
                        ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val reasonCode = data.asInstanceOf[ReasonCode]
      processFirehoseRequest(builder, streamName, reasonCode.transactionId, reasonCode.accountId, data, datadogEnvTag)
    }
  }

  private
  class RuleCodeIntactStream(
                              streamName: String,
                              builder   : FirehoseClient,
                              datadogEnvTag: String
                            ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val ruleCodeIntact = data.asInstanceOf[RuleCodeIntact]
      processFirehoseRequest(builder, streamName, ruleCodeIntact.transactionId, ruleCodeIntact.accountId, data, datadogEnvTag)
    }
  }

  private
  class RuleCodeStream(
                        streamName: String,
                        builder: FirehoseClient,
                        datadogEnvTag: String
                      ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val ruleCode = data.asInstanceOf[RuleCodeValue]
      processFirehoseRequest(builder, streamName, ruleCode.transactionId, ruleCode.accountId, data, datadogEnvTag)
    }
  }

  private
  class WatchlistStream(
                         streamName: String,
                         builder: FirehoseClient,
                         datadogEnvTag: String
                       ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val watchlist = data.asInstanceOf[Watchlist]
      processFirehoseRequest(builder, streamName, watchlist.transactionId, watchlist.accountId, data, datadogEnvTag)
    }
  }

  private
  class ModelScoreStream(
                          streamName: String,
                          builder: FirehoseClient,
                          datadogTag: String
                        ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val modelScore = data.asInstanceOf[ModelScoreOutput]
      processFirehoseRequest(builder, streamName, modelScore.transactionId, modelScore.accountId, data, datadogTag)
    }
  }

  private
  class ModelScoreResponseStream(
                                  streamName: String,
                                  builder: FirehoseClient,
                                  datadogTag: String
                                ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val modelScoreResponse = data.asInstanceOf[ModelScoreOutput]
      processFirehoseRequest(builder, streamName, modelScoreResponse.transactionId, modelScoreResponse.accountId, data, datadogTag)
    }
  }

  private
  class TransactionPiiNonConsentStream(
                                        streamName: String,
                                        firehoseClient: FirehoseClient,
                                        datadogEnvTag: String
                                      ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val transaction = data.asInstanceOf[TransactionPii]
      processFirehoseRequest(firehoseClient, streamName, transaction.transactionId, transaction.accountId, data, datadogEnvTag)
    }
  }

  private
  class TransactionRawNonConsentStream(
                                        streamName: String,
                                        firehoseClient: FirehoseClient,
                                        datadogEnvTag: String
                                      ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val transaction = data.asInstanceOf[TransactionRaw]
      processFirehoseRequest(firehoseClient, streamName, transaction.transactionId, transaction.accountId, data, datadogEnvTag)
    }
  }

  private
  class KYCCodeStream(
                                        streamName: String,
                                        firehoseClient: FirehoseClient,
                                        datadogEnvTag: String
                                      ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val kycCode = data.asInstanceOf[KYCCode]
      processFirehoseRequest(firehoseClient, streamName, kycCode.transactionId, kycCode.accountId, data,
        datadogEnvTag)
    }
  }

  private
  class DecisionStream(
                       streamName: String,
                       firehoseClient: FirehoseClient,
                       datadogEnvTag: String
                     ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val transaction = data.asInstanceOf[Decision]
      processFirehoseRequest(firehoseClient, streamName, transaction.transactionId, transaction.accountId, data, datadogEnvTag)
    }
  }

  private
  class DocVStream(
                        streamName: String,
                        firehoseClient: FirehoseClient,
                        datadogEnvTag: String
                      ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val transaction = data.asInstanceOf[DocV]
      processFirehoseRequest(firehoseClient, streamName, transaction.transactionId, transaction.accountId, data, datadogEnvTag)
    }
  }

  private
  class DocVNonConsentStream(
                                        streamName: String,
                                        firehoseClient: FirehoseClient,
                                        datadogEnvTag: String
                                      ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val transaction = data.asInstanceOf[DocV]
      processFirehoseRequest(firehoseClient, streamName, transaction.transactionId, transaction.accountId, data, datadogEnvTag)
    }
  }

  private
  class PrefillStream(
                    streamName: String,
                    firehoseClient: FirehoseClient,
                    datadogEnvTag: String
                  ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val transaction = data.asInstanceOf[Prefill]
      processFirehoseRequest(firehoseClient, streamName, transaction.transactionId, transaction.accountId, data, datadogEnvTag)
    }
  }

  private
  class PrefillNonConsentStream(
                              streamName: String,
                              firehoseClient: FirehoseClient,
                              datadogEnvTag: String
                            ) extends KinesisStream[Data] {
    override
    def process[A <: Data](data: A): Unit = {
      val transaction = data.asInstanceOf[Prefill]
      processFirehoseRequest(firehoseClient, streamName, transaction.transactionId, transaction.accountId, data, datadogEnvTag)
    }
  }

  def processFirehoseRequest(firehoseClient: FirehoseClient,
                             streamName: String,
                             trxId: String,
                             accountId: String,
                             data: Data,
                             datadogEnvTag: String) = {
    data.payload match {
      case Some(payload) if payload.trim.equals("[]") || payload.trim.equals("{}") || payload.trim.isEmpty =>
         logEmptyRecord(trxId, streamName)
      case Some(_) =>
         logFirehoseWriteFailure(writeToFirehose(data, firehoseClient, streamName), datadogEnvTag)_
      case None =>
         logEmptyRecord(trxId, streamName)
    }


  }

  def logFirehoseWriteFailure(streamResponse: PutRecordResponse, datadogEnvTag: String)(
    stream: String,
    trxId: String, acctId: String
  ) = {
    if (streamResponse.recordId().isEmpty) {
      val errorMessage = s"FAILED TO PUT RECORD IN FIREHOSE $stream: $trxId"
      metrics.increment(s"$stream.failed.put.record.firehose", s"env:$datadogEnvTag")
      logger.error(errorMessage)
      throw FirehoseException(errorMessage)
    }
  }

  def writeToFirehose(data: Data, firehoseClient: FirehoseClient, streamName: String) = {
    val sdkBytes = SdkBytes.fromByteArray((data.payload.getOrElse("") + EOL).getBytes())
    val record = Record.builder()
                 .data(sdkBytes)
                 .build()
    val recordRequest = PutFirehoseRecordRequest.builder()
                        .deliveryStreamName(streamName)
                        .record(record)
                        .build()
    firehoseClient.putRecord(recordRequest)
  }

  def logEmptyRecord(trxId: String, stream: String) = {
    metrics.increment(s"$stream.skip.empty.record")
    logger.info(s"SKIPPED PUTTING RECORD TO STREAM FOR $stream: ${trxId}")
  }

  def str(streamType: KinesisStreamType) = {
    streamType.toString
  }

  def apply(
             streamType    : String,
             streamName    : String,
             firehoseClient: FirehoseClient,
             datadogEnvTag : String
           ) = {

    val transactionStream         = str(KinesisStreamTypes.TransactionStream)
    val reasonCodeStream          = str(KinesisStreamTypes.ReasonCodeStream)
    val watchlistStream           = str(KinesisStreamTypes.WatchlistStream)
    val modelScoreStream          = str(KinesisStreamTypes.ModelScoreStream)
    val modelScoreResponseStream  = str(KinesisStreamTypes.ModelScoreResponseStream)
    val transactionPiiStream      = str(KinesisStreamTypes.TransactionPiiStream)
    val transactionRawStream      = str(KinesisStreamTypes.TransactionRawStream)
    val ruleCodeIntactStream      = str(KinesisStreamTypes.RuleCodeIntactStream)
    val nonConsentingPiiStream    = str(KinesisStreamTypes.NonConsentingTransactionPiiStream)
    val nonConsentingTrxRawStream = str(KinesisStreamTypes.NonConsentingTransactionRawStream)
    val decisionStream            = str(KinesisStreamTypes.DecisionStream)
    val kycCodeStream             = str(KinesisStreamTypes.KYCCodeStream)
    val nonConsentingDocVStream   = str(KinesisStreamTypes.NonConsentingDocVStream)
    val docVStream                = str(KinesisStreamTypes.DocVStream)
    val nonConsentingPrefillStream= str(KinesisStreamTypes.NonConsentingPrefillStream)
    val prefillStream             = str(KinesisStreamTypes.PrefillStream)

    streamType match {
      case `ruleCodeIntactStream`      => new RuleCodeIntactStream(streamName, firehoseClient, datadogEnvTag)
      case `transactionStream`         => new TransactionStream(streamName, firehoseClient, datadogEnvTag)
      case `reasonCodeStream`          => new ReasonCodeStream(streamName, firehoseClient, datadogEnvTag)
      case  ruleName if(ruleName.contains(RULE_KEY))
                                       => new RuleCodeStream(streamName, firehoseClient, datadogEnvTag)
      case `watchlistStream`           => new WatchlistStream(streamName, firehoseClient, datadogEnvTag)
      case `modelScoreStream`          => new ModelScoreStream(streamName, firehoseClient, datadogEnvTag)
      case `modelScoreResponseStream`  => new ModelScoreResponseStream(streamName, firehoseClient, datadogEnvTag)
      case `transactionPiiStream`      => new TransactionPiiStream(streamName, firehoseClient, datadogEnvTag)
      case `nonConsentingPiiStream`    => new TransactionPiiNonConsentStream(streamName, firehoseClient, datadogEnvTag)
      case `transactionRawStream`      => new TransactionRawStream(streamName, firehoseClient, datadogEnvTag)
      case `nonConsentingTrxRawStream` => new TransactionRawNonConsentStream(streamName, firehoseClient, datadogEnvTag)
      case `decisionStream`            => new DecisionStream(streamName, firehoseClient, datadogEnvTag)
      case `kycCodeStream`             => new KYCCodeStream(streamName, firehoseClient, datadogEnvTag)
      case `nonConsentingDocVStream`   => new DocVNonConsentStream(streamName, firehoseClient, datadogEnvTag)
      case `docVStream`                => new DocVStream(streamName, firehoseClient, datadogEnvTag)
      case `nonConsentingPrefillStream`=> new PrefillNonConsentStream(streamName, firehoseClient, datadogEnvTag)
      case `prefillStream`             => new PrefillStream(streamName, firehoseClient, datadogEnvTag)
    }
  }
}
