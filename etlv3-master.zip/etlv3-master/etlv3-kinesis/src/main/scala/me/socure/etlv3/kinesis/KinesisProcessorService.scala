package me.socure.etlv3.kinesis

import com.amazonaws.regions.Regions
import com.typesafe.config.Config
import javax.inject.Inject
import me.socure.etlv3.common.Data
import scala.collection.JavaConverters._
import software.amazon.awssdk.services.firehose.FirehoseClient
import software.amazon.awssdk.regions.Region

class KinesisProcessorService @Inject()(
                                         config: Config
                                       ) {

  lazy val KINESIS_STREAM_MAP = config.getConfig("pipeline.kinesis.stream").entrySet.asScala.map(e => e.getKey -> e
    .getValue.render().replaceAll("^\"|\"$", "")).toMap

  lazy
  val FIREHOSE_CLIENT = FirehoseClient.builder()
                        .region(Region.of(config.getString("pipeline.region")))
                        .build()


  lazy val datadogEnvTag = config.getString("dataDogEnvTag")
  def processStream(data: Data, streamType: String) = {
    KinesisStream(streamType, KINESIS_STREAM_MAP.get(streamType).get, FIREHOSE_CLIENT, datadogEnvTag).process(data)
  }
}
