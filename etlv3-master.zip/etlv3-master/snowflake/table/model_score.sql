CREATE TABLE IF NOT EXISTS model_score
(
  transaction_id VARCHAR(36),
  account_id INTEGER,
  run_id VARCHAR(255),
  transaction_date TIMESTAMP_NTZ,
  model_identifier	VARCHAR,
  environment_id	NUMBER(20),
  model_name	VARCHAR,
  model_version	VARCHAR,
  model_association_type	VARCHAR,
  model_type	VARCHAR,
  original_score	FLOAT8,
  quantile_score	FLOAT8,
  output_score	FLOAT8,
  model_id	NUMBER(20),
  country	VARCHAR,
  PRIMARY KEY (transaction_id)
  )
  STAGE_COPY_OPTIONS = (MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE);