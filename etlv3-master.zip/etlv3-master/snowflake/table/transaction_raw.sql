CREATE TABLE IF NOT EXISTS transaction_raw
(
  transaction_id VARCHAR(36),
  transaction VARIANT,
  PRIMARY KEY (transaction_id),
  FOREIGN KEY (transaction_id) REFERENCES transaction (transaction_id)
  )
  STAGE_COPY_OPTIONS = (MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE);