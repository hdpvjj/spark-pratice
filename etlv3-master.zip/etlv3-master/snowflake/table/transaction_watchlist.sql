CREATE TABLE IF NOT EXISTS transaction_watchlist
(
  transaction_id VARCHAR(36),
  account_id INTEGER,
  run_id VARCHAR(255),
  transaction_date TIMESTAMP_NTZ,
  matches VARIANT,
  settings VARIANT,
  PRIMARY KEY (transaction_id),
  FOREIGN KEY (transaction_id) REFERENCES transaction (transaction_id)
  )
  STAGE_COPY_OPTIONS = (MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE);