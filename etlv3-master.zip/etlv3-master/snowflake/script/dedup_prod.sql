-- for prod env
-- 1, use account_admin role (TF somehow can't not grant such permission)
use database TRANSACTION_PROD;
grant execute task on account to role TERRAFORMSERVICE;
grant monitor execution on account to role ETL_DEVELOPER;

-- 2, use TERRAFORMSERVICE role
USE ROLE TERRAFORMSERVICE;
use database TRANSACTION_PROD;

-- store procedures to dedup a table (from duplicate and identical records)
-- param: table_name: target table_name
-- param: delta: TRUE to dedup only new records since last run, FALSE to dedup all records in the table
-- param: pkey_columns: comma separated primary key column names
create or replace procedure detect_and_dedup(table_name VARCHAR, delta BOOLEAN, pkey_columns VARCHAR)
    returns varchar not null
    language javascript
    comment = 'dedup a table (from duplicate and identical records)'
    as
    $$
    var epoch_sec = Math.round(new Date().getTime()/1000)
    var result = "";
    var tempTable = TABLE_NAME + "_" + epoch_sec;
    var pkeysArray = PKEY_COLUMNS.split(",").map(x => x.trim());
    var pkeysLenSeqStr = Array(pkeysArray.length).fill().map((element, index)=>index + 1).join(",");

    var dupRecordsSQL = (DELTA) ? ("(select " + pkeysArray.map(x => `t.${x}`).join(', ') + ", count(1) cnt from " + TABLE_NAME + " t join " + "(select distinct " + PKEY_COLUMNS + " from \"" + TABLE_NAME +
        "_change_stream\") s on " + pkeysArray.map(x => `t.${x} = s.${x}`).join(' and ') + " group by " + pkeysLenSeqStr + " having cnt > 1) d ") : ("(select " + PKEY_COLUMNS + ", count(1) cnt from " + TABLE_NAME + " group by "+ pkeysLenSeqStr + " having cnt > 1) d ")
    var createTempTableDDL = "create table " + tempTable + " as (select t.* from " + TABLE_NAME + " t join " +
        dupRecordsSQL + " on " + pkeysArray.map(x => `d.${x} = t.${x}`).join(' and ') + ");\n";
    var createDupTableDDL = "create table if not exists dup_" + TABLE_NAME + " as select to_timestamp(" + epoch_sec +
        ")::timestamp_ntz as updated_at, * from " + tempTable +" limit 0;\n"
    var insertDupTableCmd = "insert into \"dup_" + TABLE_NAME + "\" select to_timestamp(" + epoch_sec +
        ")::timestamp_ntz as updated_at, * from " + tempTable + ";\n"
    var deleteCmd = "delete from " + TABLE_NAME + " using (select distinct " + PKEY_COLUMNS + " from "  + tempTable +") d where " + pkeysArray.map(x => `${TABLE_NAME}.${x} = d.${x}`).join(' and ') + ";\n";
    var insertCmd = "insert into " + TABLE_NAME + " select  * from " + tempTable +" qualify row_number() over (partition by " + pkeysLenSeqStr +  " order by tetl_proc_time desc) =1;\n";
    var insertDedupHistoryCmd = "insert into \"dedup_history\" select '" + TABLE_NAME + "' as table_name, sysdate() as updated_at,  count (distinct " + PKEY_COLUMNS + ") as distinct_count, count(1) as total_count from " + tempTable + " having total_count > 0;"
    var dropTempTableCmd = "drop table " + tempTable;

    snowflake.execute( {sqlText: "BEGIN WORK;"} );
    try {
        var stmt_create = snowflake.createStatement({sqlText:createTempTableDDL});
        var res_create = stmt_create.execute();
        res_create.next();

//        snowflake.execute({sqlText:createDupTableDDL});
        snowflake.execute({sqlText:deleteCmd});
        snowflake.execute({sqlText:insertCmd});
        snowflake.execute({sqlText:insertDedupHistoryCmd});
        snowflake.execute({sqlText:dropTempTableCmd});
        snowflake.execute({sqlText: "COMMIT WORK;"});
    } catch (err) {
        snowflake.execute({sqlText:"ROLLBACK WORK;"});
        throw createTempTableDDL + "\n" +  deleteCmd + "\n" + insertCmd +  insertDedupHistoryCmd + "\n" + dropTempTableCmd+  "\nFailed: \n" + err
    }

    return createTempTableDDL + deleteCmd + "\n " + insertCmd;
    $$
    ;
-- convenient table dedup method with default primary key 'transaction_id'
create or replace procedure detect_and_dedup(table_name VARCHAR, delta BOOLEAN)
    returns varchar not null
    language javascript
    as
    $$
        snowflake.createStatement({sqlText:`call detect_and_dedup('${TABLE_NAME}', ${DELTA}, 'transaction_id')`}).execute().next();
        return 'SUCCESS'
    $$
    ;

-- convenient table dedup method with delta mode and primary key 'transaction_id'
create or replace procedure detect_and_dedup(table_name VARCHAR)
    returns varchar not null
    language javascript
    as
    $$
        snowflake.createStatement({sqlText:`call detect_and_dedup('${TABLE_NAME}', TRUE)`}).execute().next();
        return 'SUCCESS'
    $$
    ;

create or replace procedure dedup_all_tables(delta BOOLEAN)
    returns varchar not null
    language javascript
    as
    $$
        snowflake.createStatement({sqlText:`call detect_and_dedup('transaction', ${DELTA}, 'transaction_id')`}).execute().next();
        snowflake.createStatement({sqlText:`call detect_and_dedup('reason_code', ${DELTA}, 'transaction_id')`}).execute().next();
        snowflake.createStatement({sqlText:`call detect_and_dedup('rule_code_compliance', ${DELTA}, 'transaction_id')`}).execute().next();
        snowflake.createStatement({sqlText:`call detect_and_dedup('rule_code_docv', ${DELTA}, 'transaction_id')`}).execute().next();
        snowflake.createStatement({sqlText:`call detect_and_dedup('rule_code_fraud', ${DELTA}, 'transaction_id')`}).execute().next();
        snowflake.createStatement({sqlText:`call detect_and_dedup('rule_code_fraud_legacy', ${DELTA}, 'transaction_id')`}).execute().next();
        snowflake.createStatement({sqlText:`call detect_and_dedup('rule_code_globals', ${DELTA}, 'transaction_id')`}).execute().next();
        snowflake.createStatement({sqlText:`call detect_and_dedup('transaction_watchlist', ${DELTA}, 'transaction_id')`}).execute().next();
        snowflake.createStatement({sqlText:`call detect_and_dedup('transaction_raw', ${DELTA}, 'transaction_id')`}).execute().next();
        snowflake.createStatement({sqlText:`call detect_and_dedup('model_score', ${DELTA}, 'transaction_id, model_identifier, model_version')`}).execute().next();
        snowflake.createStatement({sqlText:`call detect_and_dedup('rule_code_uncategorized', ${DELTA}, 'transaction_id')`}).execute().next();
        snowflake.createStatement({sqlText:`call detect_and_dedup('transaction_pii', ${DELTA}, 'transaction_id')`}).execute().next();
        snowflake.createStatement({sqlText:`call detect_and_dedup('rule_code', ${DELTA}, 'transaction_id')`}).execute().next();

        return 'SUCCESS'
    $$
    ;

CREATE OR REPlACE TASK TASK_DEDUP_ALL_WH
  warehouse = compute_wh
  -- SCHEDULE = '10 minute'
  SCHEDULE = 'USING CRON 00 04 * * * America/Los_Angeles'
AS
call TRANSACTION_PROD.PUBLIC.dedup_all_tables(TRUE);

-- TODO adjust for diff env
-- grant usage on future procedures in schema transaction_dev.public to etl_developer role;
grant usage on  procedure detect_and_dedup(varchar, boolean, varchar) to ETL_DEVELOPER;
grant operate on task task_dedup_all_wh to role ETL_DEVELOPER;

-- task may be in suspended state after creation, so you will need to change its state to resume
-- alter task task_dedup_all_wh resume;