-- list files that failed to be copied (including snowpiped) into the table_name in the last 14 days.
-- param: table_name: target table_name
-- returns: array of (still) failed files in json.
-- example:
-- call failed_copies('rule_code_faud');

create or replace procedure failed_copies(table_name VARCHAR)
    returns VARIANT
    language javascript
    execute as CALLER
    as
    $$
    var failed_files = [];
    
    // Dynamically compose the SQL statement to get failed files
    var sqlCommand = "select replace(file_name, '" + TABLE_NAME + "/', '') as file_name_normalized, \
    first_value(error_count) over (partition by file_name_normalized order by last_load_time desc) last_error_count \
    from table(information_schema.copy_history(table_name=>'" + TABLE_NAME +"', start_time=> dateadd(day, -" + 14 +", current_timestamp()))) \
    qualify last_error_count > 0 order by last_load_time desc;"
    // Prepare statement.
    var stmt = snowflake.createStatement(
           {
           sqlText: sqlCommand
           }
        );
    // Execute Statement
    var res = stmt.execute();
    while (res.next()) {
        failed_files.push(res.getColumnValue(1))
    }
    return failed_files;
$$;

-- list all files that are not successfully copied into etlv3 tables in the last 14 days
--
-- returns: array of failed files in json
-- example:
-- call failed_copies('rule_code_fraud');
create or replace procedure all_failed_copies()
    returns VARIANT
    language javascript
    execute as CALLER
    as
    $$
    
    const tables = ['rule_code_fraud','rule_code_fraud_legacy','rule_code_globals', 'rule_code_compliance', 'rule_code_docv', 'transaction','reason_code'];
    
    var results = tables.map( x => failed_copies(x)).flat();
    return results;
    
    function failed_copies(one_table_name){
      var failed_files = [];

      // Dynamically compose the SQL statement to get failed files
      var sqlCommand = "select replace(file_name, '" + one_table_name + "/', '') as file_name_normalized, \
      first_value(error_count) over (partition by file_name_normalized order by last_load_time desc) last_error_count \
      from table(information_schema.copy_history(table_name=>'" + one_table_name +"', start_time=> dateadd(day, -" + 14 +", current_timestamp()))) \
      qualify last_error_count > 0 order by last_load_time desc;"
      // Prepare statement.
      var stmt = snowflake.createStatement(
             {
             sqlText: sqlCommand
             }
          );
      // Execute Statement
      var res = stmt.execute();
      while (res.next()) {
          failed_files.push(res.getColumnValue(1))
      }
      return failed_files;
    }
$$;
