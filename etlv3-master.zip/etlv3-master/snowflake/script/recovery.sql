-- store procedures to manually reprocess files previously failed to load in snowpipe

-- copy a file from etlv3 stage to table
-- param: table_name: target table_name
--        file: relative path of file in the stage location for the target table (ie, FILE_NAME column in information_schema.copy_history)
-- returns: copy result
-- example:
-- call etlv3_copy('rule_code_compliance','dt=20220228/etlv3-rule_code_compliance-s3-firehose-dev-1-2022-02-28-18-16-20-37ae0139-0c42-4053-ae18-9e4b513b8fd6');
create or replace procedure etlv3_copy(table_name VARCHAR, file VARCHAR)
    returns varchar
    language javascript
    comment = 'copy a file from an etlv3 stage to a table'
    as
    $$

    // Dynamically compose the SQL statement to execute.
    var sqlCommand = "COPY INTO " + TABLE_NAME + " FROM @etlv3/" + TABLE_NAME + "/" + FILE + " FILE_FORMAT = (TYPE = 'JSON') MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE;"

    // Prepare statement.
    var stmt = snowflake.createStatement(
           {
           sqlText: sqlCommand
           }
        );
    // Execute Statement
    var res = stmt.execute();
    res.next();
    var result = res.getColumnValueAsString(1);
    return result;
  $$;

-- reload failed files (in the last 14 days) for a target table
-- param: table_name: target table_name
-- returns: VARIANT of all files reload attempted
create or replace procedure reload_failed(table_name VARCHAR)
    returns VARIANT
    language javascript
    comment = 'reload failed files (in the last 14 days) for a target table'
    execute as CALLER
    as
    $$
    var failed_files = [];
    var return_rows =[];

    // Dynamically compose the SQL statement to get files still in the failed state
    // FILE_NAME column in copy_history starts with "$TABLE_NAME/" prefix for (manual) COPY result. Snowpipe result
    // does not have such prefix.
    var sqlCommand = "SELECT REPLACE(file_name, '" + TABLE_NAME + "/', '') AS file_name_normalized, \
    FIRST_VALUE(error_count) OVER (PARTITION BY file_name_normalized ORDER BY last_load_time DESC) last_error_count \
    FROM TABLE(information_schema.copy_history(table_name=>'" + TABLE_NAME +"', start_time=> dateadd(day, -" + 14 +", current_timestamp()))) \
    qualify last_error_count > 0 ORDER BY last_load_time DESC;"

    var stmt = snowflake.createStatement({sqlText: sqlCommand});
    var res = stmt.execute();
    while (res.next()) {
        failed_files.push(res.getColumnValue(1))
    }

    for (let i = 0; i < failed_files.length; i++) {
        var stmt_call = snowflake.createStatement({sqlText: 'CALL ETLV3_COPY(:1, :2)', binds:[TABLE_NAME, failed_files[i]]});
        var result_call = stmt_call.execute();
        result_call.next();
        return_rows.push(result_call.getColumnValue(1));
    }

    return return_rows;
$$;
