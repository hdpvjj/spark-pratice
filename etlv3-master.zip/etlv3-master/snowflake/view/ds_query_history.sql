use database TRANSACTION_DS;
grant execute task on account to role TERRAFORMSERVICE;
use role TERRAFORMSERVICE;

//Daily query history view for DS_RSTUDIO_WORKBENCH role
create view if not exists DS_RSTUDIO_WORKBENCH_QUERY_HISTORY as select * from table(information_schema.query_history(dateadd('days',-1,current_timestamp()),current_timestamp())) where ROLE_NAME = 'DS_RSTUDIO_WORKBENCH' order by start_time;

//Daily query history view for DS_SODAT role
create view if not exists DS_SODAT_QUERY_HISTORY as select * from table(information_schema.query_history(dateadd('days',-1,current_timestamp()),current_timestamp())) where ROLE_NAME = 'DS_SODAT' order by start_time;