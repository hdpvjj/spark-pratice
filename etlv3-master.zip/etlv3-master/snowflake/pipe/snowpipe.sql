-- create integration object
CREATE OR REPLACE STORAGE INTEGRATION etlv3integration
  TYPE = EXTERNAL_STAGE
  STORAGE_PROVIDER = S3
  ENABLED = TRUE
  STORAGE_AWS_ROLE_ARN = 'arn:aws:iam::389560044849:role/etlv3_snowpipe_role'
  STORAGE_ALLOWED_LOCATIONS = ('s3://etlv3-transactions-dev/');

-- create stage
CREATE STAGE etlv3
  URL = 's3://etlv3-transactions-dev/'
  STORAGE_INTEGRATION = etlv3integration;
