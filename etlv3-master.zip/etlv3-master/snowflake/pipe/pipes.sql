USE DATABASE ETLV3_DEV;
USE SCHEMA PUBLIC;

CREATE OR REPLACE PIPE transaction AUTO_INGEST=TRUE AS
  COPY INTO transaction
  FROM @etlv3/transaction/
  FILE_FORMAT = (TYPE = 'JSON')
  MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
;


CREATE OR REPLACE PIPE reason_code AUTO_INGEST=TRUE AS
  COPY INTO reason_code
  FROM @etlv3/reason_code/
  FILE_FORMAT = (TYPE = 'JSON')
  MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
;

-- 5 PIPES FOR RULE_CODE TABLES + uncategorized
CREATE OR REPLACE PIPE rule_code_compliance AUTO_INGEST=TRUE AS
  COPY INTO rule_code_compliance
  FROM @etlv3/rule_code_compliance/
  FILE_FORMAT = (TYPE = 'JSON')
  MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
;


CREATE OR REPLACE PIPE rule_code_docv AUTO_INGEST=TRUE AS
  COPY INTO rule_code_docv
  FROM @etlv3/rule_code_docv/
  FILE_FORMAT = (TYPE = 'JSON')
  MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
;

CREATE OR REPLACE PIPE rule_code_fraud AUTO_INGEST=TRUE AS
  COPY INTO rule_code_fraud
  FROM @etlv3/rule_code_fraud/
  FILE_FORMAT = (TYPE = 'JSON')
  MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
;

CREATE OR REPLACE PIPE rule_code_fraud_legacy AUTO_INGEST=TRUE AS
  COPY INTO rule_code_fraud_legacy
  FROM @etlv3/rule_code_fraud_legacy/
  FILE_FORMAT = (TYPE = 'JSON')
  MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
;

CREATE OR REPLACE PIPE rule_code_globals AUTO_INGEST=TRUE AS
  COPY INTO rule_code_globals
  FROM @etlv3/rule_code_globals/
  FILE_FORMAT = (TYPE = 'JSON')
  MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
;

CREATE OR REPLACE PIPE rule_code_uncategorized AUTO_INGEST=TRUE AS
  COPY INTO rule_code_uncategorized
  FROM @etlv3/rule_code_uncategorized/
  FILE_FORMAT = (TYPE = 'JSON')
  MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
;

CREATE OR REPLACE PIPE transaction_watchlist AUTO_INGEST=TRUE AS
  COPY INTO transaction_watchlist
  FROM @etlv3/transaction_watchlist/
  FILE_FORMAT = (TYPE = 'JSON')
  MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
;

CREATE OR REPLACE PIPE transaction_raw AUTO_INGEST=TRUE AS
  COPY INTO transaction_raw
  FROM @etlv3/transaction_raw/
  FILE_FORMAT = (TYPE = 'JSON')
  MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
;

CREATE OR REPLACE PIPE model_score AUTO_INGEST=TRUE AS
  COPY INTO model_score
  FROM @etlv3/model_score/
  FILE_FORMAT = (TYPE = 'JSON')
  MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
;

